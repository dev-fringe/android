package com.sprhib;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:context-h2.xml")
public class DB {

	@Test
	public void sdsd() { 
		for (int i = 0; i < 1000; i++) {
			i--;
		}
	}
}
