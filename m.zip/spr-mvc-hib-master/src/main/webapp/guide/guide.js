$(function() {
	var headH = $(".guid-menu").height();
	$("#iframeCt").height($(window).resize().height() - 105);


	$(".menu li").click(function(){
		$(this).addClass("active").siblings().removeClass("active");
	});

	$(".guide-nav-snb a").click(function(){
		var _target = $(this).attr('data-target');
		$('html').animate({scrollTop : $('#'+_target).offset().top} , 300);
		return false;
	});

	$(".guide-menu-control").click(function(i){
		$('html').toggleClass('open');
		$(".guide-menu-control").text($(this).text() == '메뉴 펼침' ? '메뉴 닫기' : '메뉴 펼침');
	});
	
});