var controller = $.extend(new $.CommonObj(), {
	eventInit : function() {
		// 로그인
		$(document).on("click", "#btnLogin", function() {
			if ($.trim($("#userId").val()) == "") {
				idChkPop();
				return;
			}
			if ($.trim($("#password").val()) == "") {
				pwChkPop();
				return;
			}
			
            controller.ajaxSend( {
				url : contextPath + '/login/apiLogin.json'
				, data : $("#form").serialize()
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var rsltCd = result.retApi.rsltCd;
					var rsltMsg = result.retApi.rsltMsg;
					var apiMsg = result.apiMsg;
					
					if (rsltCd == 000 || rsltCd == 001) { // 000 정상, 001 정상 (패스워드 종료일 7일이내)
						var easyId = $("#userId").val();
						if($("#easyYn").is(":checked")) { // 간편로그인 체크
							saveId(easyId);
						} else {
							saveId(""); // 간편로그인 해제
						}
						if (rsltCd == 001) {
							var notiTxt = '<p class="txt">'+ apiMsg +'</p>';
							$('#loginNotiMsg').html(notiTxt);
							loginNoti(); // 로그인 공지
						} else {
							goMain();
						}
					} else { //100 실패
						var txt = '<p class="txt">'+ apiMsg +'</p>';
						$('#popMsg').html(txt);
						loginFail(); // 로그인 실패
					}
				}
            });
		});

		// 테스트 DB 로그인
		$('#btnEasy').on({click :function(event){
			var param = {
						userId :'ants01' 
						, password : 'iants123!'
						, easyYn : 'on'
				};
			
		    controller.ajaxSend( {
		    	url : contextPath + "/login/dbLogin.json"
		    	, data : param
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var retCode = result.retCode;
					var retMsg = result.retMsg;
					var noti = result.loginNoti;
					if (retCode == "SUCC") {
						var easyId = $("#userId").val();
						if($("#easyYn").is(":checked")) { // 간편로그인 체크
							saveId(easyId);
						} else {
							saveId(""); // 간편로그인 해제
						}
						
						if(noti != "") {
							var notiTxt = '<p class="txt">'+ noti +'</p>';
							$('#loginNotiMsg').html(notiTxt);
							loginNoti(); // 로그인 공지
						} else {
							goMain();
						}
					} else {
						var txt = '<p class="txt">'+ retMsg +'</p>';
						$('#popMsg').html(txt);
						loginFail(); // 로그인 실패
					}
				}
		    });
	    }
		});
		// 테스트 DB 로그인
		$('#btnNor').on({click :function(event){
			var param = {
					userId :'ants01' 
					, password : 'iants123!'
			};
			
			controller.ajaxSend( {
				url : contextPath + "/login/dbLogin.json"
				, data : param
				, dataType : 'json'
					, type : 'post'
						, isBlock : true
						, isOverLap : true
						, successCall:function(result) {
							var retCode = result.retCode;
							var retMsg = result.retMsg;
							var noti = result.loginNoti;
							if (retCode == "SUCC") {
								var easyId = $("#userId").val();
								if($("#easyYn").is(":checked")) { // 간편로그인 체크
									saveId(easyId);
								} else {
									saveId(""); // 간편로그인 해제
								}
								
								if(noti != "") {
									var notiTxt = '<p class="txt">'+ noti +'</p>';
									$('#loginNotiMsg').html(notiTxt);
									loginNoti(); // 로그인 공지
								} else {
									goMain();
								}
							} else {
								var txt = '<p class="txt">'+ retMsg +'</p>';
								$('#popMsg').html(txt);
								loginFail(); // 로그인 실패
							}
						}
			});
		}
		});
		
		// 비밀번호 변경 버튼
		$(document).on("click", "#chgConfirm", function() {
			if ($("#chgConfirm").attr("class") == "btn1 red disabled") {
	    		$("#pwTitle").text('비밀번호 변경 안내');
	    		$("#pwMsg").text('변경 항목을 모두 입력해주세요.');
	     		$("#pwValidPop").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
				return;
			}
			
			if ($.trim($("#loginNewPw").val()) != $.trim($("#loginNewPwConfirm").val())) {
				$("#pwTitle").text('비밀번호 변경 안내');
				$("#pwMsg").text('새 비밀번호가 일치하지 않습니다.');
				$("#pwValidPop").bPopup({
					onOpen: function(){ $('body').addClass('bodyHold'); },
					onClose: function(){ $('body').removeClass('bodyHold'); }
				});
				return;			
			}
			
     		$("#pwConfirm").bPopup({
     			onOpen: function(){ $('body').addClass('bodyHold'); },
     			onClose: function(){ $('body').removeClass('bodyHold'); }
     		});
		});

		// 임시 비밀번호 신청 버튼
		$(document).on("click", "#chgIdTemporary", function() {
			if ($.trim($("#loginIdTemporary").val()) == "") {
	    		$("#pwTitle").text('임시 비밀번호 신청 안내');
	    		$("#pwMsg").text('아이디를 입력해주세요.');
	     		$("#pwValidPop").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
				$("#loginIdTemporary").focus();
				return;
			}
			$("#pwTempConfirm").bPopup({
				onOpen: function(){ $('body').addClass('bodyHold'); },
				onClose: function(){ $('body').removeClass('bodyHold'); }
			});
		});
	},
});

$(document).ready(function(){
	controller.init();
	
    // 로그인 버튼 키업 이벤트 
	$('#userId').keyup(function(event) {
		if ($.trim($("#userId").val()) == "") {
			$("#userId").val("");
			$('#btnLogin').addClass("disabled");
		} else if ($.trim($("#password").val()) == ""){
			$('#btnLogin').addClass("disabled");
		} else {
			$('#btnLogin').removeClass("disabled");
		}
	});
	$('#password').keyup(function(event) {
		if ($.trim($("#password").val()) == "") {
			$("#password").val("");
			$('#password').addClass("disabled");
		} else if ($.trim($("#userId").val()) == ""){
			$('#btnLogin').addClass("disabled");
		} else {
			$('#btnLogin').removeClass("disabled");
		}
	});
	
	// 패스워드 변경 키업 이벤트 
	$('#chgLoginId').keyup(function(event) {
		if ($.trim($("#chgLoginId").val()) == "") {
			$("#loginId").val("");
			$('#chgConfirm').addClass("disabled");
		} else if ($.trim($("#loginCurrentPw").val()) == "" || $.trim($("#loginNewPw").val()) == "" || $.trim($("#loginNewPwConfirm").val()) == "") {
			$('#chgConfirm').addClass("disabled");
		} else {
			$('#chgConfirm').removeClass("disabled");
		}
	});
	$('#loginCurrentPw').keyup(function(event) {
		if ($.trim($("#loginCurrentPw").val()) == "") {
			$("#loginCurrentPw").val("");
			$('#chgConfirm').addClass("disabled");
		} else if ($.trim($("#chgLoginId").val()) == "" || $.trim($("#loginNewPw").val()) == "" || $.trim($("#loginNewPwConfirm").val()) == "") {
			$('#chgConfirm').addClass("disabled");
		} else {
			$('#chgConfirm').removeClass("disabled");
		}
	});
	$('#loginNewPw').keyup(function(event) {
		if ($.trim($("#loginNewPw").val()) == "") {
			$("#loginNewPw").val("");
			$('#chgConfirm').addClass("disabled");
		} else if ($.trim($("#loginCurrentPw").val()) == "" || $.trim($("#chgLoginId").val()) == "" || $.trim($("#loginNewPwConfirm").val()) == "") {
			$('#chgConfirm').addClass("disabled");
		} else {
			$('#chgConfirm').removeClass("disabled");
		}
	});
	$('#loginNewPwConfirm').keyup(function(event) {
		if ($.trim($("#loginNewPwConfirm").val()) == "") {
			$("#loginNewPwConfirm").val("");
			$('#chgConfirm').addClass("disabled");
		} else if ($.trim($("#loginCurrentPw").val()) == "" || $.trim($("#loginNewPw").val()) == "" || $.trim($("#chgLoginId").val()) == "") {
			$('#chgConfirm').addClass("disabled");
		} else {
			$('#chgConfirm').removeClass("disabled");
		}
	});
	
	// 임시 비밀번호 신청 키업 이벤트
	$('#loginIdTemporary').keyup(function(event) {
		if ($.trim($("#loginIdTemporary").val()) == "") {
			$("#loginIdTemporary").val("");
			$('#chgIdTemporary').addClass("disabled");
		} else {
			$('#chgIdTemporary').removeClass("disabled");
		}
	});
});

function loginNoti(){
	$("#loginNoti").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function loginFail(){
	$("#loginFail").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function idChkPop(){
	$("#idChkPop").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold');
		$("#userId").focus();}
	});
}
function pwChkPop(){
	$("#pwChkPop").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold');
		$("#password").focus();}
	});
}
function goMain(){
	location.href = contextPath + '/main.do';
}
function goLogout(){
	location.href = contextPath + '/logout.do';
}
function pwChgApi(){ // 비밀번호 변경
	$("#pwConfirm").bPopup().close();
	
	var param = {
			userId : $("#chgLoginId").val()
			, password : $("#loginNewPwConfirm").val()
			, OldPassword : $("#loginCurrentPw").val()
			, mblId : "357174095821635"
	};
	
	controller.ajaxSend( {
		url : contextPath + '/login/pwdChangeApi.json'
		, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var rsltCd = result.result.rsltCd;
			var rsltMsg = result.result.rsltMsg;
			
			if (rsltCd == 000) { // 비밀번호 변경 000 정상
				$("#pwChgSuccTitle").text('비밀번호 변경 완료 안내');
	    		var pwSuccMsg = '<p class="txt">'+'비밀번호 변경이 완료되었습니다.<br>다시 로그인 해주세요.'+'</p>';
				$('#pwChgSuccMsg').html(pwSuccMsg);
				$("#pwChgSucc").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
			} else { // 100 실패, 102 아이디 혹은 패스워드 다름, 106 패스워드 형식 오류
	    		$("#pwTitle").text('비밀번호 변경 실패 안내');
	    		var pwMsg = '<p class="txt">'+'비밀번호 변경이 실패하였습니다.<br>다시 변경해주세요.'  +'</p>';
				$('#pwMsg').html(pwMsg);
	     		$("#pwValidPop").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
			}
		}
	});
}
function pwTempChgApi(){ // 임시 비밀번호 신청
	$("#pwTempConfirm").bPopup().close();

	var param = {
			userId : $("#loginIdTemporary").val()
			, mblId : "357174095821635"
	};
	
	controller.ajaxSend( {
		url : contextPath + '/login/pwTempChgApi.json'
		, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var rsltCd = result.result.rsltCd;
			var rsltMsg = result.result.rsltMsg;
			
			if (rsltCd == 000) { // 임시 비밀번호 신청 000 정상
//				$("#pwChgSuccTitle").text('임시 비밀번호 신청 완료 안내');
				var pwSuccTitle = "<strong class='pop-tit'>임시 비밀번호 신청<br> 완료 안내</strong>";
				$('#pwChgSuccTitle').html(pwSuccTitle);
				
	    		var pwSuccMsg = '<p class="txt">임시 비밀번호 신청이 완료되었습니다.<br>다시 로그인 해주세요.</p>';
				$('#pwChgSuccMsg').html(pwSuccMsg);
				$("#pwChgSucc").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
			} else { // 100 실패, 102 아이디 혹은 패스워드 다름, 106 패스워드 형식 오류
//				$("#pwTitle").text('임시 비밀번호 신청 실패 안내');
				var pwTitle = "<strong class='pop-tit'>임시 비밀번호 신청<br> 실패 안내</strong>";
				$('#pwTitle').html(pwTitle);
				
				var pwMsg = '<p class="txt">임시 비밀번호 신청이 실패하였습니다.<br>다시 변경해주세요.</p>';
				$('#pwMsg').html(pwMsg);
				$("#pwValidPop").bPopup({
					onOpen: function(){ $('body').addClass('bodyHold'); },
					onClose: function(){ $('body').removeClass('bodyHold'); }
				});
			}
		}
	});
}
function pwCancle(){
	$("#pwCancle").bPopup({ 
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function pwTempCancle(){
	$("#pwTempCancle").bPopup({ 
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
