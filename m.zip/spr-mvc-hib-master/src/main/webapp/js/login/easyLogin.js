var controller = $.extend(new $.CommonObj(), {
	eventInit : function() {
		$(document).on("click", "#btnLoginId", function() {
			if ($.trim($("#password").val()) == "") {
				pwChkPop();
				return;
			}
			var param = {
					userId : $("#userId").val()
					, password : $("#password").val()
					, easyYn : "on"
			};
			
            controller.ajaxSend( {
            	url : contextPath + '/login/apiLogin.json'
				, data : param
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var rsltCd = result.retApi.rsltCd;
					var rsltMsg = result.retApi.rsltMsg;
					var apiMsg = result.apiMsg;
					
					if (rsltCd == 000 || rsltCd == 001) { // 000 정상, 001 정상 (패스워드 종료일 7일이내)
						saveId($("#userId").val());
						if (rsltCd == 001) {
							var notiTxt = '<p class="txt">'+ apiMsg +'</p>';
							$('#loginNotiMsg').html(notiTxt);
							loginNoti(); // 로그인 공지
						} else {
							goMain();
						}
					} else { //100 실패
						var txt = '<p class="txt">'+ apiMsg +'</p>';
						$('#popMsg').html(txt);
						loginFail(); // 로그인 실패
					}
				}
            });
		});
	}
});

$(document).ready(function(){
	controller.init();
	
    // 로그인 버튼 키업 이벤트 
	$('#password').keyup(function(event) {
		if ($.trim($("#password").val()) == "") {
			$("#password").val("");
			$('#btnLoginId').addClass("disabled");
		} else {
			$('#btnLoginId').removeClass("disabled");
		}
	});
});

function pwChkPop(){
	$("#pwChkPop").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold');
		$("#password").focus();}
	});
}
function loginNoti(){
	$("#loginNoti").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function loginFail(){
	$("#loginFail").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function easyCancle(){
	$("#easyCancle").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function goMain(){
	location.href = contextPath + '/main.do';
}
function goMainCancle(){
	saveId(""); // 간편로그인 해제
	location.href = contextPath + '/logout.do';
}
