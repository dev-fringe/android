var controller = $.extend(new $.CommonObj(), {
	eventInit : function() {
		controller.ajaxSend({
			url : contextPath + '/main/mainNoti.json'
			, dataType : 'json'
			, type : 'post'
			, isBlock : true
			, isOverLap : true
			, successCall:function(result) {
				var today = result.mainReq.today;
				var cnt = result.mainNoti.length;
				
				for (var i=0; i<cnt; i++) {
					var notiId = "mainNoti_"+result.mainNoti[i].RNUM;
					var notiPopId = "mainNotiPop_"+result.mainNoti[i].RNUM;
					var notiDate = result.mainNoti[i].REGR_DH;
					var notiTitle = result.mainNoti[i].ANCMT_TITLE;
					var notiDesc = result.mainNoti[i].ANCMT_DESC;
					var notiToday = "notiToday_"+result.mainNoti[i].RNUM;
					
					var temp = notiDate.substring(0,4);
					temp += "-"+notiDate.substring(4,6);
					temp += "-"+notiDate.substring(6,8);
					
					// 공지사항 쿠키 확인
					var chkNoti = getCookie(notiId);
					if (chkNoti == 'end') {
						
					} else {
						var notiFrame = "<div id='"+notiPopId+"' class='pop-wp'><div class='pop-ct info'><header class='pop-header'><h3 class='pop-tit'>공지사항 안내</h3><button type='button' class='b-close' onclick='notiChk("+notiId+","+notiPopId+", "+notiId+");'><span class='hide'>닫기</span></button>" +
						"</header><section class='pop-noti'><h4 class='tit' id='notiTitle'>"+notiTitle+"</h4><p class='mt1 txR fc3' id='notiDate'>"+temp+"</p>" +
						"<div class='txt mt1' id='notiDesc'><div>"+notiDesc+"</div></div><div class='btn-wp'><ul class='colum'><li><button type='button' class='btn1 red b-close' onclick='notiChk("+notiId+","+notiPopId+");'><span>확인</span></button></li>" +
						"</ul></div><span class='chck1'><input type='checkbox' id='"+notiId+"' class='chkNoti' name='chkn' checked='checked'><label for='"+notiId+"'><span>오늘 하루 이 창을 더 이상 열지 않음</span></label>" +
						"</span></section></div></div>";
						
						$("#notiFrame").append(notiFrame);
					}
				}
				var nextPop = "mainNotiPop_"+cnt;
				
				if (cnt != 0) {
					if (cnt == 1) {
						$("#"+nextPop+"").bPopup({
							onOpen: function(){ $('body').addClass('bodyHold'); },
							onClose: function(){ 
							$('body').removeClass('bodyHold');
							}
						});
					} else {
						$("#"+nextPop+"").bPopup({
							onOpen: function(){ $('body').addClass('bodyHold'); },
							onClose: function(){ 
							$('body').addClass('bodyHold');
							}
						});
					}
				}
			}
		});
		
		// 상세 보기
		$(document).on("click", ".mainPrdDetailBtn", function() {
			var id = $(this).attr('id');
			var text = $(this).find('span').text();
			
			if (text == "상세 닫기") {
				var param = {"cd" : id};
				$("#"+id+"_detail").load(contextPath+'/mainDetailInfo.json', param, function(response, status, xhr) {
					var statusTxt = status;
					if (statusTxt == 'success') {
						var inner = response; // 성공
					}
				});
			}				
		});
	}
});

$(document).ready(function(){
	controller.init();

	// 메인 푸터
	$("#mainFooter").load(contextPath+'/mainFooter.json', function(response, status, xhr) {
		var statusTxt = status;
		if (statusTxt == 'success') {
			var inner = response; // 성공
		}
	});
}); // ready

function mainNoti(){ // 공지사항 팝업
	$("#mainNoti").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function notiChk(param, parameter, popX) { // 오늘 하루 이 창을 더 이상 열지 않음 체크박스
	var notiId = param.id;
	var notiPopId = parameter.id;
	var popX = popX;
	
	if ($('#'+notiId).is(':checked') == true) {
		if (popX == undefined) {
			setCookie(notiId, "end" , 1);
		}
	}
	
	var num = notiPopId.replace(/[^0-9]/g,"");
	var notiNum = parseInt(num)-1;
	var next = "#mainNotiPop_"+notiNum;
	
	if (notiNum != 0) {
		$('body').addClass('bodyHold');
	} else {
		$('body').removeClass('bodyHold');
	}
	$(next).bPopup();
}
function logout(){ // 로그아웃 팝업
	var easyYn = $("#easyYn").val();
	if (easyYn == "") {
		$("#logout").bPopup({
			onOpen: function(){ $('body').addClass('bodyHold'); },
			onClose: function(){ $('body').removeClass('bodyHold'); }
		});
	} else {
		$("#logoutEasy").bPopup({
			onOpen: function(){ $('body').addClass('bodyHold'); },
			onClose: function(){ $('body').removeClass('bodyHold'); }
		});
	}
}
function goLogout(){
	if($("#easyPop").is(":checked")) { // 간편로그인 삭제 체크
		saveId("");
		location.href = contextPath + '/logout.do';
	} else {
		location.href = contextPath + '/easyLogout.do';
	}
}
function setCookie(name, value, expiredays) { // expiredays 의 새벽 00:00:00 까지 쿠키 설정 
	var todayDate = new Date();
	
	todayDate = new Date(parseInt(todayDate.getTime() / 86400000) * 86400000 + 54000000);  
	 
	if (todayDate > new Date()) {
		expiredays = expiredays - 1;  
	}
	todayDate.setDate(todayDate.getDate() + expiredays);   
	document.cookie = name + "=" + encodeURI(value) + "; expires=" + todayDate.toGMTString() + "; path=/;";
}  
function getCookie(name) {
   var cookieName = name + "=";
   var x = 0;
   while ( x <= document.cookie.length ) {
      var y = (x+cookieName.length); 
      if ( document.cookie.substring( x, y ) == cookieName) {
         if ((lastChrCookie=document.cookie.indexOf(";", y)) == -1) 
            lastChrCookie = document.cookie.length;
         return decodeURI(document.cookie.substring(y, lastChrCookie));
      }
      x = document.cookie.indexOf(" ", x ) + 1; 
      if ( x == 0 )
         break; 
      } 
   return "";
}
function deleteCookie(cookieName) {
    var expireDate = new Date();
    expireDate.setDate(expireDate.getDate() - 1);
    document.cookie = cookieName + "= " + "; expires=" + expireDate.toGMTString();
}
