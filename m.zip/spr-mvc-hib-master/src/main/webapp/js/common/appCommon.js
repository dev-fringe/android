//네이티브 함수 호출
function callNative(param) {
	var ifName = param.ifName;
	var ifData = param.ifData;

	try {
		if (ifName == 'appClose') { // APP 종료
			eval(window.Android.callApi("{\"api\":\"10\",\"call_back\":\"\",\"input\":{}}")); 
		} else if (ifName == 'callBrowser') { // 외부 브라우저 URL
			eval(window.Android.callApi("{\"api\":\"300\",\"call_back\":\"\",\"input\":{\"url\":\""+ifData+"\"}}"));
		} else { // saveId 사용자 ID 저장
			eval(window.Android.callApi("{\"api\":\"101\",\"call_back\":\"\",\"input\":{\"user_id\":\""+ifName+"\"}}"));
		}
	} catch (e) {
		
	}
}

function appClose() {
	callNative({
		ifName : 'appClose'
	});
}
function saveId(param) {
	callNative({
		ifName : param 
	});
}
function callBrowser(param) {
	callNative({
		ifName : 'callBrowser',
		ifData : param
	});
}
function appBackButton() {
	var curUri = window.location.pathname;
	//앱종료 - 인트로,로그인,메인
	//기타화면에서는 메인으로 이동
	if("/scs/api/intro.json" == curUri
			|| "/scs/login.do" == curUri 
			|| "/scs/easyLogin.do" == curUri 
			|| "/scs/main.do" == curUri
	){
		$("#Confirm6Title").text("App 종료 안내");
		$("#Confirm6Text").html("App을 종료하시겠습니까?");
		$("#Confirm6BtnName").text("App 종료");
	} else {
		$("#Confirm6BtnName").text("확인");
	}
	Confirm6();
}

$(document).on("click", "#Confirm6BtnName", function() {
	var getTitle = $("#Confirm6Title").text();
	if(getTitle == 'App 종료 안내'){
		appClose();
	} else {
		location.href='/scs/main.do';
	}
});

function Confirm6(){
	$("#Confirm6").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
