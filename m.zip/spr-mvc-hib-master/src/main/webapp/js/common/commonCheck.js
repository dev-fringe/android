
/**
 * 현재시간 Get
 * @returns nowTime 현재시간
 */
function fn_getNowDateTime() {
    var today = new Date();
    var year = today.getFullYear();
    var month = (today.getMonth() + 1);
    var day = today.getDate();
    var hour = today.getHours();
    var min = today.getMinutes();
    var second = today.getSeconds();
    var millisecond = today.getMilliseconds();

    if (parseInt(month, 10) < 10) {
        month = "0" + month;
    	
    }
    if (parseInt(day, 10) < 10) {
        day = "0" + day;
    }
    if (parseInt(hour, 10) < 10) {
        hour = "0" + hour;
    }
    if (parseInt(min, 10) < 10) {
        min = "0" + min;
    }
    if (parseInt(second, 10) < 10) {
        second = "0" + second;
    }
    if (parseInt(millisecond, 10) < 10) {
        millisecond = "00" + millisecond;
    } else {
        if (parseInt(millisecond, 10) < 100) {
            millisecond = "0" + millisecond;
        }
    }

    var nowTime = String(year) + String(month) + String(day) + String(hour) + String(min) + String(second);

    return nowTime;
}

/** =============================================
Return : event.returnValue = boolean
Comment: 키입력시 숫자만 입력 받게 한다.
Usage  : onKeyDown="fn_onKeyOnlyNumber();"
---------------------------------------------- */
function fn_onKeyOnlyNumber()
{
	var sValid = "0123456789";

	var sValue = event.srcElement.value;
		  sValue = sValue.replace(/,/gi,"");
	var iKey = event.keyCode;
	var isShift = event.shiftKey;
	var isMove = false;
	var isCut  = false
	var isTrue = true;

	event.srcElement.style.imeMode = "inactive"; //style.imeMode(active:한글, inactive:영문) 그러나, 동적으로는 반영 안된다. (html tag의 style="IME-MODE:inactive;" 로 지정하여야만..)

	var sReturnValue = "";
	for (var ii=0; ii < sValue.length; ii++) {
		if (sValid.indexOf(sValue.substring(ii, ii+1)) >= 0) {
			sReturnValue = sReturnValue + sValue.substring(ii, ii+1);
		}
	}
	if ( (iKey == 37 || iKey == 38 || iKey == 39 || iKey == 40) ||
		 (iKey == 13 || iKey == 8  || iKey == 46 || iKey == 9  || iKey == 16  || isShift) || (iKey >= 48 && iKey <= 57) || (iKey >= 95 && iKey <= 105)) {
		for (var ii=0; ii < sValue.length; ii++) {
			if (sValid.indexOf(sValue.substring(ii, ii+1)) < 0) {
				event.returnValue = false;
				isCut  = true;
				isTrue = false;
				break;
			}
		}
	} else {
		event.returnValue = false;
		isTrue = false;
	}

	if (isCut || isTrue == false)
		event.srcElement.value = sReturnValue;

	if (iKey == 13) {
		event.keyCode = 0;
		return sReturnValue;
	} else {
		return sReturnValue;
	}
}





//fn_checkMblPhone 이동전화번호 유효성 체크
//==> 소스 확인해야함
//-- 핸드폰번호
//==> 부분적으로 입력되어 완전하지 않은 경우
//"핸드폰번호가 잘못 입력되었습니다."


//fn_checkPhone 전화번호 유효성 체크
//-- 유선전화번호
//==> 부분적으로 입력되어 완전하지 않은 경우
//"유선전화번호가 잘못 입력되었습니다."
/** =============================================
Return : boolean
Comment: 주민등록번호 체크
Usage  : if (fn_isJuminByVal(theForm.jumin_biz_no1.value, theForm.jumin_biz_no2.value) == false) { fn_focus(theForm.jumin_biz_no1); }
---------------------------------------------- */
function fn_isJuminByVal(strJumin1, strJumin2)
{
	var isTrue = false;
	var sJumin1 = strJumin1 + "";
	var sJumin2 = strJumin2 + "";
	if(strJumin2.charAt(0) == "1" || strJumin2.charAt(0) == "2" || strJumin2.charAt(0) == "3" || strJumin2.charAt(0) == "4"){
		//내국인
		isTrue = fn_isJumin(sJumin1 + sJumin2);
	}else{
		//외국인
		isTrue = fn_isJuminFo(sJumin1 + sJumin2);
	}
	return isTrue;
}

/** =============================================
Return : boolean
Comment: 주민등록번호 체크
Usage  : fn_isJuminByVal(strJumin1, strJumin2) 참조
---------------------------------------------- */

function fn_isJuminByObj(objJumin1, objJumin2) {
	var isTrue = false;
	var sJumin1 = objJumin1.value + "";
	var sJumin2 = objJumin2.value + "";
	isTrue = fn_isJumin(sJumin1 + sJumin2);

	if ( !isTrue ) {
		fn_focus(objJumin1);
	}

	return isTrue;
}
/*
 * 외국인 주민번호 체크
 * */
function fn_isJuminFo(sJumin) { 
    var sum=0; 
    var odd=0; 
    buf = new Array(13); 
    for(i=0; i<13; i++) { buf[i]=parseInt(sJumin.charAt(i)); } 
    odd = buf[7]*10 + buf[8]; 
    if(odd%2 != 0) { return false; } 
    if( (buf[11]!=6) && (buf[11]!=7) && (buf[11]!=8) && (buf[11]!=9) ) { 
            return false; 
    } 
    multipliers = [2,3,4,5,6,7,8,9,2,3,4,5]; 
    for(i=0, sum=0; i<12; i++) { sum += (buf[i] *= multipliers[i]); } 
    sum = 11 - (sum%11); 
    if(sum >= 10) { sum -= 10; } 
    sum += 2; 
    if(sum >= 10) { sum -= 10; } 
    if(sum != buf[12]) { return false } 
    return true; 
}
/*
 * 내국인
 * */
function fn_isJumin(sJumin)
{

	// 주민등록번호로 생년월일 추출
	var sBirth = fn_getBirthByVal(sJumin.substring(0, 6), sJumin.substring(6, 13));
	
	// 주민등록번호로 추출한 생년월일이 정상이고, "1111111111111" 이 아니면
	// **주민등록 체크섬 검사**
	if (sBirth.length == 8 && fn_isDate(sBirth) && sJumin != "1111111111111" ) {
		// 주민등록 체크섬 검사 ...
		var sJuminChk = new String("234567892345")
		var iJuminSum = 0;
		var sJuminLst = "";
		for (ii = 0; ii < 13; ii++) {
			iJuminSum = iJuminSum + (sJumin.substring(ii, ii+1) * sJuminChk.substring(ii, ii+1));
		}

		sJuminLst = (11 - (iJuminSum % 11)) % 10;

		if (sJuminLst == sJumin.substring(12, 13) ) {
			isTrue = true;
		} else {
			isTrue = false;
		}
	} else {
		isTrue = false;
	}

	return isTrue;
}



/** =============================================
Return : boolean
Comment: 입력된 객체이름에 해당하는 객체의 값의 앞/뒤 공백을 제거한 후  
      모든 객체의 길이가 0 이거나, 모든 객체의 길이가 0 아니면 true, 
      값이 일부만 있으면 false
Usage  : fn_isNotNullByVal() 참조
---------------------------------------------- */

function fn_isAllorNotNullByObjName()
{
	var isTrue = true;
	var checkNullCnt=0;
	var checkNotNullCnt=0;
	var sStr = "";
	
	for (var ii=0; ii < arguments.length; ii++) {
		obj = getObj(arguments[ii]);
		if (obj == null || typeof(obj) == "undefined") {
			if (typeof(arguments[ii]) == "object") {
				if (arguments[ii].id != null && arguments[ii].id != "") {
					obj = document.getElementById(arguments[ii].id);
				} else {
					obj = document.getElementsByName(arguments[ii].name)[0];
				}
			} else {
				obj = document.getElementsByName(arguments[ii])[0];
			}
		}
		
		sStr = fn_trim(obj.value);
		if (sStr == "" || sStr == "null" || sStr == "undefined") {
			++checkNullCnt;
		}else{
			++checkNotNullCnt;
		}		
	}	
	
	if(checkNullCnt == arguments.length || checkNotNullCnt == arguments.length ){
		isTrue = true;
	}else{
		isTrue = false;
	}
	
	return isTrue;
}



/** =============================================
Return :
Comment: 주민등록번호로 생일과 성별을 설정한다. 
      (성별의 경우 select 또는 radio type 을 지원, select 사용을 권장)
Usage  : 주민등록번호 2번째 객체의 onBlur="fn_setBirthSexFromJumin(this.form.jumin_biz_no1, this.form.jumin_biz_no2, this.form.dt_bir1, this.form.dt_bir2, this.form.dt_bir3, this.form.sex_cd);"
---------------------------------------------- */

function fn_setBirthSexFromJumin(objJumin1, objJumin2)
{
	var sGenderMan    = "M";
	var sGenderWoman  = "F";
	var iGenderMan    = 0;
	var iGenderWoman  = 1;
	var sYearPreCode = "";
	var sGender  = ""
	var iGender  = -1;
	var sJumin1 = objJumin1;//.value;
	var sJumin2 = objJumin2;//.value;
	var sBirth = fn_getBirthByVal(sJumin1, sJumin2);
	// 01.주민등록번호가 다 입력되지 않았거나
	// 02.주민등록번호 뒷자리의 첫자가 비정상이면 return;
	if (sBirth.length != 8) {
		return;
	}

	// 11.생일 설정
	//    (생일이 등록되어 있지 않거나, 비정상적인 날짜인 경우에만)
	/*if (fn_trim(objBirthYear.value) + fn_trim(objBirthMonth.value) + fn_trim(objBirthDay.value) == "" ||
		fn_isDateByObj(objBirthYear, objBirthMonth, objBirthDay) == false) {
		objBirthYear.value  = sBirth.substring(0, 4);
		objBirthMonth.value = sBirth.substring(4, 6);
		objBirthDay.value   = sBirth.substring(6, 8);
	}*/

	// 12.성별 설정
	sYearPreCode = sJumin2.substring(0,1);
	if (sYearPreCode % 2 == 1) {
		sGender = sGenderMan;
		iGender = iGenderMan;
	} else {
		sGender = sGenderWoman;
		iGender = iGenderWoman;
	}
	/*
	if ( objGender != null && (objGender.type == "select-one" || objGender.type == "select-multiple") ) {
		// 성별이 select 객체이면
		objGender.options.selectedIndex = iGender + (objGender.options.length - 2);
	} else if ( (objGender[0] != null && objGender[1] != null) && (objGender[0].type == "radio" && objGender[1].type == "radio") ) {
		// 성별이 input type="radio" 객체이면
		objGender[(iGender+1) % 2].checked = false;
		objGender[iGender].checked = true;
	}*/
	return iGender;
}

/** =============================================
Return :
Comment: 주민등록번호로 미성년여부를 판별한다.
Usage  : onBlur="fn_isAdultByObj(objJumin1, objJumin2);"
---------------------------------------------- */
function fn_isAdultByValue(strJumin1, strJumin2)
{
	var isTrue = false;
	var sJumin1 = strJumin1;
	var sJumin2 = strJumin2;
	var sBirth = fn_getBirthByVal(sJumin1, sJumin2);


	if (sBirth.length == 8) {
		var dNow   = new Date();

                // SkyLife-CM-2013-075 성년 기준연령 변경에 따른 전산 변경 개발요청 azngnus
                //var dLimit = new Date(dNow.getYear()-20, dNow.getMonth(), dNow.getDate()); // 미성년자 만 20세
                var dLimit = new Date(dNow.getFullYear()-19, dNow.getMonth(), dNow.getDate()); // 미성년자 만 19세
                
		var iYear = dLimit.getFullYear();
		
		if (iYear <= 99)
			iYear = 1900 + iYear;
		var iMonth = dLimit.getMonth() + 1;
		var iDay   = dLimit.getDate()-1;
		var sLimit = fn_setFillzeroByVal(iYear,  4)
				   + fn_setFillzeroByVal(iMonth, 2)
				   + fn_setFillzeroByVal(iDay,   2);
				  
		
		if (sBirth > sLimit) {
			isTrue = true;
		}
	} else {
		// 주민등록번호가 다 입력되지 않았거나 주민등록번호 뒷자리의 첫자가 비정상이면 return true;
		isTrue = true;
	}

	return isTrue;
}
//===============================================

/** =============================================
Return :
Comment: 주민등록번호로 생일 추출.
Usage  : sBirth = fn_getBirthdayByVal(sJumin1, sJumin2);
---------------------------------------------- */

function fn_getBirthByVal(sJumin1, sJumin2)
{
	var isTrue = true;
	var sYearPreCode = "";
	var sYearBase = "";
	var sBirth = "";

	// 01.주민등록번호가 다 입력되지 않았으면 return;
	if ( sJumin1.length != 6 || sJumin2.length != 7 || isNaN(sJumin1) || isNaN(sJumin2) ) {
		return "";
	}

	// 02.주민등록번호 뒷자리의 첫자가 9/0:1800, 1/2:1900, 3/4:2000 아니면 return;
	sYearPreCode = sJumin2.substring(0,1);
	if (sYearPreCode == "9" || sYearPreCode == "0") {
		sYearBase = "18";
	} else if (sYearPreCode == "1" || sYearPreCode == "2") {
		sYearBase = "19";
	} else if (sYearPreCode == "3" || sYearPreCode == "4") {
		sYearBase = "20";
	} else if (sYearPreCode == "5" || sYearPreCode == "6") {
		sYearBase = "19";
	} else if (sYearPreCode == "7" || sYearPreCode == "8") {
		sYearBase = "20";
	}else {
		return "";
	}

	// 11.생일 설정
	sBirth = sYearBase + sJumin1.substring(0, 2) + sJumin1.substring(2, 4) + sJumin1.substring(4, 6);

	return sBirth;
}



/** =============================================
Return : boolean
Comment: 날짜 유효성 체크(분리된 objYear, objMonth, objDay 객체) ;; 유효한 경우 각 객체의 값 설정(년도: 4자리, 월/일: 2자리)
Usage  :
---------------------------------------------- */

function fn_isDateByObj(objYear, objMonth, objDay)
{
	var isTrue = false;

	isTrue = fn_isYearMonthDay(objYear.value, objMonth.value, objDay.value);

	if ( isTrue && objYear.value != "" && objMonth.value != "" && objDay.value != "") {
		objYear.value  = fn_setFillzeroByVal(objYear.value,  4);
		objMonth.value = fn_setFillzeroByVal(objMonth.value, 2);
		objDay.value   = fn_setFillzeroByVal(objDay.value,   2);
	}

	return isTrue;
}


/** =============================================
Return : boolean
Comment: 날짜 유효성 체크(분리된 yyyy, mm, dd 값)
Usage  :
---------------------------------------------- */
function fn_isYearMonthDay(yyyy, mm, dd)
{
	var isTrue  = false;

	var iMaxDay = fn_MaxdayYearMonth(yyyy, mm);

	if ( yyyy == "" && mm == "" && dd == "" ) {
		isTrue = true;
	} else {
		if ( (yyyy >= 1901) && (yyyy <= 9999) &&
			 (mm   >= 1)    && (mm   <= 12) &&
			 (dd   >= 1)    && (dd   <= iMaxDay) )
			isTrue = true;
	}

	return isTrue;
}
//===============================================
/** =============================================
Return : boolean
Comment: 날짜 유효성 체크(분리된 yyyy, mm)
Usage  :
---------------------------------------------- */
function fn_isYearMonth(yyyy, mm)
{
	var isTrue  = false;

	var iMaxDay = fn_MaxdayYearMonth(yyyy, mm);

	if ( yyyy == "" && mm == "" && dd == "" ) {
		isTrue = true;
	} else {
		if ( (yyyy >= 1901) && (yyyy <= 9999) &&
			 (mm   >= 1)    && (mm   <= 12) 
			 )
			isTrue = true;
	}

	return isTrue;
}

/** =============================================
Return : int (해당 년,월의 날수)
Comment: 입력받은 년,월의 최대 일을 구한다.
Usage  :
---------------------------------------------- */
function fn_MaxdayYearMonth(yyyy, mm)
{
	var monthDD = new Array(31,28,31,30,31,30,31,31,30,31,30,31);

	var iMaxDay = 0;

	if ( fn_isLeafYear(yyyy) ) {
		monthDD[1] = 29;
	}
	iMaxDay = monthDD[mm - 1];

	return iMaxDay;
}
/** =============================================
Return : boolean
Comment: 입력받은 년도가 윤년이면 true
Usage  :
---------------------------------------------- */
function fn_isLeafYear(YYYY)
{
	if ( ( (YYYY%4 == 0) && (YYYY%100 != 0) ) || (YYYY%400 == 0) ) {
		return true;
	}
	return false;
}
/** =============================================
Return : boolean
Comment: 날짜 유효성 체크(병합된 yyyymmdd 값)
Usage  :
---------------------------------------------- */
function fn_isDate(yyyymmdd)
{
	var isTrue  = false;
	//console.log("fn_isDate >" + yyyymmdd);
	 // + fn_isNumStr(yyyymmdd)
	if ( yyyymmdd.length == 8 && fn_isNumStr(yyyymmdd) ) {
		var yyyy = eval(yyyymmdd.substring(0,4));
		var mm   = eval(yyyymmdd.substring(4,6));
		var dd   = eval(yyyymmdd.substring(6,8));

		if ( fn_isYearMonthDay(yyyy,mm,dd) )
			isTrue = true;
	} else if (yyyymmdd == "") {
		isTrue = true;
	}

	return isTrue;
}

/** =============================================
Return : boolean
Comment: 법인번호 검증
Usage  : fn_isBupinNumber(Bupin_Num)
---------------------------------------------- */

function fn_isBupinNumber(Bupin_Num)
{
 var Jv_isBupIn = false;
 var Jv_Sum = 0;
 var Jv_chkDigit = -1;
 var Jv_mskDigit = new Array(13);

 if ( Bupin_Num.length == 13 &&
      fn_isNumStr(Bupin_Num)
    )
 {
     for ( idx = 0; idx < 12; idx++ )
     {
         if ( (idx % 2 ) == 0 )      // in case of even number
             Jv_mskDigit[idx] = parseInt( Bupin_Num.charAt(idx) );
         else
             Jv_mskDigit[idx] = parseInt( Bupin_Num.charAt(idx) ) * 2;

         Jv_Sum += Jv_mskDigit[idx];
     }

     Jv_chkDigit = (10 - (Jv_Sum % 10)) % 10;
     if ( Jv_chkDigit == Bupin_Num.charAt(12) )
         Jv_isBupIn = true;
 }

 return Jv_isBupIn;
}
/** =============================================
Return : boolean
Comment: 숫자로 구성된 문자열 체크
Usage  :
---------------------------------------------- */
function fn_isNumStr(no)
{
	var    i;
	var    str = null;

	str = new String(no);

	if(str == null || str.length == 0)
		return false;

	for(ii = 0; ii < str.length; ii++)
		if(!fn_isInt(str.charAt(ii)))
			return false;
	return true;
}
/** =============================================
Return : boolean
Comment: 한 글자가 숫자인지 체크
Usage  :
---------------------------------------------- */
function fn_isInt(value)
{
	var   j;
	var   _intValue   = '0123456789';

	for(j=0;j<_intValue.length;j++)
		if(value == _intValue.charAt(j)) {
			return true;
		}
	return false;
}

/** =============================================
Return : boolean
Comment: 사업자등록번호 체크
Usage  :
---------------------------------------------- */

function fn_isBusiNoByValue(strNo)
{
	if ( strNo == null || strNo == "")
		return true;

	if ( !fn_isNumStr(strNo) || strNo.length != 10)
		return false;

	IDtot = 0;
	IDAdd = "13713713";

	for(ii = 0; ii < 8 ; ii++)
		IDtot = IDtot + strNo.substring(ii, ii+1) * IDAdd.substring(ii, ii+1);

	IDtot = IDtot + Math.floor(( strNo.substring(8, 9) * 5) / 10) + ((strNo.substring(8, 9) * 5) % 10);
	IDtot = 10 - (IDtot % 10);

 if (IDtot == 10) IDtot = 0;

	if (eval(strNo.substring(9,10))== IDtot)
		return true;
	else
		return false;
}


/** =============================================
Return : boolean
Comment: 사업자등록번호 체크
Usage  :
---------------------------------------------- */
function fn_isBizRegNoByObj(objBusino)
{
	return fn_isBusiNoByValue(objBusino.value);
}
//===============================================




/** =============================================
Return : boolean
Comment: 전화번호(DDD, 국번, 번호 등을 입력 받아 유효한 전화번호인경우 각 번호를 4자리로 채워 맞춘다
Usage  :
---------------------------------------------- */

function fn_isPhoneByObj(objAreaNo, objCallNo, objTelNo, bFillZeros)
{
	var isTrue = false;
	var sAreaNo = objAreaNo.value + "";
	var sCallNo = objCallNo.value + "";
	var sTelNo  = objTelNo.value  + "";

	if (sAreaNo == "" && sCallNo == "" && sTelNo == "") {
		isTrue = true;
	} else {

		// **주의**
		// parseInt : 첫 문자가 숫자가 아닌('0'포함) 경우 NaN을 리턴
		// isNaN    : 정수값이 아니면 true
		// 위의 이러한 사항 때문에 parseInt(문자형숫자값 * 1)를 먼저 수행해야만 한다.

		var iAreaNo = parseInt(sAreaNo * 1);
		var iCallNo = parseInt(sCallNo * 1);
		var iTelNo  = parseInt(sTelNo  * 1);

		if ( ( !isNaN(iAreaNo) && !isNaN(iCallNo) && !isNaN(iTelNo) ) &&
			 ( iAreaNo ==  2 /* 서울 */ ||
			   iAreaNo == 31 /* 경기 */ ||
			   iAreaNo == 32 /* 인천 */ ||
			   iAreaNo == 33 /* 강원 */ ||
			   iAreaNo == 41 /* 충남 */ ||
			   iAreaNo == 42 /* 대전 */ ||
			   iAreaNo == 43 /* 충북 */ ||
			   iAreaNo == 51 /* 부산 */ ||
			   iAreaNo == 52 /* 울산 */ ||
			   iAreaNo == 53 /* 대구 */ ||
			   iAreaNo == 54 /* 경북 */ ||
			   iAreaNo == 55 /* 경남 */ ||
			   iAreaNo == 61 /* 전남 */ ||
			   iAreaNo == 62 /* 광주 */ ||
			   iAreaNo == 63 /* 전북 */ ||
			   iAreaNo == 64 /* 제주 */ ||
			   iAreaNo == 11 /* 011  */ ||
     	   iAreaNo == 13 /* 013  */ ||
			   iAreaNo == 16 /* 016  */ ||
			   iAreaNo == 17 /* 017  */ ||
			   iAreaNo == 18 /* 018  */ ||
			   iAreaNo == 505 /* 데이콤  */ ||
			   iAreaNo == 19 /* 019  */ ) &&
			 ( iCallNo >= 10 && iCallNo <= 9999 )) {
			isTrue = true;

			if (bFillZeros || bFillZeros == null) {
				objAreaNo.value = fn_setFillzeroByVal( objAreaNo.value, 4 );
				objCallNo.value  = fn_setFillzeroByVal( objCallNo.value, 4 );
				objTelNo.value  = fn_setFillzeroByVal( objTelNo.value,  4 );
			} else {
				objAreaNo.value = "0"+ iAreaNo;
			}
		}
	}

	return isTrue;
}


/** =============================================
Return : boolean
Comment: E-mail 주소 체크 함수
Usage  :
---------------------------------------------- */
function fn_isEmail(email_addr)
{
	if (email_addr == "") return false;

	var t = email_addr;

	var Alpha = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	var Digit = '1234567890';
	var Symbol='_-';
	var check = '@.' + Alpha + Digit + Symbol;

	for (i=0; i < t.length; i++)
		if(check.indexOf(t.substring(i,i+1)) < 0)    {
			return false;
		}

	var check = '@';
	var a = 0;
	for (i=0; i < t.length; i++)
		if(check.indexOf(t.substring(i,i+1)) >= 0)    a = i;

	var check = '.';
	var b = 0;

	for (i=a+1; i < t.length; i++)
		if(check.indexOf(t.substring(i,i+1)) >= 0)  b = i;

	if (a != 0 && b != 0 && b!=t.length-1 ) {
		return true;
	} else {
		return false;
	}
}

/** =============================================
Return : String
Comment: sVal의 길이를 iLen으로 "0"으로 채워 맞춘 값을 리턴
Usage  :
---------------------------------------------- */

function fn_setFillzeroByVal(sVal, iVal)
{
	sStr = sVal + "";

	for (ii = sStr.length; ii < iVal; ii++) {
		sStr =  "0" + sStr;
	}
	return sStr;
}


//주민번호 마스킹
function fn_maskJumin(str)
{
	return fn_maskString(str,'XXXXXXi i-i *******');
}
//은행 계좌 번호 마스킹
function fn_maskBankNo(str)
{
	if(fn_isNull(str) ) return '';
	if(str.length < 5) return str;
	return fn_maskString(str,'XXXXXr*');
}

//masking을 한다.
//마스킹 문자는 
//'X' : 원본문자열을 복사한다. 
//'i?' : ? 위치의문자를 끼워넣기 한다.
//'r?' : ? 위치의문자를 끝까지 반복한다.
//그외 : 마스킹문자로 덮어쓴다.
//ex : fn_maskString('7007211122333','XXXXXXi i-i *******') 의 결과는 '700721 - *******' 이다.
//ex : fn_maskString('7007211122333','XXXXXXi i-i r*') 의 결과는 '700721 - *******' 이다.
function fn_maskString(str,mask)
{
	if(fn_isNull(str) ) return '';
	var idx = 0;
	var ret = '';
	for(var i = 0 ; i < mask.length && idx < str.length ; i ++)
	{
		if(mask[i] == 'X')
		{
			ret += str[idx ++ ];
		}
		else if(mask[i] == 'i')
		{
			i ++;
			ret += mask[i];
		}
		else if(mask[i] == 'r')
		{
			i ++;
			ret += mask[i];
			i --;
			i --;
			idx ++;
		}
		else
		{
			ret += mask[i];
			idx ++;
		}
	}
	return ret;
}

/** =============================================
Return : boolean
Comment: 주민등록번호 체크 (메시지 제외 ITV팝업에서 사용)
Usage  : fn_isJuminByVal(strJumin1, strJumin2) 참조
---------------------------------------------- */
function fn_isJuminByObjWithoutMsg(objJumin1, objJumin2)
{
	var isTrue = false;
	var sJumin1 = objJumin1.value + "";
	var sJumin2 = objJumin2.value + "";

	isTrue = fn_isJuminWithoutMsg(sJumin1 + sJumin2);

	if ( !isTrue ) {
		fn_focus(objJumin1);
	}

	return isTrue;
}


/** =============================================
Return : boolean
Comment: 주민등록번호 체크
Usage  : if (fn_isJumin(theForm.jumin_biz_no1.value + theForm.jumin_biz_no2.value) == false) { fn_focus(theForm.jumin_biz_no1); }
---------------------------------------------- */
function fn_isJuminWithoutMsg(sVal)
{
	var isTrue    = false;
	var isConfirm = false;
	var sJumin = fn_trim(sVal);

	if (sJumin == null || sJumin == "") {
		// 값이 없으면: true;
		return true;
	} else if (sJumin.length != 13) {
		// 13자리가 아니면 false;
		alert("주민등록번호는 앞, 뒤 포함 13자리 입니다.\n\n입력자료를 확인하세요!");
		return  false;
	} else {
		// 숫자가 아닌것이 있으면: false;
		for (ii = 0; ii < sJumin.length; ii++) {
			if (sJumin.substring(ii, ii+1) < "0" || sJumin.substring(ii, ii+1) > "9") {
				alert("주민등록번호에 숫자가 아닌 문자값이 입력되었습니다.\n\n입력자료를 확인하세요!");
				return false;
			}
		}
	}

	// **************************************************
	// 이제부터 검사 ..
	// **************************************************

	// 주민등록번호로 생년월일 추출
	var sBirth = fn_getBirthByVal(sJumin.substring(0, 6), sJumin.substring(6, 13));
	// 주민등록번호로 추출한 생년월일이 정상이고, "1111111111111" 이 아니면
	// **주민등록 체크섬 검사**
	if (sBirth.length == 8 && fn_isDate(sBirth) &&
		sJumin != "1111111111111" ) {
		// 주민등록 체크섬 검사 ...
		var sJuminChk = new String("234567892345")
		var iJuminSum = 0;
		var sJuminLst = "";
		for (ii = 0; ii < 13; ii++) {
			iJuminSum = iJuminSum + (sJumin.substring(ii, ii+1) * sJuminChk.substring(ii, ii+1));
		}

		sJuminLst = (11 - (iJuminSum % 11)) % 10;

		if (sJuminLst == sJumin.substring(12, 13) ) {
			isTrue = true;
		} else {
			isTrue = false;
		}
	} else {
		isTrue = false;
	}

	return isTrue;
}

/** =============================================
Return :
Comment: 인수로 받은 객체로 포커스를 이동한다.
Usage  : onKeyPress="fn_focus(NextObj, isNextObjSelection)"
---------------------------------------------- */
function fn_focus(objTo, bSelection)
{
	// 속성: .disabled, .readonly, .enabled, .visible
	// 속성이 지정되지 않은 경우를 주의할것! 2001-02-10
	if ( ((objTo.readonly == null) || (objTo.readonly != null && objTo.readonly == false)) &&
		 ((objTo.disabled == null) || (objTo.disabled != null && objTo.disabled == false)) &&
		 ((objTo.visible  == null) || (objTo.visible  != null && objTo.visible  == true )) &&
		 ((objTo.enabled  == null) || (objTo.enabled  != null && objTo.enabled  == true )) ) {
		objTo.focus();

		if ( (bSelection == null || (bSelection != null && bSelection == true)) &&
			 (objTo.isTextEdit) )
			objTo.select();
	}
	return;
}


/** =============================================
Return : string phoneNum ( "" or null : 오류, else 정상)
Comment: 이동전화번호 check : nChkType ="1"
Usage  : bResult = fn_checkMblPhone(szType, szPhone, szPhone.length);
20070713 추가 kjpark93
---------------------------------------------- */
function fn_checkMblPhone(nChkType, szdata, nSize)
{
	
	pSize = nSize; //Loop Length
	phoneNum = szdata; //Phone Number
	fstPhoneNum = ""; //Phone Number
	tmpPhoneNum = szdata;

	//포맷에 맞춤:숫자가 아닌 값 삭제
	for (i = 0; i < pSize; i++)
	{
		if (tmpPhoneNum.charAt(i) < '0' || tmpPhoneNum.charAt(i) > '9')
		{

			pSize--;

			fstPhoneNum = tmpPhoneNum.substring(0,i);
			tmpPhoneNum = strDeleteAt(fstPhoneNum, tmpPhoneNum , pSize, i);

			i--;
		}
	}

	phoneNum = tmpPhoneNum;
	//alert(phoneNum);
	if(tmpPhoneNum.substring(0,1)=="0")
	{

		//포맷에 맞춤:번호 앞 두자리가 00 이면 한자리 삭제
		if(tmpPhoneNum.substring(1,2)== "0")
		{
			tmpPhoneNum = strDeleteAt(tmpPhoneNum.substring(0,1), tmpPhoneNum , tmpPhoneNum.length, 1);

			phoneNum = tmpPhoneNum;
		}
	}
	else
	{
		//번호가 0으로 시작하지 않으면 에러
		return phoneNum = "" ;
	}

	pSize = tmpPhoneNum.length;

	var arrPhone = new Array();

	for (i = 0; i < pSize; i++) {
		arrPhone[i] = parseInt(tmpPhoneNum.substring(i,i+1));
		//alert(arrPhone[i]);
	}


	if (arrPhone[1] == 1) {

		if(pSize < 10 || nChkType == -1)
		{
			/*총 길이가 10보다 작거나 일반전화유효성 체크이면 에러*/
			return phoneNum = "" ;
		}

		/*번호가 011일 경우*/
		if(arrPhone[2] == 1)
		{

			if(arrPhone[3] == 9 || arrPhone[3] == 1)
			{
				if(pSize != 11)
				{
					//9 또는 1로 시작되는 국번의 번호 자리수는 항상 11자리(011-912-1234,011-123-1234:에러)
					return phoneNum = "" ;
				}
			}
			else if(arrPhone[3] == 0)
			{

				if(pSize == 11)
				{
					if(arrPhone[4] == 0 || arrPhone[4] == 1 || arrPhone[4] == 9)
					{
						//두번째 국번이 0 또는 1 또는 9 이면 에러(011-0912-1234,011-0012-1234:에러)
						return phoneNum = "" ;
					}
					else
					{
						//포맷에 맞춤:0삭제(011-0234-1234 -> 011-234-1234)
						tmpPhoneNum = strDeleteAt(tmpPhoneNum.substring(0,3), tmpPhoneNum , tmpPhoneNum.length, 3);

						phoneNum = tmpPhoneNum;

						//strDeleteAt(szdata,nSize,3);
					}
				}
				else
				{
					//0으로 시작되는 국번의 번호 자리수는 항상 11자리(011-023-1234:에러)
					return phoneNum = "" ;
				}
			}
			else
			{
				if(pSize != 10 && pSize != 11)
				{
					//휴대폰 번호는 항상 10자리 또는 11자리
					return phoneNum = "" ;
				}
			}
		}
		//번호가 010일 경우
		else if(arrPhone[2] == 0)
		{
			if(arrPhone[3] == 0 || pSize != 11)
			{
				//국번은 항상 4자리
				return phoneNum = "" ;
			}
		}
		//번호가 016, 019, 017, 018일 경우
		else if(arrPhone[2] == 6 || arrPhone[2] == 9 || arrPhone[2] == 7 || arrPhone[2] == 8)
		{
			if(arrPhone[3] == 9)
			{
				if(pSize != 11)
				{
					//9로 시작되는 국번의 번호 자리수는 항상 11자리(019-912-1234:에러)
					return phoneNum = "" ;
				}
			}
			else if(arrPhone[3] == 0)
			{
				if(pSize == 11)
				{
					if(arrPhone[4] == 0 || arrPhone[4] == 9)
					{
						//두번째 국번이 0 또는 9 이면 에러(019-0912-1234,019-0012-1234:에러)
						return phoneNum = "" ;
					}
					else
					{
						//포맷에 맞춤:0삭제(019-0234-1234 -> 019-234-1234)
						tmpPhoneNum = strDeleteAt(tmpPhoneNum.substring(0,3), tmpPhoneNum , tmpPhoneNum.length, 3);

						phoneNum = tmpPhoneNum;

					}
				}
				else
				{
					//0으로 시작되는 국번의 번호 자리수는 항상 11자리(019-023-1234:에러)
					return phoneNum = "" ;
				}
			}
			else
			{
				if(pSize != 10 && pSize != 11)
				{
					//휴대폰 번호는 항상 10자리 또는 11자리
					return phoneNum = "" ;
				}
			}
		}
		else if(arrPhone[2] == 3)
		{
			//0130 번호일 경우
			if(arrPhone[3] != '0')
			{
				//0130 이 아닌 013# 이면 에러
				return phoneNum = "" ;
			}

			if(arrPhone[4] == 0)
			{
				//포맷에 맞춤:0삭제(019-0234-1234 -> 019-234-1234)
				tmpPhoneNum = strDeleteAt(tmpPhoneNum.substring(0,3), tmpPhoneNum , tmpPhoneNum.length, 3);

				phoneNum = tmpPhoneNum;


			}

			if(pSize != 11 && pSize != 12)
			{
				//0130 번호는 항상 11자리 또는 12자리
				return phoneNum = "" ;
			}

		}
		else
		{
			//011,016,017,018,019,0130 이 아닌 01#은 에러
			return phoneNum = "" ;
		}

	} else if (arrPhone[1] == 2) {
		if(pSize < 9  || pSize > 10 || arrPhone[1] == 0 || nChkType == 1)
		{
			//서울지역 번호는 항상 9 또는 10자리, 국번이 0으로 시작하면 에러, 휴대폰 체크이면 에러
			return phoneNum = "" ;
		}

	} else if (arrPhone[1] == 3) {
		if(pSize < 9  || nChkType > 0)
		{
			//03으로 시작하는 번호는 항상 9자리 이상, 휴대폰 체크이면 에러
			return phoneNum = "" ;
		}

		if(arrPhone[2] >= 1 && arrPhone[2] <= 3)
		{
			if(arrPhone[3] == 0 || (pSize != 10 && pSize != 11))
			{
				//지역번호 031,032,033일 경우 국번이 0으로 시작하면 에러, 번호는 항상 10 또는 11자리
				return phoneNum = "" ;
			}
		}
		else if( arrPhone[2] == 0 && arrPhone[3] == 3)
		{
			if(pSize != 11 && pSize != 12)
			{
				//특수 번호 0303일 경우 번호는 항상 11 또는 12자리(향후 추가예상)
				return phoneNum = "" ;
			}
		}
		else
		{
			//031,032,033,0303을 제외한 03#은 에러
			return phoneNum = "" ;
		}

	} else if (arrPhone[1] == 4) {
		if(pSize < 9  || nChkType > 0)
		{
			//04으로 시작하는 번호는 항상 9자리 이상, 휴대폰 체크이면 에러
			return phoneNum = "" ;
		}

		if(arrPhone[2] >= 1 && arrPhone[2] <= 3)
		{
			if(arrPhone[3] == 0 || (nSize != 10 && nSize != 11))
			{
				//지역번호 041,042,043일 경우 국번이 0으로 시작하면 에러, 번호는 항상 10 또는 11자리
				return phoneNum = "" ;
			}
		}
		else
		{
			//041,042,043을 제외한 04#은 에러
			return phoneNum = "" ;
		}
	} else if (arrPhone[1] == 5) {

		if(pSize < 9  || nChkType > 0)
		{
			//05으로 시작하는 번호는 항상 9자리 이상, 휴대폰 체크이면 에러
			return phoneNum = "" ;
		}

		if(arrPhone[2] >= 1 || arrPhone[2] <= 5)
		{
			if(arrPhone[3] == 0 || (pSize != 10 && pSize != 11))
			{
				//지역번호 051,052,053,054,055일 경우 국번이 0으로 시작하면 에러, 번호는 항상 10 또는 11자리
				return phoneNum = "" ;
			}
		}
		else if( arrPhone[2] == 0 && ( arrPhone[3] == 5 || arrPhone[3] == 2 || arrPhone[3] == 7 ))
		{
			if(pSize != 11 && pSize != 12)
			{
				//특수 번호 0505,0502,0507일 경우 번호는 항상 11 또는 12자리(향후 추가예상)
				return phoneNum = "" ;
			}
		}
		else
		{
			//051,052,053,054,055,0505,0502,0507을 제외한 05#은 에러
			return phoneNum = "" ;
		}

	} else if (arrPhone[1] == 6) {

		if(pSize < 9  || nChkType > 0)
		{
			/*06으로 시작하는 번호는 항상 9자리 이상, 휴대폰 체크이면 에러*/
			return phoneNum = "" ;
		}

		if(arrPhone[2] >= 1 && arrPhone[2] <= 4)
		{
			if(arrPhone[3] == 0 || (pSize != 10 && pSize != 11))
			{
				/*지역번호 061,062,063,064일 경우 국번이 0으로 시작하면 에러, 번호는 항상 10 또는 11자리*/
				return phoneNum = "" ;
			}
		}
		else
		{
			//061,062,063,064을 제외한 06#은 에러
			return phoneNum = "" ;
		}
	} else {
		//01,02,03,04,05,06을 제외한 0#은 에러
		return phoneNum = "" ;
	}

	return phoneNum;
}






/** =============================================
Return : String (숫자)
Comment: 입력받은 값중 숫자만을 취한다.
Usage  : onKeyUp="this.value=fn_clearString(this.value)"
---------------------------------------------- */
function fn_clearString(sVal)
{
	var pstr, sstr, ii;
	sstr = sVal;
	pstr = "";
	for(ii=0; ii<sstr.length; ii++) {
		//isNaN() : 입력파라미터의 값이 숫자면 false,숫자가 아니면 true를 반환
		if( !isNaN(sstr.substr(ii, 1)) )
			pstr = pstr + sstr.substr(ii, 1);
	}
	return pstr;
}
//===============================================


/** =============================================
Return : String
Comment: 입력받은 text 의 앞뒤에 붙은 Space, Tab, CRLF 를 제거
Usage  :
---------------------------------------------- */
function fn_trim(text)
{
	if (text == null) {
		return "";
	}

	var txt = text + "";
	var flag = false;

	// 앞쪽 트림
	var ii = 0;

	while (!flag) {
		var ch = txt.charAt(ii);
		if ( (ch == ' ') || (ch == '\t') || (ch == '\n') || (ch == '\r') ) {
			if (ii < txt.length)
				ii++;
			else
				flag = true;
		} else
			flag = true;
	}

	if (ii == (txt.length))
		return "";
	else
		txt = txt.substring(ii);

	// 뒤쪽 트림
	flag = false;
	var jj = txt.length - 1;

	while (!flag) {
		var ch = txt.charAt(jj);
		if ( (ch == ' ') || (ch == '\t') || (ch == '\n') || (ch == '\r') ) {
			if ( jj > 0 )
				jj--;
			else
				flag = true;
		} else
			flag = true;
	}

	txt = txt.substring(0, jj+1);
	return txt;
}
//===============================================


/** =============================================
Return : String
Comment: 입력받은 text 의 앞뒤에 붙은 Space, Tab, CRLF 를 제거
Usage  :
---------------------------------------------- */
function fn_trimByObj(obj)
{
	obj.value = fn_trim(obj.value);
}
//===============================================
