var skywin;
var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
var eventer = window[eventMethod];
var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
eventer(messageEvent,function(e) {
	  console.log('origin: ', e.origin)
	  console.log('ozServer: ', ozServer)
//	  alert(ozServer + e.origin);
	  if( e.origin != ozServer ){
		  return 
	  }else{
		  console.log('parent received message!: ', e.data);
			var param = e.data;
			if(e.data.Name != null){
				e.data['sign'] =e.data.Name; 
				$.ajax({
					type : "POST",
					contentType : "application/json",
					url : contextPath + "/common/saveSign.json",
					data : JSON.stringify(param),
					dataType : 'json',
					timeout : 100000
		        }).done(function(res) {
		        	objs = res;
					console.log("SUCCESS: ", res);
					
					if(res.message == "success"){
						res.data['type'] = e.data.type;
//						if(e.data.test != 'test'){
						var imgContainer = $('#sign');
						imgContainer.html('');
						console.log(res.data);
					    imgContainer.html('<li><div class="canvas"><img width="100%" src="'+e.data.Name+'"/></div></li>');
							//fnCmmAozSignResult(res.data);
							skywin.close();
//						}else{
//							var imgContainer = $('#sign');
//							imgContainer.html('');
//							console.log(res.data);
//						    imgContainer.html('<li><div class="canvas"><img width="100%" src="'+e.data.Name+'"/></div></li>');
//							skywin.close();
//						} 
					}
		        }).fail(function(e) {
					console.log("ERROR: ", e);
					skywin.close();
		        });			  
			}
  }
}, false);

var paramObjReqSign;
var temporaryInputValue;

test = function(){
	$("#OZViewer").empty();
	
	var opt = {};
	opt["ranering_mode"] = "svg";
	start_ozjs("OZViewer",ozServer +"/oz80/ozhviewer/",opt);
}
reopen = function(){
	var oz = document.getElementById("OZViewer");
	
	oz.Script('closeall');
	
	var params = new Array();
	
	params.push("connection.servlet="+ozServer+"/oz80/server");
	params.push("connection.reportname=/signpad2.ozr");
	params.push("viewer.usetoolbar=false");
	params.push("viewer.viewmode=fittowidth");
	params.push("viewer.usestatusbar=false");
	params.push("viewer.useprogressbar=false");
	
	oz.CreateReportEx(params.join("***"), "***");
}

function signPop(paramObjReq){ //서명
	$("#OZViewer").empty();
	
	var opt = {};
	opt["ranering_mode"] = "svg";
	start_ozjs("OZViewer",ozServer +"/oz80/ozhviewer/",opt);
	
	/*OZViewer.Script('closeall');*/
/*	var opt = {};
	opt["ranering_mode"] = "svg";
 	start_ozjs("OZViewer","${contextPath}/ozhviewer/",opt);*/
	/*var param = "";
	param += "connection.servlet="+ ozServer + "***";
	param += "connection.reportname=signpad2.ozr" + "***";
	OZViewer.CreateReportEx(param, "***");*/
	
 	paramObjReqSign = paramObjReq;
	$("#signPop").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $("#OZViewer").empty(); $('body').removeClass('bodyHold'); }
	});
}

function saveSign(){ //완료
	temporaryInputValue = OZViewer.GetInformation("EFORM_DATA_AT=0");
	//console.log("temporaryInputValue ==> " + temporaryInputValue);
	
    var ozjson = JSON.parse(OZViewer.GetInformation("INPUT_JSON_ALL"));
    //console.log("ozjson.Name ==> " + ozjson.Name);
    
    var param = {};
	if(ozjson.Name != null){
		param.name = ozjson.Name;
		param.sign = ozjson.Name2;
		param.moRecvNo = paramObjReqSign.moRecvNo;
		param.type = paramObjReqSign.type;
		param.moFileType = paramObjReqSign.moFileType;
		if('TEST' != paramObjReqSign.type){
				$.ajax({
					type : "POST",
					contentType : "application/json",
					url : contextPath + "/common/saveSign.json",
					data : JSON.stringify(param),
					dataType : 'json',
					timeout : 100000
		        }).done(function(res) {
		        	objs = res;
					console.log("SUCCESS: ", res);
					if(res.message == "success"){
						res.data['type'] = paramObjReqSign.type;
						if('TEST' != paramObjReqSign.type){
							fnCmmAozSignResult(res.data)
							$('#signPop').bPopup().close();
							$('body').removeClass('bodyHold');
						}else{
							var imgContainer = $('#sign');
							imgContainer.html('');
						    imgContainer.html('<li><div class="canvas" id="sign"><img width="100%" src="'+ozjson.Name+'"/></div></li>');
//							var imgContainer2 = $('#sign2');
//							imgContainer2.html('');
//						    imgContainer2.html('<li><div class="canvas" id="sign2"><img width="100%" src="'+ozjson.Name2+'"/></div></li>');
							$('#signPop').bPopup().close();
							$('body').removeClass('bodyHold');
						}
					}
		        }).fail(function(e) {
					console.log("ERROR: ", e);
					$('#signPop').bPopup().close();
					$('body').removeClass('bodyHold');
		        });
		}else{
			var imgContainer = $('#sign');
			imgContainer.html('');
		    imgContainer.html('<li><div class="canvas" id="sign"><img width="100%" src="'+ozjson.Name+'"/></div></li>');
			var imgContainer2 = $('#sign2');
			imgContainer2.html('');
		    imgContainer2.html('<li><div class="canvas" id="sign2"><img width="100%" src="'+ozjson.Name2+'"/></div></li>');
			$('#signPop').bPopup().close();
			$('body').removeClass('bodyHold');
		}
		
	}    

}
function sign(paramObjReq){
    var params = {};
    params['type'] = paramObjReq.type;
    params['moRecvNo'] = paramObjReq.moRecvNo;
    params['moFileType'] = paramObjReq.moFileType;
	skywin = window.open(ozServer+"/oz80/ozSign.jsp?" + $.param(params));
}
var androidCap;
function capture(paramObjReq) {
//	alert('capture1');
	var androidReq = {};
	androidReq.api = "200";
	androidReq.call_back = "callback";
	androidReq["input"] = {};
	androidReq.input["type"] = paramObjReq.type;
	androidReq.input["moRecvNo"] = paramObjReq.moRecvNo;
	androidReq.input["moFileType"] = paramObjReq.moFileType;
//	alert('capture2');
//	androidCap = androidReq;
//	captureInfo();
	window.Android.callApi(JSON.stringify(androidReq));
//	alert(JSON.stringify(androidReq));
}
function captureInfo(){
	$("#captureInfo").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function deviceCall(){
	window.Android.callApi(JSON.stringify(androidCap));
}

function caputreDocument(paramObjReq) {
	var androidReq = {}
	androidReq.api = "201";
	androidReq.call_back = "callbackDocument";
	androidReq["input"] = {};
	androidReq.input["type"] = paramObjReq.type;
	androidReq.input["moRecvNo"] = paramObjReq.moRecvNo;
	androidReq.input["moFileType"] = paramObjReq.moFileType;	
//	alert(JSON.stringify(androidReq));
	window.Android.callApi(JSON.stringify(androidReq));
}

function callback(res) {
//	alert(JSON.stringify(res.type));
	res.type = res.type;
	res.moRecvNo = res.moRecvNo;
	res.moFileType = res.moFileType;
	fn_loading(true);
		$.ajax({
			type : 'POST',
			contentType : 'application/json',
			url : '/scs/api/captureImage.json',
			data : JSON.stringify(res)
		}).done(function(json) {
//			alert('3');
			console.log("SUCCESS: ", json);
			if(json.message == "success"){
//				alert('성공');
//				alert(JSON.stringify(json.data));
				fnCmmAozCameraResult(json.data);
				fn_loading(false);

//				alert('성공2');
				/*
				var paramObjRes = {
					type : "" //페이지내 id 구분
					, name : ""   	//이름
					, jumin1 : ""   	//주민1
					, jumin2 : ""   	//주민2
					, moFileType : "" 	//내부 db 공통코드(MO_FILE_TYPE) 값
					, moRecvNo : ""   	//스마트청약접수번호
					, moFileNum : "" 	//첨부파일유형페이지번호
					, moFileNm : ""  	//첨부파일명
					, moFileSize : ""	//첨부파일크기
					, moFile : ""		//첨부파일경로
					, moFileRsltCd : "" //파일전송결과
				}
				*/
				$('#captureInfo').bPopup().close();
			}
//			display(data);
        }).fail(function(e) {
			console.log("ERROR: ", e);
			$('#captureInfo').bPopup().close();
			fn_loading(false);
//			display(e);
        });	
	}
function cls (){
	   window.close();
	}

function callbackDocument(res) {
	//alert('1');
	res.type = res.type;
	res.moRecvNo = res.moRecvNo;
	res.moFileType = res.moFileType;	
//	$('#applicatNum3').val(res.page_cnt); 
	res.document = 'true';

	fnCmmAozCameraResult(res.successResponse.data);
	//alert('2');
//	$.ajax({
//		type : 'POST',
//		contentType : 'application/json',
//		url : '/scs/api/captureDocument.json',
//		data : JSON.stringify(res)
//	}).done(function(json) {
//		alert('3');
//		console.log("SUCCESS: ", json);
//		if(json.message == "success"){
//			//alert('성공');
//			alert(JSON.stringify(json.data));
//			fnCmmAozCameraResult(json.data);
//			//alert('성공2');
//			/*
//			var paramObjRes = {
//				type : "" //페이지내 id 구분
//				, name : ""   	//이름
//				, jumin1 : ""   	//주민1
//				, jumin2 : ""   	//주민2
//				, moFileType : "" 	//내부 db 공통코드(MO_FILE_TYPE) 값
//				, moRecvNo : ""   	//스마트청약접수번호
//				, moFileNum : "" 	//첨부파일유형페이지번호
//				, moFileNm : ""  	//첨부파일명
//				, moFileSize : ""	//첨부파일크기
//				, moFile : ""		//첨부파일경로
//				, moFileRsltCd : "" //파일전송결과
//			}
//			*/
//		}
////		display(data);
//    }).fail(function(e) {
//		console.log("ERROR: ", e);
////		display(e);
//    });	
	
}