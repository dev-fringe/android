$(function() {

	$("select").selectOrDie();	

	$(".tabs > li").click(function(i){
		var tabs = $(this);
		var activeTab = tabs.attr("rel");
		var tabct = $(this).parent().next('.tabCt');
		tabs.addClass("active").siblings().removeClass("active");
		tabct.children('.tabUnit').hide();
		$("#" + activeTab).show();
	});

	 $(".collaps").each(function(i) {
		var collaps = $(this);
		collaps.find(".clpsTit").click(function(){			
			collaps.toggleClass("open").scrollTop();
		});
	 });

	 $(".checkBox").each(function(i) {
		var checkbox = $(this);
		checkbox.find(".checkTit").change(function(){
			checkbox.find(".checkCt").toggle();		
			checkbox.toggleClass("open");	
		});
	});

	 $(".menuBtn").click(function(){
		var menuOpen = $(this);		
		menuOpen.closest("body").addClass("menuOpen");
	});
	 $(".menuClose").click(function(){
		var menuClose = $(this);		
		menuClose.closest("body").removeClass("menuOpen");
	});
	
	$(".pop-adrlst > li").click(function(i){
		$(this).addClass("selectd")
		$(this).siblings().removeClass("selectd");

	});
	
	$(".menu-lst li a").click(function(i){
		$(this).addClass("selectd").siblings().removeClass("selectd");
	});
		
	$(".wtop").click(function(i){
		$('html, body').animate({scrollTop: 0}, 500);
	});
  
});