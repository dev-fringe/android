var returnFindAddrFunc=""; //리턴 function
var returnObjIndex="0"; //호출하는 위치 인덱스..
var zipAddr_searchGubun="N";

var tmp1 = "";
var tmp2 = "";

$(document).ready(function(){
	$('#btnRoadNm').on({click :function(event){
		fnPOPA_60_P5("fnddd");
		
		// 초기화
		$("#rdNm").val("");
		$("#frontNum").val("");
		$("#backNum").val("");
		$("#eupmyundongNm").val("");
		$("#addrLoadCl").addClass("active");
		$("#addrNumCl").removeClass("active");
		$("#addrbtnList1").hide();
		$("#addrbtnList2").hide();
		$("#detailAddr1").hide();
		$("#detailAddr2").hide();
		$('.dynm').remove();
	}
	});
});

// 도로명 찾기
function fnPOPA_60_P5(rtnFunc, targetIndex){
	$("#POP_A_60_P5").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
	
	// 초기화
	$("#rdNm").val("");
	$("#frontNum").val("");
	$("#backNum").val("");
	$("#eupmyundongNm").val("");
	$("#addrLoadCl").addClass("active");
	$("#addrNumCl").removeClass("active");
	$("#addrbtnList1").hide();
	$("#addrbtnList2").hide();
	$("#detailAddr1").hide();
	$("#detailAddr2").hide();
	$('.dynm').remove();
	
	returnFindAddrFunc = rtnFunc;
	returnObjIndex = targetIndex;
}

// 주소 클릭 시 selected
$("ul").on("click", "li.dynm", function(){
	$(this).addClass("selectd").siblings().removeClass("selectd");
});

// 도로명 찾기 버튼
$('#searchRdBtn').on({click :function(event){
	
	$('.dynm').remove();
	
	$("#addrbtnList1").hide();
	
	if ($.trim($("#rdNm").val()) == "") {
		var msg = '<p class="txt">'+ "도로명을 입력하여 주십시오." +'</p>'; 
		$('#rdChkPopMsg').html(msg);
		rdChkPop("rd");
		return;
	} 
	if ($.trim($("#frontNum").val()) == "") {
		var msg = '<p class="txt">'+ "건물 앞번호를 입력하여 주십시오." +'</p>'; 
		$('#rdChkPopMsg').html(msg);
		rdChkPop("num");
		return;
	}
	
	zipAddr_searchGubun = "N";
	//var searchGubun = "N"
	//$('#searchGubun').val("N");
	var rdNm  = $('#rdNm').val();
	var frontNum = $('#frontNum').val();
	var backNum = $('#backNum').val();
	
	var param = {
			searchGubun :zipAddr_searchGubun 
			, rdNm : rdNm
			, rdNmBldNo : frontNum
			, rdNmBldSubNo : backNum
	};
	
    controller.ajaxSend( {
    	url : contextPath + "/contract/searchAddr.json"
    	, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var rsltCd = result.retApi.rsltCd;
			var rsltMsg = result.retApi.rsltMsg;
			var vo = result.retApi.responseAddressListVO;
			// 도로명 찾기
			if(rsltCd == 000) { // 000 : 정상
				for (var i=0; i<vo.length; i++) {
					var zipCd = result.retApi.responseAddressListVO[i].zipCd;
					var siDoNm = result.retApi.responseAddressListVO[i].siDoNm;
					var siGunGuNm = result.retApi.responseAddressListVO[i].siGunGuNm;
					var rdNm = result.retApi.responseAddressListVO[i].rdNm;
					var bldMainNo = result.retApi.responseAddressListVO[i].bldMainNo;
					var bldSubNoVal = result.retApi.responseAddressListVO[i].bldSubNo;
					var bldSubNo = "";
					if (result.retApi.responseAddressListVO[i].bldSubNo != undefined) {
						bldSubNo = "-"+result.retApi.responseAddressListVO[i].bldSubNo;
					}
					
					var cont = "<li class='dynm' id='dynm'><div class='zipAddr'><span id='zipCd'>"+zipCd+" </span><span hidden id='siDoNm' class='"+siDoNm+"'></span><span hidden id='bldMainNo' class='"+bldMainNo+"'></span><span hidden id='bldSubNoVal' class='"+bldSubNoVal+"'></span><span id='siGunGuNm' class='"+siGunGuNm+"'></span>" +
							"<strong>"+siDoNm+" "+siGunGuNm+" "+rdNm+" "+ bldMainNo + bldSubNo+"</strong><span hidden id=rdNm class="+rdNm+">"+rdNm+"</span></div></ul></div></div></li>";
					
					$("#addrbtnList1").show();
					$("#pop-adrlst1").append(cont);
					$('#detailAddr1').hide();
					
					$('#nodata1').hide();
				}
			} else { // 199 : 조회결과없음
				$("#addrbtnList1").show();
				$('#nodata1').show();
			}
		}
    });
}
});

//도로명 주소 클릭 -> 아파트 검색
$(document).on("click","ul#pop-adrlst1 li#dynm.dynm",function(){
	//var gubun = $('#searchGubun').val();
	var gubun = zipAddr_searchGubun;
	var chk = $(this).children('#detailAddr1').attr('class');
	
	if(gubun == 'N') { // 도로명 찾기
		if(chk != 'detailAddr') {
			
			$("#titDetailAddr-lst1").hide();
			$("#detailAddr-lst1").hide();
			
			$("#addrChkLi1").remove();
			
			$("#sel1").empty();
			$("#sel1").append("<option value=''>아파트를 선택하세요.</option>");
			
			var detatchedAddr = $("#detailAddr1").detach();
			var length = detatchedAddr.length;
			
			if (length == '1') {
				tmp1 = detatchedAddr;
			} else {
				detatchedAddr = tmp1;
			}
			
//			$(this).append(detatchedAddr);
			$("#pop-adrlst1").append(detatchedAddr);
			$("#detailAddr1").show();
			
			$("#aptDong1").val("");
			$("#aptDongHo1").val("");
			$("#aptBurn1").val("");
			$("#aptBurnHo1").val("");
			$("#rest1").val("");
			$('#addrChk1').remove();

			var zipCd = $(this).find('span#zipCd').text();
			var searchGubun = zipAddr_searchGubun;//$('#searchGubun').val();
			var siDoNm = $(this).find('span#siDoNm').attr('class');
			var siGunGuNm = $(this).find('span#siGunGuNm').attr('class');
			var bldMainNo = $(this).find('span#bldMainNo').attr('class');
			var bldSubNoVal = $(this).find('span#bldSubNoVal').attr('class');
			var rdNm = $(this).find('span#rdNm').text();

			var param = {
					zipCd : zipCd.trim()
					, searchGubun :searchGubun 
					, siDoNm : siDoNm
					, siGunGuNm : siGunGuNm
					, rdNm : rdNm
					, rdNmBldNo : bldMainNo
					, rdNmBldSubNo : bldSubNoVal 
			};
			
			controller.ajaxSend( {
				url : contextPath + "/contract/searchApt.json"
				, data : param
				, dataType : 'json'
				, type : 'post'
				, async : false
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var rsltCd = result.retApi.rsltCd;
					var rsltMsg = result.retApi.rsltMsg;
					var vo = result.retApi.responseAptListVO;
					// 도로명 아파트 찾기
					if(rsltCd == 000) {
						for (var i=0; i<vo.length; i++) {
							var aptCd = vo[i].aptCd;
							var aptNm = vo[i].aptNm;
							var qamApt = vo[i].qamApt;
							var suppAddr = vo[i].suppAddr;
							
							var cont = "<option value='"+aptCd+"'>"+aptNm+"</option>";
							$("#sel1").append(cont);
						}
						$('#nodata1').hide();
						
						$("#sel1").focus();
						$("#aptDong1").focus();
						$("#rest1").focus();
						
						updateSelectOrDieRoad();
					} else {
						$('#nodata1').show();
					}
				}
			});
		}
	}
});

//도로명 주소 확인
$(document).on("click","#btnAddrChk1",function(){
	var gubun = zipAddr_searchGubun;
	var chk = $(this).parents("div#detailAddr1.detailAddr").find("#validAddr1").attr("id");
	
	if (chk != undefined) {
		$("#addrChkLi1").remove();
	}
	
	if(gubun == 'N') { // 도로명 찾기
		if (chk == undefined) {
			$("#btnAddrChk1").closest("div").append($("#valid1").html());
		}
		
		$("#titDetailAddr-lst1").show();
		$("#detailAddr-lst1").show();
		
		var searchGubun = zipAddr_searchGubun;//$('#searchGubun').val();
		var zipCd = $("#pop-adrlst1").children("li#dynm.dynm.selectd").find("span#zipCd").text();
		var siDoNm = $("#pop-adrlst1").children("li#dynm.dynm.selectd").find("span#siDoNm").attr("class");
		var siGunGuNm = $("#pop-adrlst1").children("li#dynm.dynm.selectd").find("span#siGunGuNm").attr("class");
		var rdNmBldNo = $("#pop-adrlst1").children("li#dynm.dynm.selectd").find("span#bldMainNo").attr("class");
		var bldSubNoVal = $("#pop-adrlst1").children("li#dynm.dynm.selectd").find("span#bldSubNoVal").attr("class");
		var rdNm = $("#pop-adrlst1").children("li#dynm.dynm.selectd").find("span#rdNm").text();
//		var zipCd = $("#btnAddrChk1").parents("li#dynm.dynm.selectd").find("span#zipCd").text();
//		var siDoNm = $("#btnAddrChk1").parents("li#dynm.dynm.selectd").find("span#siDoNm").attr("class");
//		var siGunGuNm = $("#btnAddrChk1").parents("li#dynm.dynm.selectd").find("span#siGunGuNm").attr("class");
//		var rdNmBldNo = $("#btnAddrChk1").parents("li#dynm.dynm.selectd").find("span#bldMainNo").attr("class");
//		var bldSubNoVal = $("#btnAddrChk1").parents("li#dynm.dynm.selectd").find("span#bldSubNoVal").attr("class");
//		var rdNm = $("#btnAddrChk1").parents("li#dynm.dynm.selectd").find("span#rdNm").text();
		var aptDong = $("#aptDong1").val();
		var aptDongHo = $("#aptDongHo1").val();
		var aptBurn = $("#aptBurn1").val();
		var aptBurnHo = $("#aptBurnHo1").val();
		var suppAddr = $("#rest1").val();
		var aptCd = $('#sel1 option:selected').val();
		
		if (aptCd != "") {
			if (aptDong == "") {
				var msg = '<p class="txt">'+ "아파트 동을 입력하여 주십시오." +'</p>'; 
				$('#rdChkPopMsg').html(msg);
				rdChkPop("aptDong1");
				return false;
			} else if (aptDongHo == "") {
				var msg = '<p class="txt">'+ "아파트 호를 입력하여 주십시오." +'</p>'; 
				$('#rdChkPopMsg').html(msg);
				rdChkPop("aptDongHo1");
				return false;
			}
		}

		var param = {
				zipCd : zipCd.trim()
				, searchGubun :searchGubun 
				, siDoNm : siDoNm
				, siGunGuNm : siGunGuNm
				, rdNm : rdNm
				, rdNmBldNo : rdNmBldNo
				, eupmyundongNm : ""
				, bunji : aptBurn
				, ho : aptBurnHo
				, suppAddr : suppAddr
				, aptCd : aptCd
		};
		
		controller.ajaxSend({
			url : contextPath + "/contract/addrValid.json"
			, data : param
			, dataType : 'json'
			, type : 'post'
			, isBlock : true
			, isOverLap : true
			, successCall:function(result) {
				var rsltCd = result.retApi.rsltCd;
				var rsltMsg = result.retApi.rsltMsg;
				var instalPlceZipCd = result.retApi.instalPlceZipCd;
				var jibunAddr = result.retApi.jibunAddr;
				var jibunSuppAddr = result.retApi.jibunSuppAddr;
				var rdNmVrfCd = result.retApi.rdNmVrfCd;
				var rdNmAddr = result.retApi.rdNmAddr;
				var rdNmSuppAddr = result.retApi.rdNmSuppAddr;
				var ktDongCd = result.retApi.ktDongCd;
				var addrBunjiCl = result.retApi.addrBunjiCl;
				var addrBunji = result.retApi.addrBunji;
				var addrHo = result.retApi.addrHo;
				var ktOfceCd = result.retApi.ktOfceCd;
				var ktOfceNm = result.retApi.ktOfceNm;
				var ktBldId = result.retApi.ktBldId;
				var ktRdNmId = result.retApi.ktRdNmId;
				var instalCrclNetCd = result.retApi.instalCrclNetCd;
				
				var aptNm = "";
				if ($('#sel1 option:selected').val() != "") {
					aptNm = $('#sel1 option:selected').text() +" "+$("#aptDong1").val()+"-"+$("#aptDongHo1").val() 
				}

				// 도로명 주소 확인
				if(rsltCd == 000) {
					var cont = "<li class='dynm' id='addrChkLi1'><div class='FinalAddr'><span id='instalPlceZipCd'>"+instalPlceZipCd+"</span><span hidden id='jibunAddr' class='"+jibunAddr+"'></span><span hidden id='jibunSuppAddr' class='"+jibunSuppAddr+"'></span><span hidden id='rdNmVrfCd' class='"+rdNmVrfCd+"'></span><span hidden id='rdNmAddr' class='"+rdNmAddr+"'></span><span hidden id='rdNmSuppAddr' class='"+rdNmSuppAddr+"'></span><span hidden id='ktDongCd' class='"+ktDongCd+"'></span><span hidden id='addrBunjiCl' class='"+addrBunjiCl+"'></span><span hidden id='addrBunji' class='"+addrBunji+"'></span><span hidden id='addrHo' class='"+addrHo+"'></span><span hidden id='ktOfceCd' class='"+ktOfceCd+"'></span><span hidden id='ktOfceNm' class='"+ktOfceNm+"'></span><span hidden id='ktBldId' class='"+ktBldId+"'></span><span hidden id='ktRdNmId' class='"+ktRdNmId+"'></span><span hidden id='instalCrclNetCd' class='"+instalCrclNetCd+"'></span>" +
					"<strong> "+rdNmAddr+" "+rdNmSuppAddr+" "+aptNm+"</strong></div></li>";
					
					$("#validAddr1").append(cont);
					$('#nodata11').hide();
				} else {
					$('#nodata11').show();
				}
			}
		});
	}
});

//도로명 주소 정제 완료
$(document).on("click","#addrChkLi1",function(){
	var instalPlceZipCd = $("#addrChkLi1").children().find("span#instalPlceZipCd").text();
	var jibunAddr = $("#addrChkLi1").children().find("span#jibunAddr").attr("class");
	var jibunSuppAddr = $("#addrChkLi1").children().find("span#jibunSuppAddr").attr('class');
	var rdNmVrfCd = $("#addrChkLi1").children().find("span#rdNmVrfCd").attr('class');
	var rdNmAddr = $("#addrChkLi1").children().find("span#rdNmAddr").attr('class');
	var rdNmSuppAddr = $("#addrChkLi1").children().find("span#rdNmSuppAddr").attr('class');
	var ktDongCd = $("#addrChkLi1").children().find("span#ktDongCd").attr('class');
	var addrBunjiCl = $("#addrChkLi1").children().find("span#addrBunjiCl").attr('class');
	var addrBunji = $("#addrChkLi1").children().find("span#addrBunji").attr('class');
	var addrHo = $("#addrChkLi1").children().find("span#addrHo").attr('class');
	var ktOfceCd = $("#addrChkLi1").children().find("span#ktOfceCd").attr('class');
	var ktOfceNm = $("#addrChkLi1").children().find("span#ktOfceNm").attr('class');
	var ktBldId = $("#addrChkLi1").children().find("span#ktBldId").attr('class');
	var ktRdNmId = $("#addrChkLi1").children().find("span#ktRdNmId").attr('class');
	var instalCrclNetCd = $("#addrChkLi1").children().find("span#instalCrclNetCd").attr('class');
	var aptCd = $('#sel1 option:selected').val(); 
	var aptDong = $("#aptDong1").val(); 
	var aptHo = $("#aptDongHo1").val();
	var aptBurn = $("#aptBurn1").val();
	var aptBurnHo = $("#aptBurnHo1").val();
	var rest = $("#rest1").val();
	
	var paramObj = {
		searchGubun : "N" //J:지번, N : 도로명
		, instalPlceZipCd : instalPlceZipCd	//설치우편번호
		, jibunAddr	 :  jibunAddr	//	지번기본주소
		, jibunSuppAddr : jibunSuppAddr	//	지번보조주소
		, rdNmVrfCd : rdNmVrfCd	//	도로명검증코드
		, rdNmAddr : rdNmAddr	//	도로명기본주소
		, rdNmSuppAddr : rdNmSuppAddr	//		도로명보조주소
		, ktDongCd : ktDongCd	//	KT동코드
		, addrBunjiCl : addrBunjiCl	//		주소번지유형
		, addrBunji : addrBunji	//	주소번지
		, addrHo : addrHo	//		주소호
		, ktOfceCd : ktOfceCd	//	KT수용국코드
		, ktOfceNm :ktOfceNm	//		KT수용국명
		, ktBldId : ktBldId	//		KT건물아이디
		, ktRdNmId : ktRdNmId//	KT도로명아이디
		, instalCrclNetCd :instalCrclNetCd	//	설치유통망코드
		, aptCd : aptCd // 아파트코드
		, aptDong : aptDong // 아파트동
		, aptHo : aptHo // 아파트호
		, bldMgmtNo : aptBurn +"-"+ aptBurnHo +" "+ rest // 건물관리번호
		, targetIndex : returnObjIndex
	};
	//paramObj.instalPlceZipCd="";
	var functionName = returnFindAddrFunc;
	eval (functionName+"(paramObj);");
	
	//팝업닫기
	$('body').removeClass('bodyHold');
	$("#POP_A_60_P5").bPopup().close();
});

// 지번 찾기 버튼
$('#searchAddrBtn').on({click :function(event){
	
	$('.dynm').remove();
	
	$('#addrbtnList2').hide();
	
	if ($.trim($("#eupmyundongNm").val()) == "") {
		jbChkPop();
		return;
	} 
	
	//var searchGubun = "J"
	//$('#searchGubun').val("J");
	zipAddr_searchGubun = "J";
	var eupmyundongNm = $('#eupmyundongNm').val();
	
	var param = {
			searchGubun :zipAddr_searchGubun 
			, eupmyundongNm : eupmyundongNm
	};
	
    controller.ajaxSend( {
    	url : contextPath + "/contract/searchAddr.json"
    	, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var rsltCd = result.retApi.rsltCd;
			var rsltMsg = result.retApi.rsltMsg;
			var vo = result.retApi.responseAddressListVO;
			// 지번 찾기
			if(rsltCd == 000) { // 000 : 정상 
				for (var i=0; i<vo.length; i++) {
					var zipCd = result.retApi.responseAddressListVO[i].zipCd;
					var siDoNm = result.retApi.responseAddressListVO[i].siDoNm;
					var siGunGuNm = result.retApi.responseAddressListVO[i].siGunGuNm;
					var eupmyundongNm = result.retApi.responseAddressListVO[i].eupmyundongNm;
					var riNm = result.retApi.responseAddressListVO[i].riNm;
					if (riNm == undefined) {
						riNm = "";
					}
					var regionLvlType = result.retApi.responseAddressListVO[i].regionLvlType;
					
					var cont = "<li class='dynm' id='dynm'><div class='zipAddr'><span id='zipCd'>"+zipCd+" </span><span hidden id='siDoNm' class='"+siDoNm+"'></span></span><span hidden id='siGunGuNm' class='"+siGunGuNm+"'></span>" +
					"<strong>"+siDoNm+" "+siGunGuNm+" "+eupmyundongNm+" "+riNm+"</strong><span hidden id=eupmyundongNm class="+eupmyundongNm+"></span><span hidden id=riNm class="+riNm+"></span></div></ul></div></div></li>";

					$("#addrbtnList2").show();
					$("#pop-adrlst2").append(cont);
					$('#detailAddr2').hide();
					
					$('#nodata2').hide();
				}
			} else { // 199 : 조회결과없음
				$("#addrbtnList2").show();
				$('#nodata2').show();
			}
		}
    });
}
});	

// 지번 주소 클릭 -> 아파트 검색
$(document).on("click","ul#pop-adrlst2 li#dynm.dynm",function(){
	//var gubun = $('#searchGubun').val();
	var gubun = zipAddr_searchGubun;
	var chk = $(this).children('#detailAddr2').attr('class');
	
	if(gubun == 'J'){ // 지번
		if(chk != 'detailAddr') {
			
			$("#addrChkLi2").remove();
			
			$("#titDetailAddr-lst2").hide();
			$("#detailAddr-lst2").hide();
			
			$("#sel2").empty();
			$("#sel2").append("<option value=''>아파트를 선택하세요.</option>");
			
			var detatchedAddr = $("#detailAddr2").detach();
			var length = detatchedAddr.length;
			
			if (length == '1') {
				tmp2 = detatchedAddr;
			} else {
				detatchedAddr = tmp2;
			}
			
//			$(this).append(detatchedAddr);
			$("#pop-adrlst2").append(detatchedAddr);
			$("#detailAddr2").show();
			
			$("#aptDong2").val("");
			$("#aptDongHo2").val("");
			$("#aptBurn2").val("");
			$("#aptBurnHo2").val("");
			$("#rest2").val("");
			$('#addrChk2').remove();
			
			var zipCd = $(this).find('span#zipCd').text();
			var searchGubun = zipAddr_searchGubun;//$('#searchGubun').val();
			var siDoNm = $(this).find('span#siDoNm').attr('class');
			var siGunGuNm = $(this).find('span#siGunGuNm').attr('class');
			var eupmyundongNm = $(this).find('span#eupmyundongNm').attr('class');
			var riNm = $(this).find('span#riNm').attr('class');
			
			var param = {
					zipCd : zipCd.trim()
					, searchGubun :searchGubun 
					, siDoNm : siDoNm
					, siGunGuNm : siGunGuNm
					, eupmyundongNm : eupmyundongNm
					, riNm : riNm
			};
			
			controller.ajaxSend( {
				url : contextPath + "/contract/searchApt.json"
				, data : param
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var rsltCd = result.retApi.rsltCd;
					var rsltMsg = result.retApi.rsltMsg;
					var vo = result.retApi.responseAptListVO;
					// 아파트 찾기
					if(rsltCd == 000 || rsltCd == 199) {
						for (var i=0; i<vo.length; i++) {
							var aptCd = vo[i].aptCd;
							var aptNm = vo[i].aptNm;
							var qamApt = vo[i].qamApt;
							var suppAddr = vo[i].suppAddr;
							
							var cont = "<option value='"+aptCd+"'>"+aptNm+"</option>";
							$("#sel2").append(cont);
						}
						$('#nodata2').hide();
						
						$("#sel2").focus();
						$("#aptDong2").focus();
						$("#rest2").focus();
						
						updateSelectOrDieRoad();
					} else {
						$('#nodata2').show();
					}
				}
			});
		}
	}
});

// 지번 주소 확인
$(document).on("click","#btnAddrChk2",function(){
	var gubun = zipAddr_searchGubun;
	var chk = $(this).parents("div#detailAddr2.detailAddr").find("#validAddr2").attr("id");
	if (chk != undefined) {
		$("#addrChkLi2").remove();
	}
	
	if(gubun == 'J'){ // 지번
		if (chk == undefined) {
			$("#btnAddrChk2").closest("div").append($("#valid2").html());
		}
		
		$("#titDetailAddr-lst2").show();
		$("#detailAddr-lst2").show();
		
		var searchGubun = zipAddr_searchGubun;//$('#searchGubun').val();
		var zipCd = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#zipCd").text();
		var siDoNm = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#siDoNm").attr("class");
		var siGunGuNm = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#siGunGuNm").attr("class");
		var rdNmBldNo = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#bldMainNo").attr("class");
		var bldSubNoVal = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#bldSubNoVal").attr("class");
		var rdNm = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#rdNm").text();
		var eupmyundongNm = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#eupmyundongNm").attr("class");
		var riNm = $("#pop-adrlst2").children("li#dynm.dynm.selectd").find("span#riNm").attr("class");
//		var zipCd = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#zipCd").text();
//		var siDoNm = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#siDoNm").attr("class");
//		var siGunGuNm = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#siGunGuNm").attr("class");
//		var rdNmBldNo = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#bldMainNo").attr("class");
//		var bldSubNoVal = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#bldSubNoVal").attr("class");
//		var rdNm = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#rdNm").text();
//		var eupmyundongNm = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#eupmyundongNm").attr("class");
//		var riNm = $("#btnAddrChk2").parents("li#dynm.dynm.selectd").find("span#riNm").attr("class");
		var aptDong = $("#aptDong2").val();
		var aptDongHo = $("#aptDongHo2").val();
		var aptBurn = $("#aptBurn2").val();
		var aptBurnHo = $("#aptBurnHo2").val();
		var suppAddr = $("#rest2").val();
		var aptCd = $('#sel2 option:selected').val();
		
		if (aptCd != "") {
			if (aptDong == "") {
				var msg = '<p class="txt">'+ "아파트 동을 입력하여 주십시오." +'</p>'; 
				$('#rdChkPopMsg').html(msg);
				rdChkPop("aptDong2");
				return false;
			} else if (aptDongHo == "") {
				var msg = '<p class="txt">'+ "아파트 호를 입력하여 주십시오." +'</p>'; 
				$('#rdChkPopMsg').html(msg);
				rdChkPop("aptDongHo2");
				return false;
			}
		}
		
		var param = {
				zipCd : zipCd.trim()
				, searchGubun :searchGubun 
				, siDoNm : siDoNm
				, siGunGuNm : siGunGuNm
				, riNm : riNm
				, eupmyundongNm : eupmyundongNm
				, bunji : aptBurn
				, ho : aptBurnHo
				, suppAddr : suppAddr
				, aptCd : aptCd
		};
		
		controller.ajaxSend({
			url : contextPath + "/contract/addrValid.json"
			, data : param
			, dataType : 'json'
			, type : 'post'
			, isBlock : true
			, isOverLap : true
			, successCall:function(result) {
				var rsltCd = result.retApi.rsltCd;
				var rsltMsg = result.retApi.rsltMsg;
				var instalPlceZipCd = result.retApi.instalPlceZipCd;
				var jibunAddr = result.retApi.jibunAddr;
				var jibunSuppAddr = result.retApi.jibunSuppAddr;
				var rdNmVrfCd = result.retApi.rdNmVrfCd;
				var rdNmAddr = result.retApi.rdNmAddr;
				var rdNmSuppAddr = result.retApi.rdNmSuppAddr;
				var ktDongCd = result.retApi.ktDongCd;
				var addrBunjiCl = result.retApi.addrBunjiCl;
				var addrBunji = result.retApi.addrBunji;
				var addrHo = result.retApi.addrHo;
				var ktOfceCd = result.retApi.ktOfceCd;
				var ktOfceNm = result.retApi.ktOfceNm;
				var ktBldId = result.retApi.ktBldId;
				var ktRdNmId = result.retApi.ktRdNmId;
				var instalCrclNetCd = result.retApi.instalCrclNetCd;
				
				var aptNm = "";
				if ($('#sel2 option:selected').val() != "") {
					aptNm = $('#sel2 option:selected').text() +" "+$("#aptDong2").val()+"-"+$("#aptDongHo2").val() 
				}
				
				// 지번 주소 확인
				if(rsltCd == 000) {
					var cont = "<li class='dynm' id='addrChkLi2'><div class='FinalAddr'><span id='instalPlceZipCd'>"+instalPlceZipCd+"</span>"+" "+"<span hidden id='jibunAddr' class='"+jibunAddr+"'></span><span hidden id='jibunSuppAddr' class='"+jibunSuppAddr+"'></span><span hidden id='rdNmVrfCd' class='"+rdNmVrfCd+"'></span><span hidden id='rdNmAddr' class='"+rdNmAddr+"'></span><span hidden id='rdNmSuppAddr' class='"+rdNmSuppAddr+"'></span><span hidden id='ktDongCd' class='"+ktDongCd+"'></span><span hidden id='addrBunjiCl' class='"+addrBunjiCl+"'></span><span hidden id='addrBunji' class='"+addrBunji+"'></span><span hidden id='addrHo' class='"+addrHo+"'></span><span hidden id='ktOfceCd' class='"+ktOfceCd+"'></span><span hidden id='ktOfceNm' class='"+ktOfceNm+"'></span><span hidden id='ktBldId' class='"+ktBldId+"'></span><span hidden id='ktRdNmId' class='"+ktRdNmId+"'></span><span hidden id='instalCrclNetCd' class='"+instalCrclNetCd+"'></span>" +
					"<strong>"+jibunAddr+" "+jibunSuppAddr+" "+aptNm+"</strong></div></li>";
					
					$("#validAddr2").append(cont);
					$('#nodata22').hide();
				} else {
					$('#nodata22').show();
				}
			}
		});
	}
});

// 지번 주소 정제 완료
$(document).on("click","#addrChkLi2",function(){
	var instalPlceZipCd = $("#addrChkLi2").children().find("span#instalPlceZipCd").text();
	var jibunAddr = $("#addrChkLi2").children().find("span#jibunAddr").attr("class");
	var jibunSuppAddr = $("#addrChkLi2").children().find("span#jibunSuppAddr").attr('class');
	var rdNmVrfCd = $("#addrChkLi2").children().find("span#rdNmVrfCd").attr('class');
	var rdNmAddr = $("#addrChkLi2").children().find("span#rdNmAddr").attr('class');
	var rdNmSuppAddr = $("#addrChkLi2").children().find("span#rdNmSuppAddr").attr('class');
	var ktDongCd = $("#addrChkLi2").children().find("span#ktDongCd").attr('class');
	var addrBunjiCl = $("#addrChkLi2").children().find("span#addrBunjiCl").attr('class');
	var addrBunji = $("#addrChkLi2").children().find("span#addrBunji").attr('class');
	var addrHo = $("#addrChkLi2").children().find("span#addrHo").attr('class');
	var ktOfceCd = $("#addrChkLi2").children().find("span#ktOfceCd").attr('class');
	var ktOfceNm = $("#addrChkLi2").children().find("span#ktOfceNm").attr('class');
	var ktBldId = $("#addrChkLi2").children().find("span#ktBldId").attr('class');
	var ktRdNmId = $("#addrChkLi2").children().find("span#ktRdNmId").attr('class');
	var instalCrclNetCd = $("#addrChkLi2").children().find("span#instalCrclNetCd").attr('class');
	var aptCd = $('#sel2 option:selected').val(); 
	var aptDong = $("#aptDong2").val(); 
	var aptHo = $("#aptDongHo2").val();
	var aptBurn = $("#aptBurn2").val();
	var aptBurnHo = $("#aptBurnHo2").val();
	var rest = $("#rest2").val();
	
	var paramObj = {
			searchGubun : "J" //J:지번, N : 도로명
			, instalPlceZipCd : instalPlceZipCd	//설치우편번호
			, jibunAddr	 :  jibunAddr	//	지번기본주소
			, jibunSuppAddr : jibunSuppAddr	//	지번보조주소
			, rdNmVrfCd : rdNmVrfCd	//	도로명검증코드
			, rdNmAddr : rdNmAddr	//	도로명기본주소
			, rdNmSuppAddr : rdNmSuppAddr	//		도로명보조주소
			, ktDongCd : ktDongCd	//	KT동코드
			, addrBunjiCl : addrBunjiCl	//		주소번지유형
			, addrBunji : addrBunji	//	주소번지
			, addrHo : addrHo	//		주소호
			, ktOfceCd : ktOfceCd	//	KT수용국코드
			, ktOfceNm :ktOfceNm	//		KT수용국명
			, ktBldId : ktBldId	//		KT건물아이디
			, ktRdNmId : ktRdNmId//	KT도로명아이디
			, instalCrclNetCd :instalCrclNetCd	//	설치유통망코드
			, aptCd : aptCd // 아파트코드
			, aptDong : aptDong // 아파트동
			, aptHo : aptHo // 아파트호
			, bldMgmtNo : aptBurn +"-"+ aptBurnHo +" "+ rest // 건물관리번호
			, targetIndex : returnObjIndex
	};
	//paramObj.instalPlceZipCd="";
	var functionName = returnFindAddrFunc;
	eval (functionName+"(paramObj);");
	
	//팝업닫기
	$('body').removeClass('bodyHold');
	$("#POP_A_60_P5").bPopup().close();
});

function rdChkPop(param){
	$("#rdChkPop").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold');
			if (param == "rd") {
				$("#rdNm").focus();
			} else if (param == "num") {
				$("#frontNum").focus();
			} else if (param == "aptDong1") {
				$("#aptDong1").focus();
			} else if (param == "aptDongHo1") {
				$("#aptDongHo1").focus();
			} else if (param == "aptDong2") {
				$("#aptDong2").focus();
			} else if (param == "aptDongHo2") {
				$("#aptDongHo2").focus();
			}
		}
	});
}
function jbChkPop(){
	$("#jbChkPop").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold');
		$("#eupmyundongNm").focus();}
	});
}
function updateSelectOrDieRoad(){
	setTimeout(function() { 
		$("select").selectOrDie("update");
	}, 100);
}
