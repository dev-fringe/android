var AJAX_RESULT_CODE = {
	SUCCESS : '00000'
};

//로딩
var isLoadBlock = true,
	curevent;

//getUrlToSubmitPost 함수사용 처리중표시
var isUrlToSubmitPost = false;
if(isUrlToSubmitPost == true) {
	$.loadUnBlock();
}

jQuery.loadBlock = function(event, name){
	fn_loading(true);
};

jQuery.loadUnBlock = function(event){
	if(event == null){
		$("#Loading").remove();
		$("#LoadWrap").remove();
	}else{
		$(event).removeAttr("style");
		$(event).find("#LoadingDetail").remove();
	}
	fn_loading(false);
	isLoadBlock = false;
};

jQuery.layerAlertClose = function(event){
	if(event == null){
		$(".popErrorWrap").hide();
		$(".popErrorWrap-middle").hide();
	}else{
		$(event).removeAttr("style");
		$(event).find(".popErrorWrap").hide();
		$(event).find(".popErrorWrap-middle").hide();
	}
	isLoadBlock = false;
};

jQuery.layerError = function(msg) {
	var html;
		html   = '<div class="popErrorWrap" style="position:fixed;"></div>';
		html  += '<div class="popErrorWrap-middle">';
			html +=	'<span class="title">시스템 점검 중입니다.</span>';
			html +=	'<p>점검시간 동안 일부 서비스 이용이 제한되는 점 양해 부탁드립니다.</p>';
	if(msg == null) {
	/*
	$.layerError();
	*/
	} else if(typeof msg == "object") {

			html += '<ul>';
		if(msg.time) {
				html += '<li>';
					html += '<strong class="name">점검 시간 :</strong>';
					html += '<span class="desc">'+ msg.time +'</span>';
				html += '</li>';
		}
		if(msg.desc) {
				html += '<li>';
					html += '<strong class="name">점검 내용 :</strong>';
					html += '<span class="desc">'+ msg.desc +'</span>';
				html += '</li>';
		}
		if(msg.target) {
				html += '<li>';
					html += '<strong class="name">대상서비스 :</strong>';
					html += '<span class="desc">'+ msg.target +'</span>';
				html += '</li>';
		}
			html += '</ul>';
	} else if(typeof msg == "string") {
	/*
	var msg = '서비스 개선을 위한 점검입니다.';
	$.layerError(msg);
	*/
			html += '<ul>';
				html += '<li>';
					html += '<strong class="name">점검 내용 :</strong>';
					html += '<span class="desc">'+ msg +'</span>';
				html += '</li>';
			html += '</ul>';
	}
		html += '</div>';
	$('body').prepend(html);
};

jQuery.layerAlert = function(event, msg){
	if (msg ==null){
		msg = "조회가 불가능합니다." ;
	}
	if(event == null){
		var  loadMsg = '' ;
			loadMsg += '<div class="popErrorWrap" style="position:fixed;"></div>',
			loadMsg += '<div class="popErrorWrap-middle">',
			loadMsg += '<p>'+ msg +'</p>',
			loadMsg += '<div class="pbtnWrap">',
			loadMsg += " <p><a href=\"javascript:$.layerAlertClose();\" ><span class='pbtn36-gray'>닫기</span></a></p>",
			loadMsg += '</div>',
			loadMsg += '</div>';
		$("body").prepend(loadMsg);
	}else{
		var contH = $(event).height();

		var loadMsg='';
		loadMsg += '<div class="popErrorWrap" style="position:fixed;"></div>',
		loadMsg += '<div class="popErrorWrap-middle">',
		loadMsg += '<p>'+ msg +'</p>',
		loadMsg += '<div class="pbtnWrap">',
		loadMsg += " <p><a href=\"javascript:$.layerAlertClose();\" ><span class='pbtn36-gray'>닫기</span></a></p>",
		loadMsg += '</div>',
		loadMsg += '</div>';

		if (curevent != event) {
			isLoadBlock = false;
			curevent = event ;
		}

		if(isLoadBlock == false){
			$(event).attr("style","position:relative")
			$(event).append(loadMsg);

			isLoadBlock = true;
		}
	}
};

var isCommonEvent = false;

jQuery.extend({
	CommonObj : function() {
		var that = this;
		var $form = null;
		var $body = null;
		// var $body= $('body');

		this.isOverLapClick = false;
		this.ajaxCount = 0;

		this.createForm = function(cfg) {
			if (!that.$form) {
				that.$form = $('<form></form>');
			}
			that.$form.empty();

			if (cfg.id != undefined) {
				that.$form.attr('id', cfg.id);
			}
			if (cfg.name != undefined) {
				that.$form.attr('name', cfg.name);
			}
			that.$form.attr('method', cfg.method || 'post');
			that.$form.attr('action', cfg.action || '');
			that.$form.attr('target', cfg.target || '_self');
			that.$body.append(that.$form);

			return that.$form;
		};

		this.attachHiddenElement = function(name, value) {
			if (!that.$form) {
				alert('createForm() must be called');
				return;
			}

			var $hdnEl = $('<input type="hidden"></input>');
			$hdnEl.attr('name', name);
			$hdnEl.attr('value', value);
			that.$form.append($hdnEl);
		};

		this.formSerialize = function() {
			if (that.$form) {
				return that.$form.serialize();
			}
		};

		this.formSubmit = function() {
			if (that.$form) {
				that.$form.submit();
			}
		};

		this.setSerializedFormData = function(param) {
			var resultStr = '';
			if (Object.prototype.toString.call(param) === '[object Object]') {
				var encodedParam = '';
				for ( var p in param) {
					if (param.hasOwnProperty(p)) {
						encodedParam = param[p];
						if (typeof encodedParam == 'string') {
							encodedParam = encodedParam.replace(/\&/gm, '%26').replace(/\+/gm, '%2B');
						}
						var $hdnEl = $('<input type="hidden"></input>');
						$hdnEl.attr('name', p);
						$hdnEl.attr('value', encodedParam);
						that.$form.append($hdnEl);
					}
				}
			}
			return resultStr;
		};

		this.getSerializedData = function(param) {
			var resultStr = '';
			if (Object.prototype.toString.call(param) === '[object Object]') {
				var arr = [];
				var encodedParam = '';
				for ( var p in param) {
					if (param.hasOwnProperty(p)) {
						encodedParam = param[p];
						if (typeof encodedParam == 'string') {
							encodedParam = encodedParam.replace(/\&/gm, '%26').replace(/\+/gm, '%2B').replace(/\?/gm, '%3F').replace(/%/gm, '%25');
						}
						arr.push(p + '=' + encodedParam);
					}
				}

				resultStr = arr.join('&');
			} else if ($.isArray(param)) {
				resultStr = param.join('&');
			}
			return resultStr;
		};

		this.getSerializedFormData = function($formObj) {
			var resultStr = '';
			var arr = [];
			if ($formObj != null && $formObj != "") {
				$($formObj).find("input").each(function() {
					if ($(this).attr("name") != null) {
						arr.push($(this).attr("name") + '=' + $(this).val());
					}
				});
			}
			resultStr = arr.join('&');
			return resultStr;
		};


		this.getUrlToSubmitPost = function(url, target) {
			if (url == null) {
				return;
			}

			var param = "";
			if (url.indexOf("?") > -1) {
				param = url.substring(url.indexOf("?")+1, url.length);
				url = url.substring(0, url.indexOf("?"));

				if (target == null) {
					target = "_self";
				}

				$.loadBlock(null, "처리중입니다.");
				isUrlToSubmitPost = true;

				var fmOption = {
					"id" : "postSbumit",
					"name" : "postSbumit",
					"target" : target,
					"action" : url
				}
				that.createForm(fmOption);

				var paramList = param.split("&");

				for (var i=0; i < paramList.length; i++) {
					var paramObj = paramList[i].split("=");
					var paramNm = paramObj[0];
					var paramValue = "";
					if (paramObj.length == 2) {
						paramValue = paramObj[1];
					}
					// 암호화된 get Url인코딩 되어있는거 푼다.
					if (typeof paramValue == 'string') {
						paramValue = paramValue.replace(/\&/gm, '%26').replace(/\+/gm, '%2B').replace(/\?/gm, '%3F').replace(/%/gm, '%25');
					}
					that.attachHiddenElement(paramNm, decodeURIComponent(paramValue));

				}
				that.formSubmit();
			} else {
				location.href = url;
			}

		};

		this.ajaxSend = function(cfg) {

			if (cfg.isOverLap == undefined) {
				cfg.isOverLap = true;
			}

			if (cfg.isBlock == undefined) {
				cfg.isBlock = true;
			}

			if (cfg.isBlock) {
				$.loadBlock(cfg.isBlockTarget, cfg.blockText);
			}

			if (that.isOverLapClick) {
				alert("잠시만 기다려주세요.");
				$.loadUnBlock();
				return;
			}

			if (cfg.isOverLap == false) {
				that.isOverLapClick = true;
			}
			that.ajaxCount++;

			$.ajax({
				url : cfg.url,
				data : cfg.data,
				type : (cfg.method == undefined) ? 'post': cfg.method,
				contentType : (cfg.contentType == undefined) ? 'application/x-www-form-urlencoded;charset=UTF-8' : cfg.contentType,
				cache : false,
				dataType : cfg.dataType,
				async : (cfg.async == undefined) ? true : cfg.async,
				timeout : (cfg.timeout == undefined) ? 60000 : cfg.timeout,
				isBlock : (cfg.isBlock == undefined) ? true : cfg.isBlock,
				isBlockTarget : (cfg.isBlockTarget == undefined) ? null : cfg.isBlockTarget,
				errorCall : (cfg.errorCall == undefined) ? function() { } : cfg.errorCall,
				error : function(e, status, exception) {

					that.ajaxCount--;
					that.isOverLapClick = false;

					if (this.isBlockTarget != null) {
						$.loadUnBlock(this.isBlockTarget);
					}
					$.loadUnBlock();

					var data = e.responseJSON;
					if (data == null && e.responseText != null && e.responseText != '') {
						try {
							data = JSON.parse(e.responseText);
						} catch (e) {}
					}
					if (data != null) {
						if (data.RES.returnCode == "02" ) {		//02 실패
							var msg = data.RES.returnMsg;
							var rUrl = data.RES.returnUrl;
							alert(msg.replace(/\\n/g, "\n"));

							if (rUrl != "null" && $.trim(rUrl).length > 0) {

								if (rUrl == 'HISTORYBACK') {
									history.go(-1);
									return;
								}else if(rUrl == 'SELFCLOSE'){
									window.parent.lyPop.close();
									return;
								}
								top.location.href = rUrl;
							}
							if (cfg.errorCall != undefined) {
								cfg.errorCall(data);
							}
							return;
						}else if (data.RES.returnCode == "06")  { // 06 에러공지
							var msg = data.RES.returnMsg;
							$.layerError(cfg.isBlockTarget , msg) ;
							return;
						}else if (data.RES.returnCode == "08")  { // 08 접근권한
							var msg = data.RES.returnMsg;
							$.layerAlert(cfg.isBlockTarget , msg) ;
							return;
						}
					}

					if (cfg.errorCall != undefined) {
						cfg.errorCall(e);
						return;
					}

					var errorMsg = '';
					if (e.status == '0') {
						errorMsg = '네트워크 에러입니다.\n통신연결 상태를 확인하세요';
					} else {
						errorMsg = '서버 에러입니다.\n관리자에게 문의해 주시기 바랍니다.';
					}
					alert(errorMsg);

				}, success : function(data) {

					that.ajaxCount--;
					that.isOverLapClick = false;

					if (this.isBlockTarget != null) {
						$.loadUnBlock(this.isBlockTarget);
					}

					if (that.ajaxCount == 0) {
						$.loadUnBlock();
					}
					if (this.dataType == 'html') {
						cfg.successCall(data);
						return;
					}

					if (typeof data.RES == "undefined") {
						alert("알수없는 오류가\n발생 하였습니다.\n관리자 에게 문의 해주세요");
						return;
					}

					if (data != null) {
						if (data.RES.returnCode == "02" ) {		//02 실패
							var msg = data.RES.returnMsg;
							var rUrl = data.RES.returnUrl;

							alert(msg.replace(/\\n/g, "\n"));

							if (rUrl != "null" && $.trim(rUrl).length > 0) {

								if (rUrl == 'HISTORYBACK') {
									history.go(-1);
									return;
								}else if(rUrl == 'SELFCLOSE'){
									window.parent.lyPop.close();
									return;
								}
								top.location.href = rUrl;
							}
							if (cfg.errorCall != undefined) {
								cfg.errorCall(data);
							}
							return;
						}else if (data.RES.returnCode == "06" ){  //06 에러공지
							var msg = data.RES.returnMsg;
							$.layerError(cfg.isBlockTarget , msg) ;
							return;
						}else if (data.RES.returnCode == "08"){  // 08 접근권한
							var msg = data.RES.returnMsg;
							$.layerAlert(cfg.isBlockTarget , msg) ;
							return;
						} 
					}
					cfg.successCall(data);
				}
			});
		};

		this.onCreate = function() {
		};

		this.eventInit = function() {
		};

		this.enterToBr = function(str) {
			var strReturn = "";
			strReturn = str.replace(/\n/g, "<br>").replace(/\\n/g, "<br>");
			return strReturn;
		};

		// null check
		this.nvl = function(s, s2) {
			var retStr = "";
			s = $.trim(s);
			if (s != null && s !== "") {
				retStr = s;
			} else {
				retStr = s2;
			}

			return retStr;
		};

		//이메일 유효성 체크
		this.emailValidate = function(str) {
			var regExp = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
			if(!regExp.test(str)){
				return true;
			} else {
				return false;
			}
		};

		//숫자 유효성 체크
		this.numberValidate = function(str) {
			var regExp = /^[0-9]+$/;
			if(!regExp.test(str)){
				return true;
			} else {
				return false;
			}
		}

		this.init = function() {
			that.$body = $('body');
			this.eventInit();
			this.onCreate();
			if (isCommonEvent == false) {
				this.commonEvent();
			}

			//$("#returnUrl").val(location.pathname);

		};

		this.maxLengthCheck = function(object) {
			if (object.value.length > object.maxLength) {
				object.value = object.value.slice(0, object.maxLength);
			}
		};

		// 날짜 반환
		this.converDateString = function(dt,h){
			return dt.getFullYear() + h + this.addZero(eval(dt.getMonth()+1)) + h + this.addZero(dt.getDate());
		};

		this.addZero = function(i){
			var rtn = i+100;
			return rtn.toString().substring(1,3);
		};

		// 공통 이벤트 바인딩
		this.commonEvent = function () {

			isCommonEvent = true;

			// 숫자만 입력가능 (ex: <input type="text" class="onlyNum" />)
			$(document).on("keyup keypress blur", ".onlyNum", function(e) {
				$(this).val($(this).val().replace(/[^0-9]/gi, ""));
			});

			// 영어, 숫자
			$(document).on("keyup keypress blur", ".onlyNumEng", function(event) {
				var pattern = /[^\sa-zA-Z0-9\.]/g;
				$(this).val($(this).val().replace(pattern, ""));
			});

			// 완성형 한글, 영어 (ex: <input type="text" class="nameRegular"
			$(".nameRegular").blur(function() {
				var pattern = /[^\s가-힝a-zA-Z]/g;
				if (pattern.test($(this).val())) {
					alert("완성된 한글, 영어만\n입력가능합니다.");
					$(this).val($(this).val().replace(pattern, ""));
					$(this).focus();
				}
			});


			//Disable browser refresh key [F5, Ctrl + F5, Ctrl + R, Shift + Ctrl + R]
			$(document).on("keydown", function(e) {
				/*var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
				var event = window.event || e;
				if(event.keyCode == 116 || event.ctrlKey && event.keyCode == 82) {
					event.keyCode = 0; // ie7,8
					if(!isFirefox) alert("현재 화면에서는 새로고침을 하실 수 없습니다.");
					return false;
				}*/
			});

		};

		// 우편번호에 하이픈추가
		this.addHyphenZip = function(zipCode) {
			if (zipCode != undefined && zipCode.length == 6) {
				return zipCode.replace(/(^.{3})(.)/, '$1-$2');
			} else {
				return zipCode;
			}
		};

		this.addCom = function(paramInt) {
			if (isNaN(paramInt)) {
				return 0;
			}
			var reg = /(^[+-]?\d+)(\d{3})/; // 정규식
			var rtnValue = paramInt + ''; // 숫자를 문자열로 변환

			while (reg.test(rtnValue)) {
				rtnValue = rtnValue.replace(reg, '$1,$2');
			}
			return rtnValue;
		};

		// 월의 끝 일자 얻기 (param = yyyyMM)
		this.getEndDate = function(datestr) {
			var yy = Number(datestr.substring(0, 4));
			var mm = Number(datestr.substring(4, 6));
			// 윤년 검증
			var boundDay = "";
			if (mm != 2) {
				var mon = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
				boundDay = mon[mm - 1];
			} else {
				if (yy % 4 == 0 && yy % 100 != 0 || yy % 400 == 0) {
					boundDay = 29;
				} else {
					boundDay = 28;
				}
			}
			return boundDay;
		};


		// 해당 월의 전체 일자 얻기 (param = yyyyMM)
		this.getMonthAllDateArray = function (datestr) {
			var arrayDate = new Array();

			var lastDate = this.getEndDate(datestr);
			lastDate = parseInt(lastDate);
			for (var i=1; i <= lastDate; i++) {
				arrayDate.push(i);
			}

			return arrayDate;
		};

		// 월이 1자리 일경우 앞에 0붙이기
		this.addMMZero = function (date) {
			date = date + "";
			if (date.length == 1) {
				date = "0" + date;
			}
			return date;
		}

		// 레이어 팝업 box로 alert 보여주는 함수
		// TODO : 추후변경필요.
		this.msgBoxAlert = function(msg, rtnObj) {

			alert(msg);

		};

	}
});


$(document).ready(function(){

	var CommonObj = new $.CommonObj();
	var varData = CommonObj.getSerializedData({
		locateUri : location.pathname
	});

	// 로그인 페이지로 이동
	$(document).on("click", "#btnLoginForm", function() {
		goLoginForm();
	});
		
	// 로그아웃
	$(document).on("click", "#btnLogout", function() {
		
		if (!confirm("로그아웃 하시겠습니까?")) {
			return false;
		}
		
		if($("#nativeOs").val() =="") {
			logOut();
		} else {
			appLogout();
		}
	});

	//footer 이메일집단수집거부 팝업
	$(document).on("click", "#btnAgreeEmailId", function() {
		$("#emailLyPop").show();
		$("#emailLyPop").css("position", "fixed");
	});

	// 캡챠 새로고침
	$("#btnCaptchaImage").click(function() {
		var rand = "pageType=JAJ&r=" + Math.floor(Math.random() * 999999) + 100000; //
		$("#imgCaptcha").attr("src", contextPath +"/common/CapchaCertInput.do?" + rand);
		$("#captchachk").val("");
		$("#captcha").val("");
		return false;
	});

	if ($("#summaryInfo").length > 0) {
		setInterval(riding.getSummary, 3 * 60 * 1000);
	}
});

function getCookie(cookieName) {
	cookieName = cookieName + "=";
	var cookieData = document.cookie;
	var start = cookieData.indexOf(cookieName);
	var cookieValue = "";
	if (start != -1) {
		start += cookieName.length;
		var end = cookieData.indexOf(";", start);
		if (end == -1) end = cookieData.length;
		cookieValue = cookieData.substring(start, end);
	}
	return unescape(cookieValue);
}

function checkpw(pwd) {
	var len = pwd.length;
	for(var i=0;i<len;i++){
		if(i+3 < len){
			if(pwd.charCodeAt(i)+1 == pwd.charCodeAt(i+1)
				&& pwd.charCodeAt(i+1)+1 == pwd.charCodeAt(i+2)
				&& pwd.charCodeAt(i+2)+1 == pwd.charCodeAt(i+3)){
				return true;
			}
		}
	}
	return false;
}

var isValidEmail = function(emailAddr){
	var emailPattern = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	if(!emailPattern.test(emailAddr)){
		return false;
	}else{
		return true;
	}
}

function splitComma(str) {
	if (isNaN(str) || str == "") {
		return "";
	} else {
		str = str - 0;
		var txtNumber = String(str);
		var rxSplit = new RegExp('([0-9])([0-9][0-9][0-9][,.])');
		var arrNumber = txtNumber.split('.');
		arrNumber[0] += '.';
		do
		{
			arrNumber[0] = arrNumber[0].replace(rxSplit, '$1,$2');
		} while (rxSplit.test(arrNumber[0]));
		if (arrNumber.length > 1) {
			return arrNumber.join('');
		}else {
			return arrNumber[0].split('.')[0];
				}
		}
}

function isNullAndLen(input, size) {
	if (input == null || input == "") {
		return true;
	} else {
		if (input.length >= size) {
			return false;
		} else {
			return true;
		}
	}
}

function inValidParam(input) {
	if(input == undefined || input == '[object Object]' || input == '') {
		return true;
	}
	return false;
}



function fn_addHidden(theForm, key, value) {
	var input = $('<input>').attr({type: 'hidden', name: key, value : value});
	input.appendTo(theForm);
}
function fn_replaceAll(source,orgStr,chngStr){
	return  source.split(orgStr).join(chngStr);
}
function fn_replaceNewLine (str) {
	str = str.replace(/(?:\r\n|\r|\n)/g, '<br />');
	return str;
}

function fn_comma(str) {
	str = String(str);
	return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
}

function fn_setCombo(comboExpr,dataRows,code,name,allCode,allName,selectedValue)
{
	var $combo = $(comboExpr);
	$combo.empty();
	if(allCode)
	{
		if(allCode == selectedValue)
		{
			$combo.append('<option selected value="'+fn_encodeHtml(allCode)+'">'+fn_encodeHtml(allName)+'</option>');
		}
		else
		{
			$combo.append('<option value="'+fn_encodeHtml(allCode)+'">'+fn_encodeHtml(allName)+'</option>');
		}
	}
	$(dataRows).each(function(i,row){
		if(row[code] == selectedValue)
		{
			$combo.append($('<option selected value="'+fn_encodeHtml(row[code])+'">'+fn_encodeHtml(row[name])+'</option>').data('row',row));
		}
		else
		{
			$combo.append($('<option value="'+fn_encodeHtml(row[code])+'">'+fn_encodeHtml(row[name])+'</option>').data('row',row));
		}
	});
}
//콤보에 목록에 특정 목록츨 추가한다.
//comboExpr 은 Combo object id 또는 Combo object
//Value는 콤보의 Value값
//name은 콤보의 명칭
//selectedTF가 true면 아이템 추가후 선택처리 false면 아이템추가만 한다.
function fn_setComboAddItem(comboExpr,value,name,selectedTF)
{
	var $combo = $(comboExpr);
	if (selectedTF) {
		$combo.append('<option selected value="'+fn_encodeHtml(value)+'">'+fn_encodeHtml(name)+'</option>');
	} else {
		$combo.append('<option value="'+fn_encodeHtml(value)+'">'+fn_encodeHtml(name)+'</option>');
	}
}
//콤보의 내용을 지운다.
function fn_clearComboItems(comboExpr)
{
	var $combo = $(comboExpr);
	$combo.empty();

}

function fn_encodeHtml(s)
{
	if(s == null || s == undefined) return "";
	var el = document.createElement("div");
	el.innerText = el.textContent = s;
	s = el.innerHTML;
	delete el;
	return s.replace(/ /g,'&nbsp;');
}
function fn_enterkey(obj,func){
	$(obj).on({
    keyup : function(event){
    	if(event.keyCode == 13){
    		eval (func + "();");
    		obj.blur();
    	}
    }
});
}
function fn_callAjax(action, reqObj, succFunc){
	controller.ajaxSend( {
		url : contextPath + action
		, data : reqObj
		, dataType : 'json'
		, type : 'post'
		, async : false	
		, isBlock : true
		, isOverLap : true
		, successCall: succFunc
});
}

function fn_callAjaxAsync(action, reqObj, succFunc){
	controller.ajaxSend( {
		url : contextPath + action
		, data : reqObj
		, dataType : 'json'
		, type : 'post'
		, async : true	
		, isBlock : true
		, isOverLap : true
		, successCall: succFunc
});
}

//입력값이 NULL인지 체크
function fn_isNull(asValue)
{
    if (asValue == null || asValue == undefined || asValue.toString() == "")
    {
        return true;
    }
    
    return false;
}

//기본값
function fn_nvl(asValue,asDefValue)
{
	return fn_isNull(asValue) ? (fn_isNull(asDefValue) ? "": asDefValue) : asValue;
}

//로딩 fn_loading(true);
function fn_loading(flag){
	if(flag){
		$('body').addClass('lodingHold');
		$(".loding").show();
	}else{
		$(".loding").hide();
		$('body').removeClass('lodingHold');
	}
}

function goLogin(){
	top.location.href=contextPath+'/login.do';
}

function goMain(){
	top.location.href=contextPath+'/main.do';
}

function searchPopup(title,text, msg, btn){
	$("#searchPopupTitle").text(title);
	$("#searchPopupText").html(text);
	$("#searchPopupMsg").html(msg);
	$("#searchPopupBtnName").text(btn);
	$("#searchPopup").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}