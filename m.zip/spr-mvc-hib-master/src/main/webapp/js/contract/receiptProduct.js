/**
 * 가입신청서 > 상품정보
 */
$(function(){
	
	var controller = new $.CommonObj();
	
	//상품정보 입력 템플릿 컨테이너
	var container = {
		$: $('[data-id="template-container"]'),
		moRecvNo: null,//스마트청약접수번호 - 임시 저장 데이터 수정 모드 일 경우 셋팅된다.
		itemList: [],
		//상품입력폼 추가
		addItem: function(type, initData, isSavedData){
			//추가할 상품 입력 템플릿 생성
			var obj = type.create(initData);
			
			//스택에 추가
			this.itemList.push(obj);
			
			//화면에 셋팅
			this.$.append(obj.$item);
			this.itemScroll(obj, !isSavedData);
			
			this.onComplete();
			
			//상품 추가 버튼 숨김 처리
			addButtonController.check();
		},
		//스크롤 처리
		itemScroll: function(obj, isExpand){
			
			//펼쳐져있는 기존 상품 입력폼 접기
			this.$.find('[data-product-template].open').removeClass("open");
			
			if(isExpand===undefined || isExpand===true){
				//새로운 상품 입력폼 펼침
				obj.$item.addClass('open');
			}
			obj.$item.show();
			
			var scrollTop = cm.getScrollTop() + obj.$item.get(0).getBoundingClientRect().top - $('.header').outerHeight();
			$('html,body').stop().animate({scrollTop: scrollTop}, {
				duration: 300
			});
		},
		//상품입력폼 삭제
		deleteItem: function(obj){
			for(var i=0 ; i<this.itemList.length ; i++){
				if(this.itemList[i]===obj){
					this.itemList.splice(i,1);
					break;
				}
			}
			
			//임시저장 데이터 일 경우 데이터삭제
			if(obj.initData && obj.initData.moRecvNo && obj.initData.moScrbrNo){
				var data = {
					moPrdtTypeCd: obj.initData.prdtTypeCd,
					moRecvNo    : obj.initData.moRecvNo,
					moScrbrNo   : obj.initData.moScrbrNo
				};
				
				console.log("/contract/deleteProduct.json input : ", data);
				
				//이벤트 상품 정보 조회
				cm.ajax(controller, "/contract/deleteProduct.json", data, true, function(r){
					
					console.log("/contract/deleteProduct.json result : ", r);
					
					obj.remove();
					addButtonController.check();
					container.onComplete();
				});//end of ajax
			}
			else{
				obj.remove();
				addButtonController.check();
				container.onComplete();
			}
		},
		getItemLength: function(type){
			if(type===tv){
				return this.$.find('[data-product-template="01"]').length;
			}
			if(type===internet){
				return this.$.find('[data-product-template="02"]').length;
			}
			if(type===rental){
				return this.$.find('[data-product-template="03"]').length;
			}
			return this.$.find('[data-product-template]').length;
		},
		onComplete: function(obj){
			//다음 버튼 활성/비활성
			var $items = this.$.find('[data-product-template]');
			if($items.length > 0 && $items.length === $items.filter('.completed').length){
				this.next.enable();
			}
			else{
				this.next.disable();
			}
			//소계 표시 활성/비활성
			this.summary.set();
		},
		//작성완료 되지 않은 상품입력 템플릿 객체를 반환한다.
		getIncomplete: function(){
			var obj;
			for(var i=0 ; i<this.itemList.length ; i++){
				obj = this.itemList[i];
				if(!obj.isComplete()){
					return obj;
				}
			}
			return null;
		},
		//작성 완료 된 상품입력 템플릿 객체를 반환한다.
		getCompleteList: function(){
			var list = [];
			for(var i=0 ; i<this.itemList.length ; i++){
				obj = this.itemList[i];
				if(obj.isComplete()){
					list.push(obj);
				}
			}
			return list;
		},
		//2개이상일 경우 소계금액
		summary: {
			isInit: false,
			$: $('[data-container="summary"]'),
			set: function(){
				
				//임시 저장 데이터 셋팅시 한번만 로직 처리 되기 위해 확인한다.
				if(!this.isInit && container.initDataList && container.initDataList.length>0){
					if(container.$.find('[data-product-template].completed').length !== container.initDataList.length){
						return;
					}
				}
				this.isInit = true;
				
				//작성 완료한 상품이 1개일 경우 숨김
				if(container.$.find('[data-product-template].completed').length < 2){
					this.$.hide();
					return;
				}

				//TV + 인터넷이 존재할 경우 인터페이스 호출을 통해 할인금액을 조회하기 때문에 TV/인터넷만 추출한다.
				var list = container.getCompleteList();
				var tv, internet, obj;
				for(var i=0 ; i<list.length ; i++){
					obj = list[i];
					if(obj.PRDT_TYPE_CD==='01'){
						tv = obj;
					}
					else if(obj.PRDT_TYPE_CD==='02'){
						internet = obj;
					}
				}
				
				//TV, 인터넷이 있을 경우 결합예상요금(할인요금) 조회 한다.
				if(tv && internet){
					var input_product004 = {
						list: []
					};
					var tvData = tv.getData();
					input_product004.list.push({
						eventNo   : tvData.eventNo,//이벤트번호   - 신규+신규 결합인 경우
						prdtTypeCd: tvData.prdtTypeCd//상품구분코드 - 신규+신규 결합인 경우 - 01:TV, 02:인터넷, 03:홈렌탈
					});
					var internetData = internet.getData();
					input_product004.list.push({
						eventNo   : internetData.eventNo,
						prdtTypeCd: internetData.prdtTypeCd
					});
					
					//결합예상요금조회(할인요금)
					cm.ajax(controller, "/contract/action/product004.json", input_product004, true, function(r){
						container.summary._set(r.INF_SCS_027.combiPsumAmt);
					}, true);//end of ajax
				}
				else{
					container.summary._set();
				}
			},
			/**
			 * @param {string|number} combiPsumAmt 할인될금액
			 */
			_set: function(combiPsumAmt){
				var list = container.getCompleteList();
				var obj;
				var rentalPrdtData;//홈렌탈 - 선택되어있는 상품 데이터
				var MO_MONTH_INVCE_AMT = 0;//월예상납부액
				var MO_TOT_INVCE_AMT   = 0;//일시불납부액
				for(var i=0 ; i<list.length ; i++){
					obj = list[i];
					//TV
					if(obj.PRDT_TYPE_CD==='01'){
						MO_MONTH_INVCE_AMT += cm.format.toNumber(obj.amt.MO_MONTH_INVCE_AMT);
						MO_TOT_INVCE_AMT   += cm.format.toNumber(obj.amt.MO_TOT_INVCE_AMT);
					}
					//internet
					else if(obj.PRDT_TYPE_CD==='02'){
						MO_MONTH_INVCE_AMT += cm.format.toNumber(obj.amt.MO_MONTH_INVCE_AMT);
						MO_TOT_INVCE_AMT   += cm.format.toNumber(obj.amt.MO_TOT_INVCE_AMT);
					}
					//홈렌탈
					else{
						rentalPrdtData = obj.input.PRDT_CD.data();//현재 선택된 상품 데이터
						//일시불
						if(cm.format.number(rentalPrdtData.instmPerd) <= 1){
							MO_TOT_INVCE_AMT += cm.format.toNumber(obj.amt.MO_TOT_INVCE_AMT);
						}
						//할부
						else{
							MO_MONTH_INVCE_AMT += cm.format.toNumber(obj.amt.MO_MONTH_INVCE_AMT);
						}
					}
				}
				MO_MONTH_INVCE_AMT = MO_MONTH_INVCE_AMT - cm.format.toNumber(combiPsumAmt);
				
				//100원이하 절사
				MO_MONTH_INVCE_AMT = parseInt(MO_MONTH_INVCE_AMT);
				MO_MONTH_INVCE_AMT = MO_MONTH_INVCE_AMT - (MO_MONTH_INVCE_AMT % 100);
				
				//월예상납부액
				this.$.find('[data-item="MO_MONTH_INVCE_AMT"]').find('[data-value-item]').text( cm.format.number(MO_MONTH_INVCE_AMT) );
				
				//일시불납부액
				this.$.find('[data-item="MO_TOT_INVCE_AMT"]').find('[data-value-item]').text( cm.format.number(MO_TOT_INVCE_AMT) );
				if(MO_TOT_INVCE_AMT===0){
					this.$.find('[data-item="MO_TOT_INVCE_AMT"]').hide();
				}
				else{
					this.$.find('[data-item="MO_TOT_INVCE_AMT"]').show();
				}
				
				this.$.show();
			},
			init: function(){
				this.isInit = true;
				this.set();
			}
		},
		//다음버튼처리
		next: {
			$btn: $('[data-id="btnNextPage"]').click(function(e){
				e.preventDefault();
				
				if(container.getItemLength()===0){
//					cm.message.alert({
//						text: '신청 할 상품이 존재하지 않습니다.'
//					});
					return;
				}
				var obj = container.getIncomplete();
				if(obj){
					cm.message.alert({
						title: '상품정보 작성 미완료',
						text: '작성중인 상품이 존재합니다.<br>작성완료 또는 삭제 후 진행해주세요.'
					}, function(){
						container.itemScroll(obj);
					});
					return;
				}
				container.next.execute();
			}),
			enable: function(){
				this.$btn.removeClass('disabled').addClass('red');
			},
			disable: function(){
				this.$btn.removeClass('red').addClass('disabled');
			},
			execute: function(){
				var saveData = {
					moMonthInvceAmtRecv: "0",//월예상납부액
					moTotInvceAmtRecv: "0"//결합 월 예상납부액
				};
				
				var obj, rowdata, newKey;
				for(var i=0 ; i<container.itemList.length ; i++){
					obj = container.itemList[i];
					rowdata = obj.getData();
					for(var key in rowdata){
						newKey = key + '[' + i + ']';
						saveData[ newKey ] = rowdata[key];
						
						//임시저장 모드 일 경우 moRecvNo(스마트청약접수번호) 값이 없으면 신규 상품
						if(key==='moRecvNo' && !rowdata[key] && container.moRecvNo){
							saveData[ newKey ] = container.moRecvNo;
						}
					}
				}
				
				console.log("save data : ", saveData);
				
				cm.ajax(controller, "/contract/saveReceiptProduct.json", saveData, true, function(r){
					console.log("save result : ", r);
					
					if(r.retCode!=="SUCC"){
						cm.message.alert({
							title: "오류안내",
							text: r.retMsg
						});
						return;
					}
					
					var $form = $("#__next__");
					$form.find('input[name="moRecvNo"]').val( r.moRecvNo );//스마트청약접수번호
					$form.submit();
				});//end of ajax
			}
		},
		init: function(){
			var initData = {
				prdtTypeCd : $('input[name="prdtTypeCd"]').val(),//상품구분코드
				moPrdtGrpCd: $('input[name="moPrdtGrpCd"]').val()//스마트청약대그룹코드
			};
			//상품구분코드, 스마트청약대그룹코드 파라미터가 있을 경우
			if(initData.prdtTypeCd){
				switch(initData.prdtTypeCd){
					case tv.PRDT_TYPE_CD:
						container.addItem(tv, initData);
						break;
					case internet.PRDT_TYPE_CD:
						container.addItem(internet, initData);
						break;
					case rental.PRDT_TYPE_CD:
						container.addItem(rental, initData);
						break;
				}
			}
			//스마트청약접수번호 가 있을경우
			else{
				var moRecvNo = $('#__next__ input[name="moRecvNo"]').val();
				if(!moRecvNo){
					return;
				}
				
				this.moRecvNo = moRecvNo;
				
				var data = {
					moRecvNo: moRecvNo
				};
				cm.ajax(controller, "/contract/action/product005.json", data, true, function(r){
					if(r.retCode!=="SUCC"){
						cm.message.alert({
							title: "오류안내",
							text: r.retMsg
						});
						return;
					}
					
					var list = r.cntrtInfoList;
					if(!list || list.length===0){
						return;
					}
					
					console.log("임시저장데이터 :cntrtInfoList: ", list);
					
					container.initDataList = list;
					
					var rowdata, len=list.length;
					for(var i=0 ; i<len ; i++){
						rowdata = list[i];
						switch(rowdata.prdtTypeCd){
							case tv.PRDT_TYPE_CD:
								container.addItem(tv, rowdata, true);
								break;
							case internet.PRDT_TYPE_CD:
								container.addItem(internet, rowdata, true);
								break;
							case rental.PRDT_TYPE_CD:
								container.addItem(rental, rowdata, true);
								break;
						}
					}
				});//end of ajax
			}
		}
	};//end of container
	
	//상품정보 입력 템플릿  : TV
	//PRDT_TYPE_CD(상품구분코드) : 01
	var tv = {
		PRDT_TYPE_CD: "01",
		init: function(){
			this.temp.init();
		},
		temp: {
			$: null, //템플릿을 저장한다.
			init: function(){
				//템플릿 초기화
				this.$ = $('[data-product-template="01"]').remove();
			},
			get: function(){
				var $item = this.$.clone();
				return $item;
			}
		},
		create: function(initData){
			var obj = {};
			var $item = this.temp.get();
			obj.$item = $item;
			obj.amt   = {};//월예상금액 등 계산된 금액을 저장할 변수
			obj.PRDT_TYPE_CD = this.PRDT_TYPE_CD;
			
			/**
			 * 작성완료처리
			 * @param {boolean} flag 완료여부
			 */
			obj.complete = function(flag){
				if(flag){
					this.$item.addClass('completed');
				}
				else{
					this.$item.removeClass('completed');
				}
				container.onComplete(this);
			};
			
			/**
			 * 작성완료여부를 반환
			 */
			obj.isComplete = function(){
				return this.$item.hasClass('completed');
			};
			
			/**
			 * 삭제처리
			 * @param {boolean} flag 완료여부
			 */
			obj.remove = function(){
				this.$item.remove();
				addButtonController.check();
			};
			
			/**
			 * 저장 할 데이터를 반환한다.
			 */
			obj.getData = function(){
				var result = {};
				
				result.moRecvNo       = obj.initData ? $.trim(obj.initData.moRecvNo) : "";//스마트청약접수번호
				result.moScrbrNo      = obj.initData ? $.trim(obj.initData.moScrbrNo) : "";//스마트청약가입계약번호
				result.prdtTypeCd     = this.PRDT_TYPE_CD;//상품구분코드.TV,인터넷,렌탈
				result.moPrdtGrpCd    = this.input.MO_PRDT_GRP_CD.val();//상품유형(스마트청약대그룹코드)
				
				var eventData         = this.input.EVENT_NO.getEventData();
				result.eventNo        = eventData.eventNo;//이벤트번호(TV,인터넷)
				result.eventNm        = eventData.eventNm;//이벤트명(TV,인터넷)
				result.eventPrdtGrpCd = eventData.eventPrdtGrpCd;//이벤트상품그룹코드(TV,인터넷)
				result.eventPrdtGrpNm = eventData.eventPrdtGrpNm;//이벤트상품그룹명(TV,인터넷)
				result.dutyUsePerd    = eventData.dutyUsePerd;//약정기간(TV,인터넷)

				result.moMonthInvceAmt= this.amt.MO_MONTH_INVCE_AMT;//월예상납부액
				result.moChrg         = this.amt.MO_CHRG;//시청료
				result.moLseAmt       = this.amt.MO_LSE_AMT;//모델장비임대료
				result.moTotInvceAmt  = "0";//일시불납부액(홈렌탈)
				result.rentalSellerCd = "";//판매처코드(홈렌탈)
				result.rentalSellerNm = "";//판매처명(홈렌탈)
				result.prdtCd         = "";//상품코드(인터넷,홈렌탈)
				result.prdtNm         = "";//상품명(인터넷,홈렌탈)
				result.termInstalClCd = "";//단말설치유형
				result.recvClType     = "";//접수유형(홈렌탈)
				result.prdtGrpCd      = "";//상품종류(홈렌탈)
				result.moMultiCnt     = "0";//복수가입수량
				result.buyMthCd       = "2";//구매형태(홈렌탈) - 1:일시불,2:할부
				result.moInstmCd      = "";//일시불할부구분(홈렌탈)
				result.moPrdtAmt      = "0";//구매단가(홈렌탈)
				
				return result;
			};
			
			//ui 공통에서 적용된 selectOrDir 제거
			$item.find('select').selectOrDie("destroy");
			
			obj.input = {
				//상품유형(스마트청약대그룹코드)
				MO_PRDT_GRP_CD: {
					$elem: $item.find('select[data-id="MO_PRDT_GRP_CD"]').selectOrDie({
						onChange: function(){
							//이벤트 번호 초기화
							obj.input.EVENT_NO.reset();
							
							if(this.value==="__NONE__"){
								obj.input.EVENT_PRDT_GRP_CD.set();
							}
							else{
								cm.code.memCache.getList(controller, this.value, function(list){
									obj.input.EVENT_PRDT_GRP_CD.set(list);
								});
							}
						}
					}),
					val: function(){
						return this.$elem.val();
					},
					set: function(list, value){
						if(value){
							this.$elem.find('option[value="' + value + '"]').prop('selected', true);
							this.$elem.trigger('change');
						}
					}
				},
				//상품종류(이벤트상품그룹코드)
				EVENT_PRDT_GRP_CD: {
					isInit: false,
					$elem: $item.find('select[data-id="EVENT_PRDT_GRP_CD"]').selectOrDie(),
					val: function(){
						return this.$elem.val();
					},
					text: function(){
						return this.$elem.children(':selected').text();
					},
					set: function(list){
						if(!list || list.length===0){
							this.$elem.children().not('[value="__NONE__"]').remove();
							this.$elem.selectOrDie("destroy").selectOrDie();
						}
						else{
							//상품종류(이벤트상품그룹코드) 콤보 초기화
							fn_setCombo(this.$elem, list, "cd", "cdNm", "__NONE__", "선택해주세요.");
							this.$elem.selectOrDie("destroy").selectOrDie({
								onChange: function(){
									//이벤트 번호 초기화
									obj.input.EVENT_NO.reset();
								}
							});
							
							//임시 저장 데이터 셋팅
							if(!this.isInit){
								this.isInit = true;
								if(obj.initData && obj.initData.eventPrdtGrpCd){
									this.$elem.find('option[value="' + obj.initData.eventPrdtGrpCd + '"]').prop('selected', true);
									this.$elem.trigger('change');
									
									//임시 저장 데이터 셋팅
									obj.input.EVENT_NO.init();
								}
							}
						}
					}
				},
				//약정기간(의무사용기간)
				DUTY_USE_PERD: {
					$elem: $item.find('select[data-id="DUTY_USE_PERD"]').selectOrDie({
						onChange: function(){
							//이벤트 번호 초기화
							obj.input.EVENT_NO.reset();
						}
					}),
					val: function(){
						return this.$elem.val();
					},
					set: function(list, value){
						if(value){
							var $option = this.$elem.find('option[value="' + value + '"]');
							if($option.length===0){
								$option = this.$elem.find('option[value="0"]');
							}
							$option.prop('selected', true);
							this.$elem.trigger('change');
							
							//임시 저장 데이터 셋팅
							obj.input.EVENT_NO.init();
						}
					}
				},
				//사용자 입력 검색조건
				userInputText: {
					$elem: $item.find('input[data-id="userInputText"]'),
					val: function(){
						return $.trim(this.$elem.val());
					}
				},
				//이벤트번호:
				EVENT_NO: {
					$elem: $item.find('select[data-id="EVENT_NO"]').selectOrDie(),
					val: function(){
						return this.$elem.val();
					},
					reset: function(){
						this.$elem.children().not('[value="__NONE__"]').remove();
						this.$elem.selectOrDie("destroy").selectOrDie();
						obj.complete(false);//작성완료처리
						obj.input.EVENT_NO.setEventDataDetail(null);//이벤트상품데이터초기화
					},
					set: function(list, value){
						fn_setCombo(this.$elem, list, "eventNo", "eventNm", "__NONE__", "선택해주세요.");
						this.$elem.selectOrDie("destroy").selectOrDie({
							onChange: function(){
								if(this.value==="__NONE__"){
									obj.input.EVENT_NO.setEventDataDetail(null);//이벤트상품데이터초기화
									obj.complete(false);//작성완료처리
								}
								else{
									var data = {
										eventNo: this.value
									};
									//이벤트 상품 정보 조회
									cm.ajax(controller, "/contract/action/product002.json", data, true, function(r){
										obj.input.EVENT_NO.setEventDataDetail(r.INF_SCS_026);
										obj.complete(true);//작성완료처리
									}, true);//end of ajax
								}
							}
						});
						
						if(value){
							this.$elem.find('option[value="' + value + '"]').prop('selected', true);
							this.$elem.trigger('change');
						}
					},
					//이벤트 데이터 select 의 선택된 항목의 데이터를 반환한다.(INF_SCS_004 결과)
					getEventData: function(){
						return this.$elem.children(":selected").data('row');
					},
					//이벤트 상품 정보 상세 조회 결과 데이터를 셋팅한다.
					setEventDataDetail: function(d){
						if(!d){
							this.eventDataDetail = null;
							obj.$item.find('[data-id="MO_MONTH_INVCE_AMT"]').text('-');
							obj.$item.find('[data-id="MO_CHRG"]').text('-');
							obj.$item.find('[data-id="MO_LSE_AMT"]').text('-');
							return;
						}
						
						this.eventDataDetail = d;
						
						//시청료
						var MO_CHRG = cm.format.toNumber(d.responseEventPolicyInfoVO.watchPrdtRecvChrg);//시청상품수신료
						
						//임대료
						var MO_LSE_AMT = 0;
						var list = d.responseIrdPrdtListVO;
						if(list && list instanceof Array){
							var rowdata;
							for(var i=0 ; i<list.length ; i++){
								rowdata = list[i];
								//장비유형코드(equipClCd="1")가 수신기인 데이터
								if(rowdata.equipClCd==='1'){
									MO_LSE_AMT += cm.format.toNumber(rowdata.lseAmt);//임대료
								}
							}
						}
						
						//월예상납부액
						var MO_MONTH_INVCE_AMT = MO_CHRG + MO_LSE_AMT;
						
						obj.$item.find('[data-id="MO_MONTH_INVCE_AMT"]').text( cm.format.number(MO_MONTH_INVCE_AMT) );
						obj.$item.find('[data-id="MO_CHRG"]').text( cm.format.number(MO_CHRG) );
						obj.$item.find('[data-id="MO_LSE_AMT"]').text( cm.format.number(MO_LSE_AMT) );
						
						obj.amt = {
							MO_CHRG: MO_CHRG,
							MO_LSE_AMT: MO_LSE_AMT,
							MO_MONTH_INVCE_AMT: MO_MONTH_INVCE_AMT
						};
					},
					//선택된 이벤트의 상세조회 데이터를 반환한다.(INF_SCS_026 결과)
					getEventDataDetail: function(){
						return this.eventDataDetail;
					},
					//임시 저장 데이터 셋팅
					isInit: false,
					isInitInquiry: false,
					init: function(){
						if(obj.input.MO_PRDT_GRP_CD.val()==='__NONE__'){
							return;
						}
						if(obj.input.EVENT_PRDT_GRP_CD.val()==='__NONE__'){
							return;
						}
						if(obj.input.DUTY_USE_PERD.val()==='__NONE__'){
							return;
						}
						if(this.isInit){
							return;
						}
						this.isInit = true;
						$item.find('[data-id="btnInquiry"]').trigger('click');
					}
				}
			};
			
			//접기 펼치기 이벤트 처리
			$item.find(".clpsTit").off().on('click', function(){
				$item.toggleClass("open");
			});
			
			//조회버튼
			$item.find('[data-id="btnInquiry"]').click(function(e){
				e.preventDefault();
				
				//이벤트 번호 초기화
				obj.input.EVENT_NO.reset();
				
				if(obj.input.MO_PRDT_GRP_CD.val()==='__NONE__'){
					cm.message.alert({text: "상품유형을 선택해주세요."});
					return;
				}
				if(obj.input.EVENT_PRDT_GRP_CD.val()==='__NONE__'){
					cm.message.alert({text: "상품종류를 선택해주세요."});
					return;
				}
				if(obj.input.DUTY_USE_PERD.val()==='__NONE__'){
					cm.message.alert({text: "약정기간을 선택해주세요."});
					return;
				}
				
				var data = {
					prdtTypeCd      : obj.PRDT_TYPE_CD, //상품구분코드
					eventPrdtGrpCd  : obj.input.EVENT_PRDT_GRP_CD.val(), //이벤트상품그룹코드
					eventNo         : "", //이벤트번호 
					eventNm         : "", //이벤트명 
					dutyUsePerd     : obj.input.DUTY_USE_PERD.val() //의무사용기간 
				};
				
				//사용자입력검색조건
				var userInputText = obj.input.userInputText.val();
				//숫자 10자리 일 경우
				if(/^[\d]{10}$/.test(userInputText)){
					data.eventNo = userInputText;
				}
				else{
					data.eventNm = userInputText;
				}
				
				//청약상품정보조회
				cm.ajax(controller, "/contract/action/product001.json", data, true, function(r){
					//임시 저장 데이터 셋팅
					var selectValue = null;
					if(!obj.input.EVENT_NO.isInitInquiry){
						obj.input.EVENT_NO.isInitInquiry = true;
						if(obj.initData && obj.initData.eventNo){
							selectValue = obj.initData.eventNo;
						}
					}
					
					if(r.INF_SCS_004){
						//정상
						if(r.INF_SCS_004.rsltCd === '000'){
							obj.input.EVENT_NO.set(r.INF_SCS_004.responseEventListVO, selectValue);
						}
						//조회결과없음
						else if(r.INF_SCS_004.rsltCd === '199'){
							cm.message.alert({
								text: '조건에 해당하는 상품이<br>존재하지 않습니다.'
							});
						}
						//기타오류
						else{
							cm.message.alert({
								title: '처리중 오류가 발생했습니다.',
								text: '잠시 후 다시 시도해주세요.',
								subText: '사유  : ' + r.INF_SCS_004.rsltMsg
							});
						}
					}
					else{
						cm.message.alert({
							title: '처리중 오류가 발생했습니다.',
							text: '잠시 후 다시 시도해주세요.'
						});
					}
				}, true);//end of ajax
			});//end of [data-id="btnInquiry"]
			
			//상품(이벤트) 정보 상세보기
			$item.find('[data-id="btnOpenDetail"]').click(function(e){
				e.preventDefault();
				
				var eventDataDetail = obj.input.EVENT_NO.getEventDataDetail();
				if(!eventDataDetail){
					cm.message.alert({
						text: '상품(이벤트명)을 선택해주세요.'
					});
					return;
				}
				cm.message.productInfo(eventDataDetail.responseEventPolicyInfoVO.eventNm, eventDataDetail.responseEventPolicyInfoVO.eventDesc);
			});
			
			//삭제하기
			$item.find('[data-id="btnDelete"]').click(function(e){
				e.preventDefault();
				
				cm.message.confirm({
					title: '삭제안내',
					text: '상품을 삭제하시겠습니까?'
				}, function(){
					container.deleteItem(obj);
				});
			});
			
			//약정기간(의무사용기간)
			obj.input.DUTY_USE_PERD.set(null, "36");
			
			//초기데이터셋팅
			if(initData){

				obj.initData = initData;
				
				//상품유형(스마트청약대그룹코드)
				obj.input.MO_PRDT_GRP_CD.set(null, initData.moPrdtGrpCd);
				
				//약정기간(의무사용기간)
				obj.input.DUTY_USE_PERD.set(null, initData.dutyUsePerd);
			}
			
			return obj;
		}//end of create
	};
	tv.init();
	//end of tv
	
	
	//상품정보 입력 템플릿  : internet
	//PRDT_TYPE_CD(상품구분코드) : 02
	var internet = {
		PRDT_TYPE_CD: "02",
		init: function(){
			this.temp.init();
		},
		temp: {
			$: null, //템플릿을 저장한다.
			init: function(){
				//템플릿 초기화
				this.$ = $('[data-product-template="02"]').remove();
			},
			get: function(){
				var $item = this.$.clone();
				return $item;
			}
		},
		create: function(initData){
			var obj = {};
			var $item = this.temp.get();
			obj.$item = $item;
			obj.amt   = {};//월예상금액 등 계산된 금액을 저장할 변수
			obj.PRDT_TYPE_CD = this.PRDT_TYPE_CD;
			
			/**
			 * 작성완료처리
			 * @param {boolean} flag 완료여부
			 */
			obj.complete = function(flag){
				if(flag){
					this.$item.addClass('completed');
				}
				else{
					this.$item.removeClass('completed');
				}
				container.onComplete(this);
			};
			
			/**
			 * 작성완료여부를 반환
			 */
			obj.isComplete = function(){
				return this.$item.hasClass('completed');
			};
			
			/**
			 * 삭제처리
			 * @param {boolean} flag 완료여부
			 */
			obj.remove = function(){
				this.$item.remove();
				addButtonController.check();
			};
			
			/**
			 * 저장 할 데이터를 반환한다.
			 */
			obj.getData = function(){
				var result = {};
				
				result.moRecvNo       = obj.initData ? $.trim(obj.initData.moRecvNo) : "";//스마트청약접수번호
				result.moScrbrNo      = obj.initData ? $.trim(obj.initData.moScrbrNo) : "";//스마트청약가입계약번호
				result.prdtTypeCd     = this.PRDT_TYPE_CD;//상품구분코드.TV,인터넷,렌탈
				result.moPrdtGrpCd    = this.input.MO_PRDT_GRP_CD.val();//상품유형(스마트청약대그룹코드)
				
				var eventData         = this.input.EVENT_NO.getEventData();
				result.eventNo        = eventData.eventNo;//이벤트번호(TV,인터넷)
				result.eventNm        = eventData.eventNm;//이벤트명(TV,인터넷)
				result.eventPrdtGrpCd = eventData.eventPrdtGrpCd;//이벤트상품그룹코드(TV,인터넷)
				result.eventPrdtGrpNm = eventData.eventPrdtGrpNm;//이벤트상품그룹명(TV,인터넷)
				result.dutyUsePerd    = eventData.dutyUsePerd;//약정기간(TV,인터넷)

				result.moMonthInvceAmt= this.amt.MO_MONTH_INVCE_AMT;//월예상납부액
				result.moChrg         = this.amt.MO_CHRG;//시청료
				result.moLseAmt       = this.amt.MO_LSE_AMT;//모델장비임대료
				result.moTotInvceAmt  ="0";//일시불납부액(홈렌탈)
				result.rentalSellerCd ="";//판매처코드(홈렌탈)
				result.rentalSellerNm ="";//판매처명(홈렌탈)
				result.prdtCd         ="";//상품코드(인터넷,홈렌탈)
				result.prdtNm         ="";//상품명(인터넷,홈렌탈)
				result.termInstalClCd ="";//단말설치유형
				result.recvClType     ="";//접수유형(홈렌탈)
				result.prdtGrpCd      ="";//상품종류(홈렌탈)
				result.moMultiCnt     ="0";//복수가입수량
				result.buyMthCd       ="2";//구매형태(홈렌탈) - 1:일시불,2:할부
				result.moInstmCd      ="";//일시불할부구분(홈렌탈)
				result.moPrdtAmt      ="0";//구매단가(홈렌탈)
				
				return result;
			};
			
			//ui 공통에서 적용된 selectOrDir 제거
			$item.find('select').selectOrDie("destroy");
			
			obj.input = {
				//상품유형(스마트청약대그룹코드)
				MO_PRDT_GRP_CD: {
					$elem: $item.find('select[data-id="MO_PRDT_GRP_CD"]').selectOrDie({
						onChange: function(){
							//이벤트 번호 초기화
							obj.input.EVENT_NO.reset();
						}
					}),
					val: function(){
						return this.$elem.val();
					},
					set: function(list, value){
						if(value){
							this.$elem.find('option[value="' + value + '"]').prop('selected', true);
							this.$elem.trigger('change');
						}
					},
					//현재 선택되어있는 코드를 "이벤트상품그룹코드"로 반환한다.
					convertEventPrdtGrpCd: function(){
						var result = "";
						
						switch(this.val()){
							case "INTERNET_2001":
								result = "93";
								break;
							case "INTERNET_2002":
								result = "94";
								break;
							case "INTERNET_2003":
								result = "92";
								break;
							case "INTERNET_2004":
								result = "91";
								break;
							case "INTERNET_2005":
								result = "95";
								break;
						}
						return result;
					}
				},
				//약정기간(의무사용기간)
				DUTY_USE_PERD: {
					$elem: $item.find('select[data-id="DUTY_USE_PERD"]').selectOrDie({
						onChange: function(){
							//이벤트 번호 초기화
							obj.input.EVENT_NO.reset();
						}
					}),
					val: function(){
						return this.$elem.val();
					},
					set: function(list, value){
						if(value){
							var $option = this.$elem.find('option[value="' + value + '"]');
							if($option.length===0){
								$option = this.$elem.find('option[value="0"]');
							}
							$option.prop('selected', true);
							this.$elem.trigger('change');
						}
					}
				},
				//사용자 입력 검색조건
				userInputText: {
					$elem: $item.find('input[data-id="userInputText"]'),
					val: function(){
						return $.trim(this.$elem.val());
					}
				},
				//이벤트번호:
				EVENT_NO: {
					$elem: $item.find('select[data-id="EVENT_NO"]').selectOrDie(),
					val: function(){
						return this.$elem.val();
					},
					reset: function(){
						this.$elem.children().not('[value="__NONE__"]').remove();
						this.$elem.selectOrDie("destroy").selectOrDie();
						obj.complete(false);//작성완료처리
						obj.input.EVENT_NO.setEventDataDetail(null);//이벤트상품데이터초기화
					},
					set: function(list, value){
						fn_setCombo(this.$elem, list, "eventNo", "eventNm", "__NONE__", "선택해주세요.");
						this.$elem.selectOrDie("destroy").selectOrDie({
							onChange: function(){
								if(this.value==="__NONE__"){
									obj.input.EVENT_NO.setEventDataDetail(null);//이벤트상품데이터초기화
									obj.complete(false);//작성완료처리
								}
								else{
									var data = {
										eventNo: this.value
									};
									//이벤트 상품 정보 조회
									cm.ajax(controller, "/contract/action/product002.json", data, true, function(r){
										obj.input.EVENT_NO.setEventDataDetail(r.INF_SCS_026);
										obj.complete(true);//작성완료처리
									}, true);//end of ajax
								}
							}
						});
						
						if(value){
							this.$elem.find('option[value="' + value + '"]').prop('selected', true);
							this.$elem.trigger('change');
						}
					},
					//이벤트 데이터 select 의 선택된 항목의 데이터를 반환한다.(INF_SCS_004 결과)
					getEventData: function(){
						return this.$elem.children(":selected").data('row');
					},
					//이벤트 상품 정보 상세 조회 결과 데이터를 셋팅한다.
					setEventDataDetail: function(d){
						if(!d){
							this.eventDataDetail = null;
							obj.$item.find('[data-id="MO_MONTH_INVCE_AMT"]').text('-');
							obj.$item.find('[data-id="MO_CHRG"]').text('-');
							obj.$item.find('[data-id="MO_LSE_AMT"]').text('-');
							return;
						}
						
						this.eventDataDetail = d;
						
						//시청료
						var MO_CHRG = cm.format.toNumber(d.responseEventPolicyInfoVO.watchPrdtRecvChrg);//시청상품수신료
						
						//임대료
						var MO_LSE_AMT = 0;
						var list = d.responseIrdPrdtListVO;
						if(list && list instanceof Array){
							var rowdata;
							for(var i=0 ; i<list.length ; i++){
								rowdata = list[i];
								//장비유형코드(equipClCd="1")가 수신기인 데이터
								if(rowdata.equipClCd==='1'){
									MO_LSE_AMT += cm.format.toNumber(rowdata.lseAmt);//임대료
								}
							}
						}
						
						//월예상납부액
						var MO_MONTH_INVCE_AMT = MO_CHRG + MO_LSE_AMT;
						
						obj.$item.find('[data-id="MO_MONTH_INVCE_AMT"]').text( cm.format.number(MO_MONTH_INVCE_AMT) );
						obj.$item.find('[data-id="MO_CHRG"]').text( cm.format.number(MO_CHRG) );
						obj.$item.find('[data-id="MO_LSE_AMT"]').text( cm.format.number(MO_LSE_AMT) );
						
						obj.amt = {
							MO_CHRG: MO_CHRG,
							MO_LSE_AMT: MO_LSE_AMT,
							MO_MONTH_INVCE_AMT: MO_MONTH_INVCE_AMT
						};
					},
					//선택된 이벤트의 상세조회 데이터를 반환한다.(INF_SCS_026 결과)
					getEventDataDetail: function(){
						return this.eventDataDetail;
					},
					//임시 저장 데이터 셋팅
					isInit: false,
					isInitInquiry: false,
					init: function(){
						if(obj.input.MO_PRDT_GRP_CD.val()==='__NONE__'){
							return;
						}
						if(obj.input.DUTY_USE_PERD.val()==='__NONE__'){
							return;
						}
						if(this.isInit){
							return;
						}
						this.isInit = true;
						$item.find('[data-id="btnInquiry"]').trigger('click');
					}
				}
			};
			
			//접기 펼치기 이벤트 처리
			$item.find(".clpsTit").off().on('click', function(){
				$item.toggleClass("open");
			});
			
			//조회버튼
			$item.find('[data-id="btnInquiry"]').click(function(e){
				e.preventDefault();
				
				//이벤트 번호 초기화
				obj.input.EVENT_NO.reset();
				
				if(obj.input.MO_PRDT_GRP_CD.val()==='__NONE__'){
					cm.message.alert({text: "상품유형을 선택해주세요."});
					return;
				}
				if(obj.input.DUTY_USE_PERD.val()==='__NONE__'){
					cm.message.alert({text: "약정기간을 선택해주세요."});
					return;
				}
				
				var data = {
					prdtTypeCd      : obj.PRDT_TYPE_CD, //상품구분코드
					eventPrdtGrpCd  : obj.input.MO_PRDT_GRP_CD.convertEventPrdtGrpCd(), //이벤트상품그룹코드
					eventNo         : "", //이벤트번호 
					eventNm         : "", //이벤트명 
					dutyUsePerd     : obj.input.DUTY_USE_PERD.val() //의무사용기간 
				};
				
				//사용자입력검색조건
				var userInputText = obj.input.userInputText.val();
				//숫자 10자리 일 경우
				if(/^[\d]{10}$/.test(userInputText)){
					data.eventNo = userInputText;
				}
				else{
					data.eventNm = userInputText;
				}
				
				//청약상품정보조회
				cm.ajax(controller, "/contract/action/product001.json", data, true, function(r){
					//임시 저장 데이터 셋팅
					var selectValue = null;
					if(!obj.input.EVENT_NO.isInitInquiry){
						obj.input.EVENT_NO.isInitInquiry = true;
						if(obj.initData && obj.initData.eventNo){
							selectValue = obj.initData.eventNo;
						}
					}
					
					if(r.INF_SCS_004){
						//정상
						if(r.INF_SCS_004.rsltCd === '000'){
							obj.input.EVENT_NO.set(r.INF_SCS_004.responseEventListVO, selectValue);
						}
						//조회결과없음
						else if(r.INF_SCS_004.rsltCd === '199'){
							cm.message.alert({
								text: '조건에 해당하는 상품이<br>존재하지 않습니다.'
							});
						}
						//기타오류
						else{
							cm.message.alert({
								title: '처리중 오류가 발생했습니다.',
								text: '잠시 후 다시 시도해주세요.',
								subText: '사유  : ' + r.INF_SCS_004.rsltMsg
							});
						}
					}
					else{
						cm.message.alert({
							title: '처리중 오류가 발생했습니다.',
							text: '잠시 후 다시 시도해주세요.'
						});
					}
				}, true);//end of ajax
			});//end of [data-id="btnInquiry"]
			
			//상품(이벤트) 정보 상세보기
			$item.find('[data-id="btnOpenDetail"]').click(function(e){
				e.preventDefault();
				
				var eventDataDetail = obj.input.EVENT_NO.getEventDataDetail();
				if(!eventDataDetail){
					cm.message.alert({
						text: '상품(이벤트명)을 선택해주세요.'
					});
					return;
				}
				cm.message.productInfo(eventDataDetail.responseEventPolicyInfoVO.eventNm, eventDataDetail.responseEventPolicyInfoVO.eventDesc);
			});
			
			//삭제하기
			$item.find('[data-id="btnDelete"]').click(function(e){
				e.preventDefault();
				
				cm.message.confirm({
					title: '삭제안내',
					text: '상품을 삭제하시겠습니까?'
				}, function(){
					container.deleteItem(obj);
				});
			});
			
			//약정기간(의무사용기간)
			obj.input.DUTY_USE_PERD.set(null, "36");
			
			//초기데이터셋팅
			if(initData){
				
				obj.initData = initData;
				
				//상품유형(스마트청약대그룹코드)
				obj.input.MO_PRDT_GRP_CD.set(null, initData.moPrdtGrpCd);
				
				//약정기간(의무사용기간)
				obj.input.DUTY_USE_PERD.set(null, initData.dutyUsePerd);
				
				//임시 저장 데이터 셋팅
				obj.input.EVENT_NO.init();
			}
			
			return obj;
		}//end of create
	};
	internet.init();
	//end of internet

	
	//상품정보 입력 템플릿  : 홈렌탈
	//PRDT_TYPE_CD(상품구분코드) : 03
	var rental = {
		PRDT_TYPE_CD: "03",
		max: cm.format.toNumber($('[data-config-type="PRD_MULTI_CNT"][data-config-name="RENTAL"]').val()),//동시가입 가능 상품 개수(최대수량)
		init: function(){
			this.temp.init();
		},
		temp: {
			$: null, //템플릿을 저장한다.
			init: function(){
				//템플릿 초기화
				this.$ = $('[data-product-template="03"]').remove();
			},
			get: function(){
				var $item = this.$.clone();
				
				//n건을 생성 할 수있으므로 input 엘리먼트에 고유한 id 값을 셋팅한다.
				var uniqueKey, $label;
				$item.find('input[id]').each(function(){
					$label = $item.find('label[for="' + this.id + '"]');
					
					uniqueKey = this.id + cm.unique.get('-');
					
					this.id = uniqueKey;
					$label.prop('for', uniqueKey);
				});
				
				//radio, checkbox 의 name 그룹을 고유하게 셋팅한다.
				$item.find('input:radio,input:checkbox').each(function(){
					if(this.hasAttribute("data-unique-name-group")){
						return true;
					}
					uniqueKey = this.name + cm.unique.get('-');
					$item.find('input[name="' + this.name + '"]').prop('name', uniqueKey).attr('data-unique-name-group', 'Y');
				});
				
				return $item;
			}
		},
		create: function(initData){
			var obj = {};
			var $item = this.temp.get();
			obj.$item = $item;
			obj.amt   = {};//월예상금액 등 계산된 금액을 저장할 변수
			obj.PRDT_TYPE_CD = this.PRDT_TYPE_CD;
			
			/**
			 * 작성완료처리
			 * @param {boolean} flag 완료여부
			 */
			obj.complete = function(flag){
				if(flag){
					this.$item.addClass('completed');
				}
				else{
					this.$item.removeClass('completed');
				}
				container.onComplete(this);
			};
			
			/**
			 * 작성완료여부를 반환
			 */
			obj.isComplete = function(){
				return this.$item.hasClass('completed');
			};
			
			/**
			 * 삭제처리
			 * @param {boolean} flag 완료여부
			 */
			obj.remove = function(){
				this.$item.remove();
				addButtonController.check();
			};
			
			/**
			 * 저장 할 데이터를 반환한다.
			 */
			obj.getData = function(){
				var result = {};
				
				result.moRecvNo       = obj.initData ? $.trim(obj.initData.moRecvNo) : "";//스마트청약접수번호
				result.moScrbrNo      = obj.initData ? $.trim(obj.initData.moScrbrNo) : "";//스마트청약가입계약번호
				result.prdtTypeCd     = this.PRDT_TYPE_CD;//상품구분코드.TV,인터넷,렌탈
				result.moPrdtGrpCd    = this.input.MO_PRDT_GRP_CD.val();//상품유형(스마트청약대그룹코드)
				
				result.eventNo        ="";//이벤트번호(TV,인터넷)
				result.eventNm        ="";//이벤트명(TV,인터넷)
				result.eventPrdtGrpCd ="";//이벤트상품그룹코드(TV,인터넷)
				result.eventPrdtGrpNm ="";//이벤트상품그룹명(TV,인터넷)
				result.dutyUsePerd    ="";//약정기간(TV,인터넷)

				var prdtData = this.input.PRDT_CD.data();
				
				result.moMonthInvceAmt= cm.format.number(prdtData.instmPerd) <= 1 ? "0" : prdtData.instmAmt;//월예상납부액 - 할부일 경우에만 등록
				result.moChrg         ="0";//시청료(TV,인터넷)
				result.moLseAmt       ="0";//모델장비임대료(TV,인터넷)
				result.moTotInvceAmt  = prdtData.rentalPrdtAmt;//일시불납부액(홈렌탈)
				result.rentalSellerCd = prdtData.rentalSellerCd;//판매처코드(홈렌탈)
				result.rentalSellerNm = prdtData.rentalSellerNm || prdtData.rentalSellerCd;//판매처명(홈렌탈)
				result.prdtCd         = prdtData.rentalPrdtCd;//상품코드(인터넷,홈렌탈)
				result.prdtNm         = prdtData.rentalPrdtNm;//상품명(인터넷,홈렌탈)
				result.termInstalClCd = this.input.TERM_INSTAL_CL_CD.val();//단말설치유형 - 01:일반형,02:벽걸이형
				result.recvClType     = this.input.RECV_CL_TYPE.val();//접수유형(홈렌탈)
				result.prdtGrpCd      = this.input.PRDT_GRP_CD.val();//상품종류(홈렌탈)
				result.moMultiCnt     = this.input.MO_MULTI_CNT.val();//복수가입수량
				result.buyMthCd       = this.input.BUY_MTH_CD.val();//구매형태(홈렌탈) - 1:일시불,2:할부
				result.moInstmCd      = result.buyMthCd;//일시불할부구분(홈렌탈)
				result.moPrdtAmt      = prdtData.rentalPrdtAmt;//구매단가(홈렌탈)
				
				return result;
			};
			
			/**
			 * 상품그룹이 변경되면 타이틀바에 상품그룹명을 추가한다.
			 */
			obj.updateTitle = function(){
				var addText = "";
				if(obj.input.PRDT_GRP_CD.val()!=='__NONE__'){
					addText = '(' + obj.input.PRDT_GRP_CD.text() + ')';
				}
				this.$item.find('[data-product-title]').html('홈 렌탈' + addText + '<span>[작성완료]</span>');
			};
			
			//ui 공통에서 적용된 selectOrDir 제거
			$item.find('select').selectOrDie("destroy");
			
			obj.input = {
				//상품유형(스마트청약대그룹코드)
				//	하위영향: 상품그룹
				MO_PRDT_GRP_CD: {
					$elem: $item.find('select[data-id="MO_PRDT_GRP_CD"]').selectOrDie({
						onChange: function(){
							if(this.value==="__NONE__"){
								//상품그룹코드
								obj.input.PRDT_GRP_CD.set();
							}
							else{
								cm.code.memCache.getList(controller, this.value, function(list){
									obj.input.PRDT_GRP_CD.set(list);
								});
							}
						}
					}),
					val: function(){
						return this.$elem.val();
					},
					set: function(list, value){
						if(value){
							this.$elem.find('option[value="' + value + '"]').prop('selected', true);
							this.$elem.trigger('change');
						}
					}
				},
				//판매처
				RENTAL_SELLER_CD: {
					$elem: $item.find('select[data-id="RENTAL_SELLER_CD"]').selectOrDie({
						onChange: function(){
							obj.input.PRDT_GRP_CD.change();
						}
					}),
					val: function(){
						return this.$elem.val();
					},
					set: function(list, value){
						if(value){
							this.$elem.find('option[value="' + value + '"]').prop('selected', true);
							this.$elem.trigger('change');
						}
					}
				},
				//상품그룹코드
				//	상위영향: 상품유형, 판매처
				//	하위영향: 상품명/모델명, 단말설치유형
				PRDT_GRP_CD: {
					isInit: false,
					$elem: $item.find('select[data-id="PRDT_GRP_CD"]').selectOrDie(),
					val: function(){
						return this.$elem.val();
					},
					text: function(){
						return this.$elem.find("option:selected").text();
					},
					change: function(){
						//입력폼 타이틀 변경
						obj.updateTitle();
						
						//단말설치유형
						obj.input.TERM_INSTAL_CL_CD.set();
						
						if(this.val()==="__NONE__"){
							//상품명/모델명
							obj.input.PRDT_CD.set();
							return;
						}
						
						var data = {
							prdtTypeCd      : obj.PRDT_TYPE_CD, //상품구분코드
							rentalSellerCd  : obj.input.RENTAL_SELLER_CD.val()==='__NONE__' ? "" : obj.input.RENTAL_SELLER_CD.val(),//판매처
							rentalPrdtGrpCd : this.val(),//상품그룹코드
							rentalPrdtCd    : "",//상품코드
							rentalPrdtNm    : ""//상품명
						};
						//청약상품정보조회
						cm.ajax(controller, "/contract/action/product003.json", data, true, function(r){
							if(r.INF_SCS_032){
								//정상 || 조회결과없음
								if(r.INF_SCS_032.rsltCd === '000' || r.INF_SCS_032.rsltCd === '199'){
									obj.input.PRDT_CD.set(r.INF_SCS_032.responseRentalPrdtListVO);
								}
								//기타오류
								else{
									cm.message.alert({
										title: '처리중 오류가 발생했습니다.',
										text: '잠시 후 다시 시도해주세요.',
										subText: '사유  : ' + r.INF_SCS_032.rsltMsg
									});
								}
							}
							else{
								cm.message.alert({
									title: '처리중 오류가 발생했습니다.',
									text: '잠시 후 다시 시도해주세요.'
								});
							}
						}, true);//end of ajax
					},
					set: function(list){
						//상품명/모델명
						obj.input.PRDT_CD.set();
						
						if(!list || list.length===0){
							this.$elem.children().not('[value="__NONE__"]').remove();
							this.$elem.selectOrDie("destroy").selectOrDie();
						}
						else{
							//상품그룹코드 콤보 초기화
							fn_setCombo(this.$elem, list, "cd", "cdNm", "__NONE__", "선택해주세요.");
							this.$elem.selectOrDie("destroy").selectOrDie({
								onChange: function(){
									obj.input.PRDT_GRP_CD.change();
									
									//필수값체크
									obj.input.checkComplete();
								}
							});
							
							//임시 저장 데이터 셋팅
							if(!this.isInit){
								this.isInit = true;
								if(obj.initData && obj.initData.prdtGrpCd){
									this.$elem.find('option[value="' + obj.initData.prdtGrpCd + '"]').prop('selected', true);
									this.$elem.trigger('change');
								}
							}
						}
						
						//입력폼 타이틀 변경
						obj.updateTitle();
					}
				},
				//단말설치유형
				//	상위영향: 상품그룹
				TERM_INSTAL_CL_CD: {
					isInit: false,
					$box: $item.find('[data-input-container="TERM_INSTAL_CL_CD"]'),
					set: function(){
						var PRDT_GRP_CD = obj.input.PRDT_GRP_CD.val();
						var $group = this.$box.find('[data-radio-group="' + PRDT_GRP_CD + '"]');
						
						if($group.length===0){
							$group = this.$box.find('[data-radio-group="etc"]');
						}
						
						$group.find('[type="radio"]:eq(0)').prop('checked', true);
						$group.attr('data-state', 'on').show()
							.siblings('[data-radio-group]').attr('data-state', 'off').hide();
						
						//임시 저장 데이터 셋팅
						if(!this.isInit && obj.input.PRDT_GRP_CD.$elem.children().length > 1){
							this.isInit = true;
							if(obj.initData && obj.initData.termInstalClCd){
								$group.find('[value="' + obj.initData.termInstalClCd + '"]').prop('checked', true);
							}
						}
						
						this.$box.show();
					},
					val: function(){
						return this.$box.find('[data-radio-group][data-state="on"]').find('input:checked').val();
					}
				},
				//상품명/모델명(상품코드)
				//	상위영향: 상품그룹
				//	하위영향: 구매형태
				PRDT_CD: {
					isInit: false,
					$elem: $item.find('select[data-id="PRDT_CD"]').selectOrDie(),
					val: function(){
						return this.$elem.val();
					},
					data: function(){
						return this.$elem.children(":selected").data('row');
					},
					set: function(list){
						//구매형태
						obj.input.BUY_MTH_CD.set();
						
						//복수가입수량 선택값 초기화 - 상품별로 구매가능수량이 다름
						obj.input.MO_MULTI_CNT.set();
						
						//금액표시
						obj.input.setAmt();
						
						//필수값체크
						obj.input.checkComplete();
						
						if(!list || list.length===0){
							this.$elem.children().not('[value="__NONE__"]').remove();
							this.$elem.selectOrDie("destroy").selectOrDie();
						}
						else{
							//상품그룹코드 콤보 초기화
							fn_setCombo(this.$elem, list, "rentalPrdtCd", "rentalPrdtNm", "__NONE__", "선택해주세요.");
							this.$elem.selectOrDie("destroy").selectOrDie({
								onChange: function(){
									//구매형태
									obj.input.BUY_MTH_CD.set();
									
									//복수가입수량 선택값 초기화 - 상품별로 구매가능수량이 다름
									obj.input.MO_MULTI_CNT.set();
									
									//금액표시
									obj.input.setAmt();
									
									//필수값체크
									obj.input.checkComplete();
								}
							});
							
							//임시 저장 데이터 셋팅
							if(!this.isInit){
								this.isInit = true;
								if(obj.initData && obj.initData.prdtCd){
									this.$elem.find('option[value="' + obj.initData.prdtCd + '"]').prop('selected', true);
									this.$elem.trigger('change');
								}
							}
						}
					}
				},
				//구매형태 - 일시불/할부
				BUY_MTH_CD: {
					$box: $item.find('[data-input-container="BUY_MTH_CD"]'),
					set: function(){
						var prdtData = obj.input.PRDT_CD.data();//현재 선택된 상품 데이터
						if(!prdtData){
							this.$box.hide();
							return;
						}
						
						//일시불
						var $input1 = this.$box.find('input[name^="BUY_MTH_CD"][value="1"]');
						//할부
						var $input2 = this.$box.find('input[name^="BUY_MTH_CD"][value="2"]');
						
						//일시불
						if(cm.format.number(prdtData.instmPerd) <= 1){
							$input1.prop('checked', true).closest('ul').show();
							$input2.closest('ul').hide();
						}
						//할부
						else{
							$input1.closest('ul').hide();
							$input2.prop('checked', true).closest('ul').show();
							$input2.next().find('[data-id="textInstmPerd"]').text(prdtData.instmPerd);
						}
						this.$box.show();
					},
					val: function(){
						return this.$box.find('input:checked').val();
					}
				},
				//접수유형
				RECV_CL_TYPE: {
					$elem: $item.find('select[data-id="RECV_CL_TYPE"]').selectOrDie({
						onChange: function(){
							//필수값체크
							obj.input.checkComplete();
						}
					}),
					val: function(){
						return this.$elem.val();
					},
					set: function(list, value){
						if(value){
							this.$elem.find('option[value="' + value + '"]').prop('selected', true);
							this.$elem.trigger('change');
						}
					}
				},
				//복수가입수량
				MO_MULTI_CNT: {
					isInit: false,
					max: cm.format.toNumber($('[data-config-type="MO_MULTI_CNT"][data-config-name="RENTAL"]').val()),//복수가입수량(최대수량)
					$elem: $item.find('select[data-id="MO_MULTI_CNT"]').selectOrDie(),
					val: function(){
						return this.$elem.val();
					},
					set: function(){
						this.$elem.children().not('[value="__NONE__"]').remove();
						
						//현재 선택된 상품 데이터
						var prdtData = obj.input.PRDT_CD.data();
						if(prdtData){
							var buyPossQty = cm.format.toNumber(prdtData.buyPossQty);//구매가능수량
							
							//복수가입수량, 구매가능수량 중에 작은 값으로 셋팅한다.
							var max = Math.min(this.max, buyPossQty);
							for(var i=1 ; i<=max ; i++){
								$('<option></option>').val(i).text(i).appendTo(this.$elem);
							}
						}
						
						this.$elem.selectOrDie("destroy").selectOrDie({
							onChange: function(){
								//금액표시
								obj.input.setAmt();
								
								//필수값체크
								obj.input.checkComplete();
							}
						});
						
						//임시 저장 데이터 셋팅
						if(!this.isInit && prdtData){
							this.isInit = true;
							if(obj.initData && obj.initData.moMultiCnt){
								this.$elem.find('option[value="' + obj.initData.moMultiCnt + '"]').prop('selected', true);
							}
						}
						
						this.$elem.trigger('change');
					}
				},
				//예상 금액 셋팅
				setAmt: function(){
					
					//월예상납부액
					var $MO_MONTH_INVCE_AMT = obj.$item.find('[data-item="MO_MONTH_INVCE_AMT"]');
					
					//일시불납부액
					var $MO_TOT_INVCE_AMT   = obj.$item.find('[data-item="MO_TOT_INVCE_AMT"]');
					
					var prdtData = this.PRDT_CD.data();//현재 선택된 상품 데이터
					var MO_MULTI_CNT = cm.format.toNumber(this.MO_MULTI_CNT.val());
					
					//선택된 상품이 없을경우
					if(!prdtData){
						$MO_MONTH_INVCE_AMT.show();
						$MO_TOT_INVCE_AMT.show();
					}
					else{
						//일시불
						if(cm.format.number(prdtData.instmPerd) <= 1){
							$MO_MONTH_INVCE_AMT.hide();
							$MO_TOT_INVCE_AMT.show();
						}
						//할부
						else{
							$MO_MONTH_INVCE_AMT.show();
							$MO_TOT_INVCE_AMT.hide();
						}
					}
					
					if(!prdtData || MO_MULTI_CNT<1){
						$MO_MONTH_INVCE_AMT.find('[data-value-item]').text('-');//월예상납부액
						$MO_TOT_INVCE_AMT.find('[data-value-item]').text('-');//일시불납부액
						return;
					}
					
					var MO_MONTH_INVCE_AMT = cm.format.toNumber(prdtData.instmAmt) * MO_MULTI_CNT;//월예상납부액
					var MO_TOT_INVCE_AMT   = cm.format.toNumber(prdtData.rentalPrdtAmt) * MO_MULTI_CNT;//일시불납부액
					
					$MO_MONTH_INVCE_AMT.find('[data-value-item]').text( cm.format.number(MO_MONTH_INVCE_AMT) );
					$MO_TOT_INVCE_AMT.find('[data-value-item]').text( cm.format.number(MO_TOT_INVCE_AMT) );
					
					obj.amt = {
						MO_MONTH_INVCE_AMT: MO_MONTH_INVCE_AMT,
						MO_TOT_INVCE_AMT  : MO_TOT_INVCE_AMT
					};
				},
				//필수입력값 설정 여부를 확인한다.
				checkComplete: function(){
					var isComplete = true;
					obj.$item.find('[data-required]').each(function(){
						if(this.value==='__NONE__'){
							isComplete = false;
							return false;//break;
						}
					});
					obj.complete(isComplete);
					return isComplete;
				}
			};
			
			//접기 펼치기 이벤트 처리
			$item.find(".clpsTit").off().on('click', function(){
				$item.toggleClass("open");
			});
			
			//삭제하기
			$item.find('[data-id="btnDelete"]').click(function(e){
				e.preventDefault();
				
				cm.message.confirm({
					title: '삭제안내',
					text: '상품을 삭제하시겠습니까?'
				}, function(){
					container.deleteItem(obj);
				});
			});
			
			//초기데이터셋팅
			if(initData){
				
				obj.initData = initData;
				
				//상품유형(스마트청약대그룹코드)
				obj.input.MO_PRDT_GRP_CD.set(null, initData.moPrdtGrpCd);
				
				//판매처
				obj.input.RENTAL_SELLER_CD.set(null, initData.rentalSellerCd);
				
				//접수유형
				obj.input.RECV_CL_TYPE.set(null, initData.recvClType);
			}
			
			return obj;
		}//end of create
	};
	rental.init();
	//end of rental
	
	
	//상품 작성양식 추가 버튼 처리
	var addButtonController = {
		$container: $('[data-id="addButtonContainer"]'),
		//tv, 인터넷
		group1: {
			$box: $('[data-id="addButtonContainer"] [data-button-group="group1"]'),
			tv: {
				$btn: $('[data-id="addButtonContainer"] [data-id="btnAddTv"]').click(function(e){
					e.preventDefault();
					container.addItem(tv);
				})
			},
			internet: {
				$btn: $('[data-id="addButtonContainer"] [data-id="btnAddInternet"]').click(function(e){
					e.preventDefault();
					container.addItem(internet);
				})
			}
		},
		group2: {
			$box: $('[data-id="addButtonContainer"] [data-button-group="group2"]'),
			rental: {
				$btn: $('[data-id="addButtonContainer"] [data-id="btnAddRental"]').click(function(e){
					e.preventDefault();
					container.addItem(rental);
				})
			}
		},
		check: function(){
			var lenTv   = container.getItemLength(tv),//현재 추가되어있는 tv 입력 템플릿 갯수
			lenInternet = container.getItemLength(internet),//현재 추가되어있는 인터넷 입력 템플릿 갯수
			lenRental   = container.getItemLength(rental);//현재 추가되어있는 홈렌탈 입력 템플릿 갯수
			
			//TV 입력 폼이 추가되어있을경우 TV추가 버튼 숨김
			if(lenTv>0){
				this.group1.tv.$btn.hide();
			}
			else{
				this.group1.tv.$btn.show();
			}
			
			//인터넷 입력 폼이 추가되어있을경우 인터넷 추가 버튼 숨김
			if(lenInternet>0){
				this.group1.internet.$btn.hide();
			}
			else{
				this.group1.internet.$btn.show();
			}
			
			//TV, 인터넷 입력 폼이 둘다 추가되어있을경우 TV,인터넷 추가 버튼 숨김
			if(lenTv>0 && lenInternet>0){
				this.group1.$box.hide();
			}
			else{
				this.group1.$box.show();
			}
			
			//홈렌탈 입력폼이 동시가입가능상품갯수 만큼 추가되어 있을 경우 홈렌탈 추가 버튼 박스 숨김
			if(lenRental >= rental.max){
				this.group2.$box.hide();
			}
			else{
				this.group2.$box.show();
			}
		}
	};
	
	//헤더 스탭 링크 버튼 막기
	$('.step a').click(function(e){
		e.preventDefault();
	});
	
	container.init();
});