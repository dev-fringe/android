
var g_flag = true;	    
var g_smsAuthNo = ""; //sms인증번호 보관

var g_time = 180; 
var g_timerID ; // 타이머를 핸들링하기 위한 전역 변수
var g_timerSecond = 0;


$(document).ready(function(){
	controller.beforeInit();
	controller.init();
});

$(window).on('load', function(){
	controller.afterLoad();
});
/*
document.form.submit(function(){	

	

	return true;

});*/
var controller = $.extend(new $.CommonObj(), {
	beforeInit : function() {
		//console.log('fn_isAdultByValue >> ' + fn_isAdultByValue("870630", "2268218") );
		//console.log('beforeInit >> ' + fn_setBirthSexFromJumin("870630","2268218") );
		//console.log(fn_getNowDateTime());
		ui.init();
		ui.on();
		data.init();
		evtGae.on(); //개인 이벤트
		evtSaup.on(); //사업자 이벤트
		var page = 2;
	}//beforeInit
	, eventInit : function() {
		
		//다음스텝
		$('#btnNextStep').on({
	        click :function(event){
	        	//alert('개발중'); return;
	        	var dataFlag = data.nextCheck();
	        	if(!dataFlag){
	        		fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
	        		return;
	        	}
	        	if(g_flag){
        			data.setFlag(false);
        			fnNextStep2();
        		}
	        	data.setFlag(true);
	        }
			
	    });
		//인터넷 수용국
		/*$('#btnIntHost').on({
	        click :function(event){
	        	fnPOPA_60_P11('inp_intHost', 'inp_intHostCode');
	        }
	    });*/
		/*$(document).on("submit",  function() {
			fn_loading(true);
		});
		*/
		
	}//eventInit
	, afterLoad : function() {
		/*
		 * 수용국코드 스크롤팝업 바인딩
		 * */
		$('#interLandNum').bind('scroll', function(){
		   if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight){
			   fnPOPA_60_P11Search("type_nm_intHost","scroll");
		   }
		});
		$('#interLandAddr').bind('scroll', function(){
		   if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight){
			   fnPOPA_60_P11Search("type_addr_dong","scroll");
		   }
		});
	}//afterLoad

});
function fnSelectIntHost(index){
	fnPOPA_60_P11('inp_intHost_'+index, 'inp_intHostCode_'+index);
}
function fnSelectInstall(index){
	//fn_nvl($("#inp_eventNo_" + index).val(),$("#inp_prdtCd_" + index).val()) 
	var v_prdtCd = fn_nvl($("#inp_prdtCd_"+index).val(),$("#inp_eventNo_" + index).val());
	var v_ktOfceCd = $("#inp_addr_ktOfceCd_"+index).val();  //KT수용국코드
	var v_ktDongCd = $("#inp_addr_ktDongCd_"+index).val();  //KT동코드
	var v_ktBldId = $("#inp_addr_ktBldId_"+index).val();  //KT건물아이디
	var v_bunji = $("#inp_addr_addrBunji_"+index).val();  //번지
	var v_ho = $("#inp_addr_addrHo_"+index).val();  //호
	
	//v_prdtCd = "30170102";
	v_ktBldId = "90000211096";
	var paramObj = {
		prdtCd : v_prdtCd  	//상품코드 *
		, ktOfceCd : v_ktOfceCd  //KT수용국코드 *
		, ktDongCd : v_ktDongCd  //KT동코드 *
		, ktBldId : v_ktBldId 	//KT건물아이디 *
		, bunji : v_bunji 		//번지
		, ho : v_ho				//호
		, targetId : index
	};
	fnApiCall_INF_014(index, paramObj, resultApi.INF_014);
}
function fnSelectInstallChange(obj, index){
	
	
	var v_prdtTypeCd = $("#inp_prdtTypeCd_"+index).val();
	var v_installJum = $("#slt_installJum_"+index).val();
	var v_installDay = fn_replaceAll($("#inp_installDay_"+index).val(),"-","");
	//console.log("v_prdtTypeCd >>> " + v_prdtTypeCd);
	if(v_prdtTypeCd == "03"){
		//console.log("v_installJum >>> " + v_installJum);
		if(v_installJum == MSG.DEFAULT_KEY){
			$("#slt_installJum_"+index+" option:eq(0)").prop("selected", true);
			$("#inp_installDay_"+index).val("");
			$("#slt_installTime_"+index+" option:eq(0)").prop("selected", true);
			//$("#slt_installTime_"+index).val("");
			updateSelectOrDie();
		}
		return;
	}
	if(fn_nvl(v_installJum,MSG.DEFAULT_KEY) == MSG.DEFAULT_KEY ){
		//g_msgObj.msg1 = "설치점을 선택해주세요.";
		//fnPOPMessagePopup("CUSTOM", g_msgObj);
		fn_clearComboItems("#slt_installTime_"+index);
		fn_setComboAddItem("#slt_installTime_"+index, MSG.DEFAULT_KEY, "설치 시간을 선택해 주세요.", true);
		$("#inp_installDay_"+index).val("");
		updateSelectOrDie();
	}else if(fn_nvl(v_installDay,"") == "" ){
		
	}else{
		//설치시간 조회 인터페이스
		var paramObj = {
			instalPlceZipCd : $("#inp_addr_" + index).val()			//설치우편번호	
			, instalPlceAddr : $("#inp_addr2_" + index).val()			//설치주소	
			, instalPlceSuppAddr : $("#inp_addr3_" + index).val()	//설치보조주소	
			, refBaseAddr : fn_nvl($("#inp_addr_rdNmAddr_" + index).val(),$("#inp_refMastAddr_" + index).val())				//참조기본주소	
			, refBaseSuppAddr : fn_nvl($("#inp_addr_rdNmSuppAddr_" + index).val(),$("#inp_refSuppAddr_" + index).val())		//참조보조주소	
			, addrSeltnTypeCd : "3"		//주소선택구분코드	
			, instalCrclNetCd : v_installJum		//설치점	TV/인터넷인 경우
			, preferSvcOpenDh : v_installDay   		 //개통희망일
		}
		fnApiCall_INF_015(index, paramObj, resultApi.INF_015);
	}
	
}

/*
 * 설치장소 팝업출력
 * */
function fnSelectZipAddr(type, index){
	if(type == "INSTALL_ADDR"){
		fnPOPA_60_P5("fnSelectZipAddrResult",index);
	}else if(type == "CHKP_ADDR"){
		fnPOPA_60_P5("fnSelectZipAddrChkpResult",index);
	}
}
function fnSelectZipAddrChkpResult(paramObj){
	var index = paramObj.targetIndex;
	//100 : 자동이체 > 이메일
	//101 : 자동이체 > 모바일
	//102 : 자동이체 > 고지서
	//110 : 카드이체 > 이메일
	//111 : 카드이체 > 모바일
	//112 : 카드이체 > 고지서
	if(index == "100"){
		/*
		 * 청구주소 데이터 셋팅 자동이체 > 이메일
		 * */
		data.setInvceZipAddrDataInfo(paramObj, "chkpEmail");
	}else if(index == "101"){
		/*
		 * 청구주소 데이터 셋팅 자동이체 > 모바일
		 * */
		data.setInvceZipAddrDataInfo(paramObj, "chkpMobile");
	}else if(index == "102"){
		/*
		 * 청구주소 데이터 셋팅 자동이체 > 고지서
		 * */
		data.setInvceZipAddrDataInfo(paramObj, "chkpGoji");
		
	}else if(index == "110"){
		/*
		 * 청구주소 데이터 셋팅 카드이체 > 이메일
		 * */
		data.setInvceZipAddrDataInfo(paramObj, "chkpCardEmail");
		
		
	}else if(index == "111"){
		/*
		 * 청구주소 데이터 셋팅 카드이체 > 모바일
		 * */
		data.setInvceZipAddrDataInfo(paramObj, "chkpCardMobile");
	}else if(index == "112"){
		/*
		 * 청구주소 데이터 셋팅 카드이체 > 고지서
		 * */
		data.setInvceZipAddrDataInfo(paramObj, "chkpCardGoji");
	}
	
}
function fnSelectZipAddrResult(paramObj){
	
	/*var paramObj = {
			searchGubun : "N" //J:지번, N : 도로명
			 , instalPlceZipCd : "07288" 				//설치우편번호
			 , jibunAddr : "서울특별시 영등포구 문래동4가 " //	지번기본주소
			 , jibunSuppAddr : "8-37번지" 				//	지번보조주소
			 , rdNmVrfCd : "H"    						 //	도로명검증코드
			 , rdNmAddr : "서울 영등포구 도림로145길 4" 	//	도로명기본주소
			 , rdNmSuppAddr : "(문래동4가)"  			//		도로명보조주소
		    , ktDongCd : "304413" 					//	KT동코드
		    , addrBunjiCl : "1"					//주소번지유형
		    , addrBunji : "8"					 //	주소번지
		    , addrHo : "37"						//		주소호
		    , ktOfceCd : "R00431" 					//	KT수용국코드
		    , ktOfceNm : "영등포지점"				//		KT수용국명
		    , instalCrclNetCd : "L60010"     //	설치유통망코드
		    , ktBldId : "90000211096"	//		KT건물아이디
		    	//, ktRdNmId : ""	//	KT도로명아이디
			, targetIndex : "0"
			, aptCd : ""
			, aptDong : ""
			, aptHo : ""
			, bldMgmtNo : ""
		};*/
		//주소값 셋팅
		var index = paramObj.targetIndex;
		
		
		$("#inp_addr_"+index).val(paramObj.instalPlceZipCd);
		if(paramObj.searchGubun == "J"){
			$("#inp_addr2_"+index).val(paramObj.jibunAddr);
			$("#inp_addr3_"+index).val(paramObj.jibunSuppAddr);
			
			$("#inp_refMastAddr_"+index).val(paramObj.rdNmAddr);
			$("#inp_refSuppAddr_"+index).val(paramObj.rdNmSuppAddr);
			
			$("#inp_addrSeltnTypeCd_"+index).val("3");
			
		}else{
			$("#inp_addr2_"+index).val(paramObj.rdNmAddr);
			$("#inp_addr3_"+index).val(paramObj.rdNmSuppAddr);
			
			$("#inp_refMastAddr_"+index).val(paramObj.jibunAddr);
			$("#inp_refSuppAddr_"+index).val(paramObj.jibunSuppAddr);
			
			$("#inp_addrSeltnTypeCd_"+index).val("4");
		}
		
		
		$("#inp_addr_jibunAddr_"+index).val(paramObj.jibunAddr);  //지번기본주소
		$("#inp_addr_jibunSuppAddr_"+index).val(paramObj.jibunSuppAddr);  //지번보조주소
		
		$("#inp_addr_ktOfceCd_"+index).val(paramObj.ktOfceCd);  //KT수용국코드
		$("#inp_addr_ktOfceNm_"+index).val(paramObj.ktOfceNm);  //KT수용국코드명
		
		$("#inp_addr_ktDongCd_"+index).val(paramObj.ktDongCd);  //KT동코드
		
		$("#inp_addr_addrBunjiCl_"+index).val(paramObj.addrBunjiCl); //	주소번지유형
		$("#inp_addr_addrBunji_"+index).val(paramObj.addrBunji);//번지
		$("#inp_addr_addrHo_"+index).val(paramObj.addrHo);//호
		
		
		$("#inp_addr_ktBldId_"+index).val(fn_nvl(paramObj.ktBldId,""));  //KT건물아이디
		$("#inp_addr_rdNmVrfCd_"+index).val(paramObj.rdNmVrfCd); //	도로명검증코드
		$("#inp_addr_rdNmAddr_"+index).val(paramObj.rdNmAddr); //	도로명기본주소
		$("#inp_addr_rdNmSuppAddr_"+index).val(paramObj.rdNmSuppAddr); //	도로명보조주소
		$("#inp_addr_ktRdNmId_"+index).val(paramObj.ktRdNmId);  //kt도로명아이디
		 
		/*
		 * 청구주소 매핑
		 * */
		if(index == "0"){
			var msg = "("+$("#inp_addr_0").val()+") " + $("#inp_addr2_0").val() + " " + $("#inp_addr3_0").val();
			//자동이체 > 이메일
			$("#div_chkp_invceAddrText").show();
			$("#div_chkp_invceAddrText").html(msg);
			//자동이체 > 모바일
			$("#div_chkpAuto_mobile_invceAddrText").show();
			$("#div_chkpAuto_mobile_invceAddrText").html(msg);
			//자동이체 > 고지서
			$("#div_chkpAuto_goji_invceAddrText").show();
			$("#div_chkpAuto_goji_invceAddrText").html(msg);
			
			//카드이체 > 이메일
			$("#div_chkpCard_invceAddrText").show();
			$("#div_chkpCard_invceAddrText").html(msg);
			
			//카드이체 > 모바일
			$("#div_chkpCard_mobile_invceAddrText").show();
			$("#div_chkpCard_mobile_invceAddrText").html(msg);
			
			//카드이체 > 고지서
			$("#div_chkpCard_goji_invceAddrText").show();
			$("#div_chkpCard_goji_invceAddrText").html(msg);
			
		}
		/*
		 * 설치희망일 초기화
		 * */
		var v_prdtTypeCd = $("#inp_prdtTypeCd_"+index).val();
		var v_installJum = $("#slt_installJum_"+index).val();
		var v_installDay = fn_replaceAll($("#inp_installDay_"+index).val(),"-","");
		
		if(v_prdtTypeCd == "03"){
			fn_clearComboItems("#slt_installJum_"+index);
			fn_setComboAddItem("#slt_installJum_"+index, MSG.DEFAULT_KEY, "설치점을 선택해 주세요.", true);
			$("#inp_installDay_"+index).val("");
			$("#slt_installTime_"+index+" option:eq(0)").prop("selected", true);
		}else{
			fn_clearComboItems("#slt_installJum_"+index);
			fn_setComboAddItem("#slt_installJum_"+index, MSG.DEFAULT_KEY, "설치점을 선택해 주세요.", true);
			$("#inp_installDay_"+index).val("");
			fn_clearComboItems("#slt_installTime_"+index);
			fn_setComboAddItem("#slt_installTime_"+index, MSG.DEFAULT_KEY, "설치 시간을 선택해 주세요.", true);
			
			updateSelectOrDie();
		}
		fnDisbClass("#btn_installOk_"+index, false,"#btn_installOk_"+index,"", "disabled");
}

function fnNextStep2(){
	var formObj = fnNextStep();
    controller.ajaxSend( {
		url : contextPath + '/contract/saveReceiptCustInfo.json'
		, data : formObj
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var retCode = result.retCode;
			var retMsg = result.retMsg;
			if (retCode == "SUCC") {
				//window.location.replace(contextPath + '/contract/receiptContract.do?moRecvNo=' + $("#smartRecvNo").val());
				var formOption = {
					"action" : contextPath + "/contract/receiptContract.do"
				}
				controller.createForm(formOption);
				controller.attachHiddenElement('moRecvNo', $('#smartRecvNo').val());
				controller.formSubmit();
			} else {
		    	fnReqValCheckMsgOutput(retMsg);
			}
		}
    });
}
function fnNextStep(){
	var $form = $('<form></form>');
	$form.attr('method', 'post');
    $form.appendTo('body');
    
    //fn_addHidden($form, "smartRecvNo", controller.nvl($("#smartRecvNo").val(),"") );  //session_스마트청약접수번호
    //fn_addHidden($form, "prodType", 'dummy');
    var tab = ui.tabOnCheck();
   // console.log("tab >> " + tab);
    	//고객구분코드	CM008	1		20010801	29991231	개인
    	//고객구분코드	CM008	2		20010801	29991231	외국개인
    	//고객구분코드	CM008	3		20010801	29991231	개인사업자
    	//고객구분코드	CM008	4		20010801	29991231	법인 13자리 
    	//고객구분코드	CM008	5		20010801	29991231	외국법인 13자리 (5~6번째 외국법인 81~86)
    	//고객구분코드	CM008	6		20010801	29991231	공공기관  // 71 기타분류할수없는 법인
    																		
    	//본인인증구분코드	CM376	01	8885796	20140203	29991231	휴대폰인증  MO_CUST_NM_CERTI_TYPE_CD
    	//본인인증구분코드	CM376	02	8885798	20140203	29991231	녹취인증
    	//본인인증구분코드	CM376	03	8885800	20140203	29991231	신분증스캔
    	//본인인증구분코드	CM376	04	8885802	20140203	29991231	이미지인증

    	//신청자구분코드	CM377	01	8885810	20140203	29991231	본인
    	//신청자구분코드	CM377	02	8885812	20140203	29991231	가족
    	//신청자구분코드	CM377	03	8885814	20140203	29991231	대표자
    	//신청자구분코드	CM377	04	8885816	20140203	29991231	직원
    	//신청자구분코드	CM377	05	8885818	20140203	29991231	법정대리인
    	//신청자구분코드	CM377	99	8885820	20140203	29991231	기타
    
		  /*  	
		    청구매체코드	CM067	11		20010801	29991231	고지서
		    청구매체코드	CM067	33	9354881	20031215	29991231	E-MAIL
		    청구매체코드	CM067	79		20171204	29991231	모바일알림톡
		*/
    	
    	fn_addHidden($form, "moRecvNo", controller.nvl($("#smartRecvNo").val(),""));//pk
    	fn_addHidden($form, "recvNo", controller.nvl($("#inp_recvNo").val(),""));
    	fn_addHidden($form, "moEntrType", controller.nvl($("#inp_moEntrType").val(),"")); //신청서작성업무구분(신규, 재약정)
    	fn_addHidden($form, "homeCertYn", controller.nvl(g_smsAuthUseYN,"N"));
    	//console.log(" g_smsAuthUseYN > " + g_smsAuthUseYN);
    	/*
    	 * 개인 고객 
    	 * */
    	if(tab.indexOf("gae") > -1){
    		fn_addHidden($form, "custNm", controller.nvl($("#inp_gae_custNm").val(),"")); //개인> 고객명*
    		fn_addHidden($form, "custNo", controller.nvl($("#inp_inf_custNo").val(),"")); //개인 > 고객번호(기존사용자)
    		fn_addHidden($form, "moCustNmCertiTypeCd", controller.nvl($("#inp_moCustNmCertiTypeCd").val(),"")); //개인 > 고객인증유형구분 >외국인 미성년자는 ""  : inp_custTypeCd 구분
    		fn_addHidden($form, "moCustNmCertiKey", controller.nvl($("#inp_inf_certiKey").val(),"")); //개인 > 고객인증키
    		fn_addHidden($form, "moCustNmPossDh", controller.nvl($("#inp_inf_certiTime").val(),""));
			fn_addHidden($form, "moCustNmCertiDh", controller.nvl($("#inp_inf_certiTime").val(),""));
    		fn_addHidden($form, "custTypeCd", $("#inp_custTypeCd").val()); //고객구분코드
    		
    		var juminBizNo = $("#inp_gae_juminNo1").val() +""+ $("#inp_gae_juminNo2").val();
			fn_addHidden($form, "juminBizNo", controller.nvl(juminBizNo,"")); //주민,사업자번호*
			
			var mblTelNo = $("#slt_gae_hpNo1").val() + "-" + $("#inp_gae_hpNo2").val() + "-" + $("#inp_gae_hpNo3").val();
    		fn_addHidden($form, "mblTelNo", controller.nvl(mblTelNo,""));//핸드폰번호*
			
    		if($("input:checkbox[id='chk_gae_telNo']").is(":checked")){
    			var telNo = $("#slt_gae_telNo1").val() + "-" + $("#inp_gae_telNo2").val() + "-" + $("#inp_gae_telNo3").val();
    			fn_addHidden($form, "telNo", controller.nvl(telNo,"")); //유선전화번호(선택)
    		}else{
    			fn_addHidden($form, "telNo", controller.nvl("",""));
    		}
			
			
			
    		if($("input:checkbox[id='chk_gae_cusInfo']").is(":checked")){//고객혜택제공(선택)
    			if($("input:checkbox[id='chk_gae_cusInfoSMS']").is(":checked")){
    				fn_addHidden($form, "smsRecvYn", "0" );
    			}else{
    				fn_addHidden($form, "smsRecvYn", "1" );
    			}
    			if($("input:checkbox[id='chk_gae_cusInfoEMAIL']").is(":checked")){
    				fn_addHidden($form, "emailRecvYn", "0" );
    			}else{
    				fn_addHidden($form, "emailRecvYn", "1" );
    			}
    			if($("input:checkbox[id='chk_gae_cusInfoTEL']").is(":checked")){
    				fn_addHidden($form, "telRecvYn", "0" );
    			}else{
    				fn_addHidden($form, "telRecvYn", "1" );
    			}
    		}else{
    			fn_addHidden($form, "smsRecvYn", "1" );
    			fn_addHidden($form, "emailRecvYn", "1" );
    			fn_addHidden($form, "telRecvYn", "1" );
    		}
    		/*
    		 * 감면구분
    		 * */
    		if($("input:checkbox[id='chk_gae_gam']").is(":checked")){ //감면구분
    			fn_addHidden($form, "reduTypeCd", $("#slt_gae_gam").val());
    		}
    	
			/*if($("#inp_inf_reduTypeCd").val() != ""){
				$('input[id="chk_gae_gam"]').prop('checked', true);
				$("#slt_gae_gam").val($("#inp_inf_reduTypeCd").val());
				$("#div_chk_gae_gam").find(".checkCt").toggle();		
				$("#div_chk_gae_gam").toggleClass("open");
			}*/
    		
    		
    		
    		if(tab.indexOf("reqMe") > -1){//고객_신청자_본인
    			fn_addHidden($form, "aplnTypeCd", "01" ); //개인 : 신청자유형
    			fn_addHidden($form, "aplnNm", fn_nvl($("#inp_gae_custNm").val(),""));
    			fn_addHidden($form, "aplnCnctTelNo", "--"); //신청자 전화번호
    			fn_addHidden($form, "aplnJuminNo", juminBizNo ); //신청자 주민번호
    			fn_addHidden($form, "moAplnCertiTypeCd", fn_nvl($("#inp_moAplnCertiTypeCd").val(),"N") ); //신청자인증유형구분 sms 인중구분 01
    			fn_addHidden($form, "moAplnNmCertiTypeCd", fn_nvl($("#inp_moCustNmCertiTypeCd").val(),"") ); //신청자본인인증구분  moCustNmCertiTypeCd 오토신분증스캔시 03
    			fn_addHidden($form, "moAplnNmCertiKey", fn_nvl($("#inp_inf_certiKey").val(),"") ); //신청자 인증키
    			fn_addHidden($form, "moAplnNmCertiDh", fn_nvl($("#inp_inf_certiTime").val(),""));
    	    }else if(tab.indexOf("reqFa") > -1){ //고객_신청자_가족
    	    	var etc_juminBizNo = $("#inp_gae_fa_juminNo1").val() +""+ $("#inp_gae_fa_juminNo2").val();
    	    	var etc_mblTelNo = $("#slt_gae_fa_hpNo1").val() + "-" + $("#inp_gae_fa_hpNo2").val() + "-" + $("#inp_gae_fa_hpNo3").val();
    	    	fn_addHidden($form, "aplnTypeCd", "02" ); //가족 : 신청자유형
    			fn_addHidden($form, "aplnNm", fn_nvl($("#inp_gae_fa_custNm").val(),""));
    			fn_addHidden($form, "aplnCnctTelNo", fn_nvl(etc_mblTelNo,"")); //신청자 전화번호
    			fn_addHidden($form, "aplnJuminNo", etc_juminBizNo ); //신청자 주민번호
    			fn_addHidden($form, "moAplnCertiTypeCd", fn_nvl($("#inp_moAplnCertiTypeCd").val(),"N") ); //신청자인증유형구분 sms 인중구분 01
    			fn_addHidden($form, "moAplnNmCertiTypeCd", fn_nvl($("#inp_moAplnNmCertiTypeCd").val(),"") ); //신청자본인인증구분  moCustNmCertiTypeCd 오토신분증스캔시 03
    			fn_addHidden($form, "moAplnNmCertiKey", fn_nvl($("#inp_inf_certiKey2").val(),"")); //신청자 인증키
    			fn_addHidden($form, "moAplnNmCertiDh", fn_nvl($("#inp_inf_certiTime2").val(),""));
    	    }else if(tab.indexOf("reqDae") > -1){//고객_신청자_법정대리인
    	    	var etc_juminBizNo = $("#inp_gae_dae_juminNo1").val() +""+ $("#inp_gae_dae_juminNo2").val();
    	    	var etc_mblTelNo = $("#slt_gae_dae_hpNo1").val() + "-" + $("#inp_gae_dae_hpNo2").val() + "-" + $("#inp_gae_dae_hpNo3").val();
    	    	fn_addHidden($form, "aplnTypeCd", "05" ); //법정대리인 : 신청자유형
    			fn_addHidden($form, "aplnNm", fn_nvl($("#inp_gae_dae_custNm").val(),""));
    			fn_addHidden($form, "aplnCnctTelNo", fn_nvl(etc_mblTelNo,"")); //신청자 전화번호
    			fn_addHidden($form, "aplnJuminNo", etc_juminBizNo ); //신청자 주민번호
    			fn_addHidden($form, "moAplnCertiTypeCd", fn_nvl($("#inp_moAplnCertiTypeCd").val(),"N") ); //신청자인증유형구분 sms 인중구분 01
    			fn_addHidden($form, "moAplnNmCertiTypeCd", fn_nvl($("#inp_moAplnNmCertiTypeCd").val(),"")); //신청자본인인증구분  moCustNmCertiTypeCd 오토신분증스캔시 03
    			fn_addHidden($form, "moAplnNmCertiKey", fn_nvl($("#inp_inf_certiKey3").val(),"")); //신청자 인증키
    			fn_addHidden($form, "moAplnNmCertiDh", fn_nvl($("#inp_inf_certiTime3").val(),""));
    	    }
    	}
    	/*
		 * sms인증 렌탈있을 경우
		 * */	
		if(g_smsAuthUseYN == "Y"){
			//moAplnCertiMblTelNo
			//MO_APLN_CERTI_MBL_CO_CD	신청자본인인증이동통신사구분코드 moAplnCertiMblCoCd
			//MO_APLN_CERTI_MBL_TEL_NO	신청자본인인증이동전화번호 -포함 moAplnCertiMblTelNo
			//MO_APLN_ADD_PRDT_YN	신청자본인부가서비스안내관련동의여부 moAplnAddPrdtYn
			
			//동의대상구분코드	CM276	1	8718086	20120816	29991231	고객
			//동의대상구분코드	CM276	2	8718088	20120816	29991231	법정대리인
			//동의대상구분코드	CM276	3	8718090	20120816	29991231	청구계정
			//동의대상구분코드	CM276	4	8718090	20120816	29991231	신청자
			fn_addHidden($form, "moAplnCertiMblCoCd", $("#inp_inf_moAplnCertiMblCoCd").val());
			fn_addHidden($form, "moAplnCertiKey", $("#inp_inf_moAplnCertiKey").val());
			fn_addHidden($form, "moAplnCertiDh", $("#inp_inf_moAplnCertiDh").val());
			
			//var sms_mblTelNo = $("#slt_sms_hpNo1").val() + "-" + $("#inp_sms_hpNo2").val() + "-" + $("#inp_sms_hpNo3").val();
			//console.log(">>" + sms_mblTelNo);// moAplnCertiMblTelNo
			fn_addHidden($form, "moAplnCertiMblTelNo", $("#inp_inf_moAplnCertiMblTelNo").val() ); 
			if($("input:checkbox[id='chk_sms_meTerms5']").is(":checked")){ //신청자본인부가서비스안내관련동의여부 안내동의
				fn_addHidden($form, "moAplnAddPrdtYn", "0" ); //동의
			}else{
				fn_addHidden($form, "moAplnAddPrdtYn", "1" ); 
			}
		}
    	/*
    	 * 사업자 고객 
    	 * */
    	if(tab.indexOf("saup") > -1){
    		
    		fn_addHidden($form, "custNm", controller.nvl($("#inp_saup_custNm").val(),"")); //사업자> 고객명,상호*
    		var juminBizNo = $("#inp_saup_compNum1").val()+""+$("#inp_saup_compNum2").val()+""+$("#inp_saup_compNum3").val();
			fn_addHidden($form, "juminBizNo", controller.nvl(juminBizNo,"")); //사업자 > 주민,사업자번호*
			fn_addHidden($form, "rpsntNm", controller.nvl($("#inp_saup_ceoNm").val(),""));//사업자 > 대표자명
			fn_addHidden($form, "coNo", controller.nvl($("#inp_saup_corpNm").val(),""));//사업자 > 법인번호
			fn_addHidden($form, "indsTypeCd", controller.nvl($("#slt_saup_compType").val(),"")); //사업자 > 업종구분코드
			fn_addHidden($form, "bizCndDesc", controller.nvl($("#inp_saup_compBiz").val(),"")); // 사업자 >  업태내용
			fn_addHidden($form, "indsDesc", controller.nvl($("#inp_saup_compInds").val(),"")); // 사업자 >  업종내용
			
    		fn_addHidden($form, "custNo", ""); //사업자 > 고객번호(기존사용자)//fn_nvl($("#inp_moAplnNmCertiTypeCd").val(),"")
    		fn_addHidden($form, "moCustNmCertiTypeCd", ""); //사업자 > 고객인증유형구분 >외국인 미성년자는 ""  : MO_CUST_NM_CERTI_TYPE_CD 필드에 값 케이스 추가 ["03" : 신분증스캔 / "01" : 본인인증(SMS))]
    		fn_addHidden($form, "moCustNmCertiKey", controller.nvl($("#inp_inf_certiKey").val(),"")); //사업자 > 고객인증키
    		fn_addHidden($form, "moCustNmPossDh", controller.nvl($("#inp_inf_certiTime").val(),""));  //고객가능여부체크일시
			fn_addHidden($form, "moCustNmCertiDh", controller.nvl($("#inp_inf_certiTime").val(),""));  //고객인증일시
    		fn_addHidden($form, "custTypeCd", $("#inp_custTypeCd").val()); //고객구분코드
    		
    		var mblTelNo = $("#slt_saup_hpNo1").val() + "-" + $("#inp_saup_hpNo2").val() + "-" + $("#inp_saup_hpNo3").val();
    		fn_addHidden($form, "mblTelNo", controller.nvl(mblTelNo,""));//핸드폰번호*
    		
			if($("input:checkbox[id='chk_saup_telNo']").is(":checked")){
    			var telNo = $("#slt_saup_telNo1").val() + "-" + $("#inp_saup_telNo2").val() + "-" + $("#inp_saup_telNo3").val();
    			fn_addHidden($form, "telNo", controller.nvl(telNo,"")); //유선전화번호(선택)
    		}else{
    			fn_addHidden($form, "telNo", controller.nvl("",""));
    		}
			
			if($("input:checkbox[id='chk_saup_cusInfo']").is(":checked")){//고객혜택제공(선택)
    			if($("input:checkbox[id='chk_saup_cusInfoSMS']").is(":checked")){
    				fn_addHidden($form, "smsRecvYn", "0" );
    			}else{
    				fn_addHidden($form, "smsRecvYn", "1" );
    			}
    			if($("input:checkbox[id='chk_saup_cusInfoEMAIL']").is(":checked")){
    				fn_addHidden($form, "emailRecvYn", "0" );
    			}else{
    				fn_addHidden($form, "emailRecvYn", "1" );
    			}
    			if($("input:checkbox[id='chk_saup_cusInfoTEL']").is(":checked")){
    				fn_addHidden($form, "telRecvYn", "0" );
    			}else{
    				fn_addHidden($form, "telRecvYn", "1" );
    			}
    		}else{
    			fn_addHidden($form, "smsRecvYn", "1" );
    			fn_addHidden($form, "emailRecvYn", "1" );
    			fn_addHidden($form, "telRecvYn", "1" );
    		}
			
    		/*
    		 * 감면구분
    		 * */
    		if($("input:checkbox[id='chk_saup_gam']").is(":checked")){ //감면구분
    			fn_addHidden($form, "reduTypeCd", $("#slt_saup_gam").val());
    		}
    		//var juminNo = $("#inp_gae_juminNo1").val() +""+ $("#inp_gae_juminNo2").val();
    		if(tab.indexOf("reqMe") > -1){//사업자 대표자 본인 saup_reqMe
    			fn_addHidden($form, "aplnTypeCd", "03" ); //사업자 : 대표자
    			fn_addHidden($form, "aplnNm", fn_nvl($("#inp_saup_ceoNm2").val(),""));
    			fn_addHidden($form, "aplnCnctTelNo", fn_nvl($("#slt_saup_ceoHpNo1").val(),"")+"-"+$("#inp_saup_ceoHpNo2").val()+"-"+$("#inp_saup_ceoHpNo3").val()); //신청자 전화번호
    			fn_addHidden($form, "aplnJuminNo", $("#inp_saup_juminNo1").val()+""+$("#inp_saup_juminNo2").val()); //신청자 주민번호
    			fn_addHidden($form, "moAplnCertiTypeCd", fn_nvl($("#inp_moAplnCertiTypeCd").val(),"N") ); //신청자인증유형구분
    			fn_addHidden($form, "moAplnNmCertiTypeCd",fn_nvl($("#inp_moAplnNmCertiTypeCd").val(),"") ); //신청자본인인증구분  moCustNmCertiTypeCd
    			fn_addHidden($form, "moAplnNmCertiKey", fn_nvl($("#inp_inf_certiKey2").val(),"") ); //신청자 인증키
    			fn_addHidden($form, "moAplnNmCertiDh", fn_nvl($("#inp_inf_certiTime2").val(),""));
    			
    		}else if(tab.indexOf("reqJig") > -1){ //사업자 대표자 직원 saup_reqJig
    			fn_addHidden($form, "aplnTypeCd", "04" ); //사업자 : 직원
    			fn_addHidden($form, "aplnNm", fn_nvl($("#inp_saup_jig_ceoNm").val(),""));
    			fn_addHidden($form, "aplnCnctTelNo", fn_nvl($("#slt_saup_jig_ceoHpNo1").val(),"")+"-"+$("#inp_saup_jig_ceoHpNo2").val()+"-"+$("#inp_saup_jig_ceoHpNo3").val()); //신청자 전화번호
    			fn_addHidden($form, "aplnJuminNo", $("#inp_saup_jig_juminNo1").val()+""+$("#inp_saup_jig_juminNo2").val() ); //신청자 주민번호
    			fn_addHidden($form, "moAplnCertiTypeCd", fn_nvl($("#inp_moAplnCertiTypeCd").val(),"N") ); //신청자인증유형구분 01휴대폰 03신분증스캔
    			fn_addHidden($form, "moAplnNmCertiTypeCd", fn_nvl($("#inp_moAplnNmCertiTypeCd2").val(),"") ); //신청자본인인증구분  moCustNmCertiTypeCd
    			fn_addHidden($form, "moAplnNmCertiKey", fn_nvl($("#inp_inf_certiKey3").val(),"") ); //신청자 인증키
    			fn_addHidden($form, "moAplnNmCertiDh", fn_nvl($("#inp_inf_certiTime3").val(),""));
    		}
    	}
    	/*
    	 * 설치정보
    	 * */
    	var prodtSize = Number(g_smartScrptCntrtInfoListLength);
    	var prodtCompCnt = 0; 
    	if(prodtSize > 0){
    		for(var i = 0; i < prodtSize; i++){
    			if($("#tab_comp_installInfo_"+i).attr("class").indexOf("completed") > -1){
    				prodtCompCnt++;
    			}
    		}
    		if(prodtSize == prodtCompCnt){
    			for(var i = 0; i < prodtSize; i++){
        			if($("#tab_comp_installInfo_"+i).attr("class").indexOf("completed") > -1){
    	    			fn_addHidden($form, "moScrbrNo", fn_nvl($("#inp_moScrbrNo_"+i).val(),"")); 		//가입계약번호
    	    			fn_addHidden($form, "prdtTypeCd", fn_nvl($("#inp_prdtTypeCd_"+i).val(),"")); 		//가입계약번호
    	    			fn_addHidden($form, "instalPlceZipCd", fn_nvl($("#inp_addr_"+i).val(),"")); 	//설치장소우편번호
    	    			fn_addHidden($form, "instalPlceAddr", fn_nvl($("#inp_addr2_"+i).val(),""));		//설치장소주소
    	    			fn_addHidden($form, "instalPlceSuppAddr", fn_nvl($("#inp_addr3_"+i).val(),""));	//설치장소보조주소
    	    			fn_addHidden($form, "addrSeltnTypeCd", $("#inp_addrSeltnTypeCd_"+i).val());		//주소선택구분코드
    	    			
    	    			fn_addHidden($form, "refMastAddr", $("#inp_refMastAddr_"+i).val());			//	참조기본주소
    	    			fn_addHidden($form, "refSuppAddr", $("#inp_refSuppAddr_"+i).val());		//	참조보조주소
    	    			
    	    			fn_addHidden($form, "rdNmVrfCd", $("#inp_addr_rdNmVrfCd_"+i).val());			//	도로명검증코드
    	    			fn_addHidden($form, "ktDongCd", $("#inp_addr_ktDongCd_"+i).val());		//	kt동코드	
    	    			
    	    			fn_addHidden($form, "addrBunjiCl", $("#inp_addr_addrBunjiCl_"+i).val()); //주소번지유형
    	    			fn_addHidden($form, "addrBunji", $("#inp_addr_addrBunji_"+i).val());//	주소번지
    	    			fn_addHidden($form, "addrHo", $("#inp_addr_addrHo_"+i).val());//addrHo	주소호
    	    			fn_addHidden($form, "refAddr",$("#inp_refMastAddr_"+i).val()+" "+$("#inp_refSuppAddr_"+i).val()); //refAddr	참조주소
    	    			
    	    			/*
    	    			 * 수용국구분(인터넷만)
    	    			 * */
    	    			if($("#inp_prdtTypeCd_"+i).val() == "02"){
    	    				fn_addHidden($form, "ktOfceCd",$("#inp_intHostCode_"+i).val()); //kt수용국코드
    	        			fn_addHidden($form, "ktOfceNm",$("#inp_intHost_"+i).val()); 	//kt수용국코드명
    	    			}else{
    	    				fn_addHidden($form, "ktOfceCd",$("#inp_addr_ktOfceCd_"+i).val()); //kt수용국코드
    	        			fn_addHidden($form, "ktOfceNm",$("#inp_addr_ktOfceNm_"+i).val()); //kt수용국코드명
    	    			}
    	    			fn_addHidden($form, "ktBldId",fn_nvl($("#inp_addr_ktBldId_"+i).val(),MSG.SPACE)); //kt건물아이디
    	    			fn_addHidden($form, "ktRdNmId",fn_nvl($("#inp_addr_ktRdNmId_"+i).val(),MSG.SPACE)); //kt도로명아이디
    	
    	    			
    	    			
    	    			fn_addHidden($form, "instalPossDh", $("#inp_instalPossDh_"+i).val());//설치가능여부체크일시
    	    			fn_addHidden($form, "instalCrclNetCd", $("#slt_installJum_"+i).val()); //설치유통망코드
    	    			var v_instalCrclNetNm = $("#slt_installJum_"+i+" option:selected").text().replace(/\u00A0/g, " ").replace(/[\r\n]+/g, "\n");

    	    			fn_addHidden($form, "instalCrclNetNm", v_instalCrclNetNm); //설치유통망명
    	    			//console.log(" slt_installJum_ >>>>>>> " + v_instalCrclNetNm);
    	    			
    	    			var v_preferSvcOpenDh = fn_replaceAll($("#inp_installDay_"+i).val(),"-","")+""+$("#slt_installTime_"+i).val()+"0000";
    	    			fn_addHidden($form, "preferSvcOpenDh", fn_nvl(v_preferSvcOpenDh,"")); //	희망개통일시
    	    			fn_addHidden($form, "instalClCd", $("#inp_instalClCd_"+i).val()); //	설치유형코드
    	    			
    	    			
    	    			fn_addHidden($form, "aptCd", MSG.SPACE);	//아파트코드
    	    			fn_addHidden($form, "aptDong", MSG.SPACE);	//	아파트동
    	    			fn_addHidden($form, "aptHo", MSG.SPACE);	//	아파트호
    	    			fn_addHidden($form, "bldMgmtNo", MSG.SPACE);	//	건물관리번호
        			}

        		}
    		}
    		
    	}
		 /*가입하려는 상품(이벤트)에 납부방법과 배타 관계에 있는 항목 체크
		   3-1. 가입 대상 상품에 TV 상품이 있는 경우 청약 상품 정보 조회 API 호출
		         - 대상 상품의 납부방법 배타관계 추출
		         - "선택하신 이벤트는 [XXX] 납부방법으로 가입하실 수 없습니다."
		   3-2. 가입 대상 상품에 인터넷 상품이 있는 경우 청약 상품 정보 조회 API 호출
		         - 대상 상품의 납부방법 배타관계 추출
		         - "선택하신 이벤트는 [XXX] 납부방법으로 가입하실 수 없습니다."
		   3-3. [3-1 ~ 3-2] 배타관계에 있지 않은 납부방법만 추출하여 설정 가능 대상으로 세팅
		 */
		 
    	/*
    	 * 납부정보 > 지불정보
    	 * */
    	if(tab.indexOf("payAuto") > -1){ //############ 자동이체 ##################
    		fn_addHidden($form, "payMthCd", "3" ); //납부방법코드
    		fn_addHidden($form, "bankCd", $("#slt_auto_bankCd").val() ); //금융기관코드
    		fn_addHidden($form, "acctNo", $("#inp_auto_acctNo").val() ); //계좌번호
    		fn_addHidden($form, "depOwnNm", $("#inp_auto_depOwnNm").val() ); //예금주명
    		fn_addHidden($form, "moTrnfrAuthCertiDh", $("#inp_inf_payAutoCertiTime").val() ); //지불인증일시
    		fn_addHidden($form, "moTrnfrAuthCertiRsltYn", $("#inp_inf_payAutoCertiResult").val() ); //지불인증결과여부
    		fn_addHidden($form, "autoPayAgreeYn", "0" );//자동납부동의여부 동의(0) / 미동의(1)
    		fn_addHidden($form, "acctJuminBizNo", $("#inp_auto_acctJuminBizNo").val() );////납부자주민/사업자번호
    		fn_addHidden($form, "creditCardOwnerNm", $("#inp_auto_depOwnNm").val() ); //신용카드소유주명
    		/*
        	 * 납부정보(자동이체) > 요금확인
        	 * */
        	 if(tab.indexOf("chkpEmail") > -1){ 
        		 /*
        		  * //자동이체 > 이메일
        		  * */
        		 fn_addHidden($form, "invceMediaCd", "33" ); //청구매체코드
        		 fn_addHidden($form, "invceEmailId", $("#inp_chkp_email").val() + "@" + $("#inp_chkp_email2").val() ); //청구이메일주소
        		 /*
        		  * 현금영수증
        		  * */
        		 var rdo_chkp_cashReceiptYn = $('input:radio[name="rdo_chkp_cashReceiptYn"]:checked').val();
        		 fn_addHidden($form, "cashReceiptYn", rdo_chkp_cashReceiptYn ); //cashReceiptYn	현금영수증 발행 여부
        		 if(rdo_chkp_cashReceiptYn == "0"){
        			 var v_chkp_cashHpNo = fn_nvl($("#slt_chkp_cashHpNo").val(),"")+"-"+$("#inp_chkp_cashHpNo2").val()+"-"+$("#inp_chkp_cashHpNo3").val()
        			 fn_addHidden($form, "cashReceiptMblTelNo", v_chkp_cashHpNo ); //cashReceiptMblTelNo	현금영수증 발행 이동전화번호 
        		 }
        		 /*
        		  * 청구주소
        		  * */
        		 var rdo_chkp_invceAddr = $('input:radio[name="rdo_chkp_invceAddr"]:checked').val();
        		 //console.log("rdo_chkp_invceAddr >> " + rdo_chkp_invceAddr);
        		 fn_addHidden($form, "moInvceInstalYn", rdo_chkp_invceAddr ); //moInvceInstalYn	청구처주소설치장소주소동일여부
        		 if(rdo_chkp_invceAddr == "Y"){
        			 data.setInvceDataInfo("Y", $form, "chkpEmail");
        		 }else{
        			 data.setInvceDataInfo("N", $form, "chkpEmail");
        		 }
        		 //var mblTelNo = $("#slt_gae_hpNo1").val() + "-" + $("#inp_gae_hpNo2").val() + "-" + $("#inp_gae_hpNo3").val();
        		 fn_addHidden($form, "invceMblTelNo", "--" ); 	//InvceMblTelNo	청구처이동전화번호
        		 
        		 /*
        		  * 과세구분(사업자일경우에만)
        		  * */
        		 if(tab.indexOf("saup") > -1){
        			 var rdo_taxTypeCd = $('input:radio[name="rdo_chkpAuto_email_taxTypeCd"]:checked').val();
        			 fn_addHidden($form, "taxTypeCd", rdo_taxTypeCd ); 	//과세구분
        		 }
        	 }else if(tab.indexOf("chkpMobile") > -1){
        		 /*
        		  * //자동이체 > 모바일
        		  * */
        		 fn_addHidden($form, "invceMediaCd", "79" ); //청구매체코드
        		 fn_addHidden($form, "invceEmailId", "@"); //청구이메일주소
        		 /*
        		  * 현금영수증
        		  * */
        		 var rdo_chkp_cashReceiptYn = $('input:radio[name="rdo_chkpAuto_mobile_cashReceiptYn"]:checked').val();
        		 fn_addHidden($form, "cashReceiptYn", rdo_chkp_cashReceiptYn ); //cashReceiptYn	현금영수증 발행 여부
        		 if(rdo_chkp_cashReceiptYn == "0"){
        			 var v_chkp_cashHpNo = fn_nvl($("#slt_chkpAuto_mobile_cashHpNo1").val(),"")+"-"+$("#inp_chkpAuto_mobile_cashHpNo2").val()+"-"+$("#inp_chkpAuto_mobile_cashHpNo3").val()
        			 fn_addHidden($form, "cashReceiptMblTelNo", v_chkp_cashHpNo ); //cashReceiptMblTelNo	현금영수증 발행 이동전화번호 
        		 }
        		 /*
        		  * 청구주소
        		  * */
        		 var rdo_chkp_invceAddr = $('input:radio[name="rdo_chkpAuto_mobile_invceAddr"]:checked').val();
        		 fn_addHidden($form, "moInvceInstalYn", rdo_chkp_invceAddr ); //moInvceInstalYn	청구처주소설치장소주소동일여부
        		 if(rdo_chkp_invceAddr == "Y"){
        			 data.setInvceDataInfo("Y", $form, "chkpMobile");
        		 }else{
        			 data.setInvceDataInfo("N", $form, "chkpMobile");
        		 }
        		 
        		 var mblTelNo = $("#slt_chkpAuto_mobile_hpNo1").val() + "-" + $("#inp_chkpAuto_mobile_hpNo2").val() + "-" + $("#inp_chkpAuto_mobile_hpNo3").val();
        		 fn_addHidden($form, "invceMblTelNo", mblTelNo ); 	//InvceMblTelNo	청구처이동전화번호
        		 
        		 /*
        		  * 과세구분(사업자일경우에만)
        		  * */
        		 if(tab.indexOf("saup") > -1){
        			 var rdo_taxTypeCd = $('input:radio[name="rdo_chkpAuto_mobile_taxTypeCd"]:checked').val();
        			 fn_addHidden($form, "taxTypeCd", rdo_taxTypeCd ); 	//과세구분
        		 }
        	 }else if(tab.indexOf("chkpGoji") > -1){
        		 /*
        		  * //자동이체 > 고지서
        		  * */
        		 fn_addHidden($form, "invceMediaCd", "11" ); //청구매체코드
        		 fn_addHidden($form, "invceEmailId", "@"); //청구이메일주소
        		 
        		 /*
        		  * 현금영수증
        		  * */
        		 var rdo_chkp_cashReceiptYn = $('input:radio[name="rdo_chkpAuto_goji_cashReceiptYn"]:checked').val();
        		 fn_addHidden($form, "cashReceiptYn", rdo_chkp_cashReceiptYn ); //cashReceiptYn	현금영수증 발행 여부
        		 if(rdo_chkp_cashReceiptYn == "0"){
        			 var v_chkp_cashHpNo = fn_nvl($("#slt_chkpAuto_goji_cashHpNo1").val(),"")+"-"+$("#inp_chkpAuto_goji_cashHpNo2").val()+"-"+$("#inp_chkpAuto_goji_cashHpNo3").val();
        			 fn_addHidden($form, "cashReceiptMblTelNo", v_chkp_cashHpNo ); //cashReceiptMblTelNo	현금영수증 발행 이동전화번호 
        		 }
        		 
        		 /*
        		  * 청구주소
        		  * */
        		 var rdo_chkp_invceAddr = $('input:radio[name="rdo_chkpAuto_goji_invceAddr"]:checked').val();
        		 fn_addHidden($form, "moInvceInstalYn", rdo_chkp_invceAddr ); //moInvceInstalYn	청구처주소설치장소주소동일여부
        		 if(rdo_chkp_invceAddr == "Y"){
        			 data.setInvceDataInfo("Y", $form, "chkpGoji");
        		 }else{
        			 data.setInvceDataInfo("N", $form, "chkpGoji");
        		 }
        		 //var mblTelNo = $("#slt_gae_hpNo1").val() + "-" + $("#inp_gae_hpNo2").val() + "-" + $("#inp_gae_hpNo3").val();
        		 fn_addHidden($form, "invceMblTelNo", "--" ); 	//InvceMblTelNo	청구처이동전화번호
        		 
        		 /*
        		  * 과세구분(사업자일경우에만)
        		  * */
        		 if(tab.indexOf("saup") > -1){
        			 var rdo_taxTypeCd = $('input:radio[name="rdo_chkpAuto_goji_taxTypeCd"]:checked').val();
        			 fn_addHidden($form, "taxTypeCd", rdo_taxTypeCd ); 	//과세구분
        		 }
        	 }
        	 
    	}else if(tab.indexOf("payCard") > -1){ //############	카드이체	############
    		fn_addHidden($form, "payMthCd", "2" );
    		fn_addHidden($form, "creditCardKindCd", $("#slt_card_cardComp").val() ); 	//신용카드종류코드
    		var cardNo = $("#inp_card_cardNo1").val()+""+$("#inp_card_cardNo2").val()+""+$("#inp_card_cardNo3").val()+""+$("#inp_card_cardNo4").val();
    		fn_addHidden($form, "creditCardNo", cardNo); 		//신용카드번호
    		fn_addHidden($form, "creditCardOwnerNm", $("#inp_card_cardNabbNm").val()); 	//신용카드소유주명
    		fn_addHidden($form, "creditCardValidPerdDm", $("#inp_card_cardYYYYMM").val()); //신용카드유효기한년월	
    		fn_addHidden($form, "moCreditCardCertiDh", $("#inp_inf_payCardCertiTime").val()); //신용카드인증일시
    		fn_addHidden($form, "moCreditCardCertiRsltYn", $("#inp_inf_payCardCertiResult").val()); //신용카드인증결과여부	
    		fn_addHidden($form, "acctJuminBizNo", $("#inp_card_cardJuminBizNo").val() ); 	//납부자주민/사업자번호		
    		fn_addHidden($form, "autoPayAgreeYn", "0" );	//자동납부동의여부 동의(0) / 미동의(1)
    		/*
        	 * 납부정보(카드이체) > 요금확인
        	 * */
        	 if(tab.indexOf("chkpCardEmail") > -1){ //이메일
        		 /*
        		  * //카드이체 > 이메일
        		  * */
        		 fn_addHidden($form, "invceMediaCd", "33" ); //청구매체코드
        		 fn_addHidden($form, "invceEmailId", $("#inp_chkpCard_email").val() + "@" + $("#inp_chkpCard_email2").val() ); //청구이메일주소
        		 /*
        		  * 현금영수증
        		  * */
        		 var rdo_chkp_cashReceiptYn = $('input:radio[name="rdo_chkpCard_cashReceiptYn"]:checked').val();
        		 fn_addHidden($form, "cashReceiptYn", rdo_chkp_cashReceiptYn ); //cashReceiptYn	현금영수증 발행 여부
        		 if(rdo_chkp_cashReceiptYn == "0"){
        			 var v_chkp_cashHpNo = fn_nvl($("#slt_chkpCard_cashHpNo").val(),"")+"-"+$("#inp_chkpCard_cashHpNo2").val()+"-"+$("#inp_chkpCard_cashHpNo3").val()
        			 fn_addHidden($form, "cashReceiptMblTelNo", v_chkp_cashHpNo ); //cashReceiptMblTelNo	현금영수증 발행 이동전화번호 
        		 }
        		 
        		 /*
        		  * 청구주소
        		  * */
        		 var rdo_chkp_invceAddr = $('input:radio[name="rdo_chkpCard_invceAddr"]:checked').val();
        		 fn_addHidden($form, "moInvceInstalYn", rdo_chkp_invceAddr ); //moInvceInstalYn	청구처주소설치장소주소동일여부
        		 if(rdo_chkp_invceAddr == "Y"){
        			 data.setInvceDataInfo("Y", $form, "chkpCardEmail");
        		 }else{
        			 data.setInvceDataInfo("N", $form, "chkpCardEmail");
        		 }
        		 
        		 var mblTelNo = $("#slt_gae_hpNo1").val() + "-" + $("#inp_gae_hpNo2").val() + "-" + $("#inp_gae_hpNo3").val();
        		 fn_addHidden($form, "invceMblTelNo", mblTelNo ); 	//InvceMblTelNo	청구처이동전화번호
        		 
        		 /*
        		  * 과세구분(사업자일경우에만)
        		  * */
        		 if(tab.indexOf("saup") > -1){
        			 var rdo_taxTypeCd = $('input:radio[name="rdo_chkpCard_email_taxTypeCd"]:checked').val();
        			 fn_addHidden($form, "taxTypeCd", rdo_taxTypeCd ); 	//과세구분
        		 }
        		
        	 }else if(tab.indexOf("chkpCardMobile") > -1){
        		 /*
        		  * //카드이체 > 모바일
        		  * */
        		 fn_addHidden($form, "invceMediaCd", "79" ); //청구매체코드
        		 fn_addHidden($form, "invceEmailId", "@"); //청구이메일주소
        		 
        		 /*
        		  * 현금영수증
        		  * */
        		 var rdo_chkp_cashReceiptYn = $('input:radio[name="rdo_chkpCard_mobile_cashReceiptYn"]:checked').val();
        		 fn_addHidden($form, "cashReceiptYn", rdo_chkp_cashReceiptYn ); //cashReceiptYn	현금영수증 발행 여부
        		 if(rdo_chkp_cashReceiptYn == "0"){
        			 var v_chkp_cashHpNo = fn_nvl($("#slt_chkpCard_mobile_cashHpNo1").val(),"")+"-"+$("#inp_chkpCard_mobile_cashHpNo2").val()+"-"+$("#inp_chkpCard_mobile_cashHpNo3").val()
        			 fn_addHidden($form, "cashReceiptMblTelNo", v_chkp_cashHpNo ); //cashReceiptMblTelNo	현금영수증 발행 이동전화번호 
        		 }
        		 
        		 /*
        		  * 청구주소
        		  * */
        		 var rdo_chkp_invceAddr = $('input:radio[name="rdo_chkpCard_mobile_invceAddr"]:checked').val();
        		 fn_addHidden($form, "moInvceInstalYn", rdo_chkp_invceAddr ); //moInvceInstalYn	청구처주소설치장소주소동일여부
        		 if(rdo_chkp_invceAddr == "Y"){
        			 data.setInvceDataInfo("Y", $form, "chkpCardMobile");
        		 }else{
        			 data.setInvceDataInfo("N", $form, "chkpCardMobile");
        		 }
        		 
        		 var mblTelNo = $("#slt_chkpCard_mobile_hpNo1").val() + "-" + $("#inp_chkpCard_mobile_hpNo2").val() + "-" + $("#inp_chkpCard_mobile_hpNo3").val();
        		 fn_addHidden($form, "invceMblTelNo", mblTelNo ); 	//InvceMblTelNo	청구처이동전화번호
        		 
        		 /*
        		  * 과세구분(사업자일경우에만)
        		  * */
        		 if(tab.indexOf("saup") > -1){
        			 var rdo_taxTypeCd = $('input:radio[name="rdo_chkpCard_mobile_taxTypeCd"]:checked').val();
        			 fn_addHidden($form, "taxTypeCd", rdo_taxTypeCd ); 	//과세구분
        		 }
        	 }else if(tab.indexOf("chkpCardGoji") > -1){
        		 /*
        		  * //카드이체 > 고지서
        		  * */
        		 fn_addHidden($form, "invceMediaCd", "11" ); //청구매체코드
        		 fn_addHidden($form, "invceEmailId", "@"); //청구이메일주소
        		 /*
        		  * 현금영수증
        		  * */
        		 var rdo_chkp_cashReceiptYn = $('input:radio[name="rdo_chkpCard_goji_cashReceiptYn"]:checked').val();
        		 fn_addHidden($form, "cashReceiptYn", rdo_chkp_cashReceiptYn ); //cashReceiptYn	현금영수증 발행 여부
        		 if(rdo_chkp_cashReceiptYn == "0"){
        			 var v_chkp_cashHpNo = fn_nvl($("#slt_chkpCard_goji_cashHpNo1").val(),"")+"-"+$("#inp_chkpCard_goji_cashHpNo2").val()+"-"+$("#inp_chkpCard_goji_cashHpNo3").val();
        			 fn_addHidden($form, "cashReceiptMblTelNo", v_chkp_cashHpNo ); //cashReceiptMblTelNo	현금영수증 발행 이동전화번호 
        		 }
        		 
        		 /*
        		  * 청구주소
        		  * */
        		 var rdo_chkp_invceAddr = $('input:radio[name="rdo_chkpCard_goji_invceAddr"]:checked').val();
        		 fn_addHidden($form, "moInvceInstalYn", rdo_chkp_invceAddr ); //moInvceInstalYn	청구처주소설치장소주소동일여부
        		 if(rdo_chkp_invceAddr == "Y"){
        			 data.setInvceDataInfo("Y", $form, "chkpCardGoji");
        		 }else{
        			 data.setInvceDataInfo("N", $form, "chkpCardGoji");
        		 }
        		 
        		// var mblTelNo = $("#slt_gae_hpNo1").val() + "-" + $("#inp_gae_hpNo2").val() + "-" + $("#inp_gae_hpNo3").val();
        		 fn_addHidden($form, "invceMblTelNo", "--" ); 	//InvceMblTelNo	청구처이동전화번호
        		 
        		 /*
        		  * 과세구분(사업자일경우에만)
        		  * */
        		 if(tab.indexOf("saup") > -1){
        			 var rdo_taxTypeCd = $('input:radio[name="rdo_chkpCard_goji_taxTypeCd"]:checked').val();
        			 fn_addHidden($form, "taxTypeCd", rdo_taxTypeCd ); 	//과세구분
        		 }
        	 }
    	}
    	
    	/*
    	 * 파일정보 셋팅 이미지서류관리 서버단에서 등록 할필요없음
    	 * 
    	 * moRecvNo	스마트청약접수번호
			moFileType	첨부파일유형
			moFileNum	첨부파일유형페이지번호
			moFileNm	첨부파일명
			moFileScanType	파일스캔유형
			moFileSize	첨부파일크기
			moFile	첨부파일
			moFileRsltCd	파일전송결과
    	 * */
    	
    	
    //contract/saveReceiptCustInfo.json 고객정보 체크 및 저장
	//@RequestMapping(value = {"/contract/saveReceiptSetPlaceTv.json"}) ////가입고객정보/설치정보/납부정보 - TV설치장소 체크및저장
	//@RequestMapping(value = {"/contract/saveReceiptSetPlaceInt.json"}) 가입고객정보/설치정보/납부정보 - 인터넷 설치장소 체크및저장
    //@RequestMapping(value = {"/contract/saveReceiptSetPlaceHome.json"}) 가입고객정보/설치정보/납부정보 - 홈상품 설치장소 체크및저장
    //@RequestMapping(value = {"/contract/saveReceiptPaymentInfo.json"}) 가입고객정보/설치정보/납부정보 - 납부정보 체크및저장
	
    
    //fn_callAjax('/contract/saveReceiptCustInfo.json', $form.serialize(), resultNextStep)
    
    var formData = $form.serialize();
    return formData;
  /*  var ajaxController = {
        init: function() {
            this.type = "post";
            this.url = "";
            this.data =  formData;
            this.dataType = "json";
        },
        start: function() {
        	var result = null;
            $.ajax({
                async: false,
                url: this.url,
                type: this.type,
                data: this.data,
                dataType: this.dataType,
                success: function (json) {
                    result = json;
                },
            });
            return result;
        }
    };

    
     * 고객정보 호출
     * 
    ajaxController.init();
    ajaxController.url = contextPath + "/contract/saveReceiptCustInfo.json"; //고객정보 체크 및 저장
    var resultCust = ajaxController.start();
    if(resultCust.retCode == "SUCC"){
    	console.log("resultCust:" + resultCust.retCode);
    }else{
    	fnReqValCheckMsgOutput(resultCust.retMsg);
		return;
    }
    
     * 설치정보 체크
      
    ajaxController.init();
    ajaxController.url = contextPath + "/contract/saveReceiptSetPlaceTv.json"; //가입고객정보/설치정보/납부정보 - TV설치장소 체크및저장
    var resultInstall = ajaxController.start();
    if(resultInstall.retCode == "SUCC"){
    	console.log("resultInstall:" + resultInstall.retCode);
    }else{
    	fnReqValCheckMsgOutput(resultInstall.retMsg);
		return;
    }
    
    
     * 납부정보 체크
     * 
	ajaxController.init();
    ajaxController.url = contextPath + "/contract/saveReceiptPaymentInfo.json"; //가입고객정보/설치정보/납부정보 - 납부정보 체크및저장
    var resultPay = ajaxController.start();
    if(resultPay.retCode == "SUCC"){
    	console.log("resultPay:" + resultPay.retCode);
    	
		var $form = $('<form></form>');
		$form.attr('method', 'post');
		$form.attr('action', contextPath + "/contract/receiptContract.do");
	    $form.appendTo('body');
	    fn_addHidden($form, "moRecvNo",  $("#smartRecvNo").val());
	    fn_addHidden($form, "moProgStatCd",  g_moProgStatCd);
	    $form.submit();	
    }else{
    	fnReqValCheckMsgOutput(resultPay.retMsg);
		return;
    }*/
}



/*
 * 미사용 나주에 삭제
 * */
resultNextStep = function(result){
	var retCode = result.retCode;
	var retMsg = result.retMsg;
	//console.log(retCode);
	if(retCode == "SUCC"){
		alert(retCode);
		//window.location.replace(contextPath + "/contract/receiptContract.do");
	}else{
		alert(retMsg);
		return;
	}
	
}
/*
 * json result 고객인증
 * */
function fnCustAuthCofirm(v_tartgetId, v_moRecvNo, v_custNm, v_jumin, v_prdtTypeCdGubun, v_custTypeCd, v_aplnTypeCd, v_custNmCertiTypeCd){
	var param = {
			 targetId : v_tartgetId
			, moRecvNo : v_moRecvNo
			, custNm : v_custNm
			, juminBizNo : v_jumin
			, prdtTypeCd : v_prdtTypeCdGubun //구분코드 01 : 결합계약 02 : 인터넷할인계약 03 : 홈렌탈계약
			, custTypeCd : v_custTypeCd //고객구분코드	CM008	1	개인
			, aplnTypeCd : v_aplnTypeCd
			, custNmCertiTypeCd : v_custNmCertiTypeCd
		};
	fn_callAjaxAsync('/contract/selectCustAuthCofirm.json', param, result.CustAuthCofirm);
}
/*
 * json result 사업자
 * */
function fnSaupAuthCofirm(v_tartgetId, v_moRecvNo, v_custNm, v_juminBizNo, v_rpsntNm, v_coNo, v_custTypeCd){
	var param = {
			 targetId : v_tartgetId
			, moRecvNo : v_moRecvNo
			, custNm : v_custNm
			, juminBizNo : v_juminBizNo
			, rpsntNm : v_rpsntNm
			, coNo : v_coNo
			, custTypeCd : v_custTypeCd //고객구분코드	CM008	1	개인
		};
	fn_callAjaxAsync('/contract/selectSaupAuthCofirm.json', param, result.SaupAuthCofirm);
}

/*
 * 실명인증 제외 고객정보 업데이트
 * */
function fnUpdateSecNumCerti(v_tartgetId, paramObj){
	var param = {
			 targetId : v_tartgetId
			, moRecvNo : paramObj.moRecvNo
			, custNm : paramObj.custNm			
			, juminBizNo : paramObj.juminBizNo
			, custTypeCd : paramObj.custTypeCd
			, aplnTypeCd : paramObj.aplnTypeCd
			, moCustNmCertiKey : paramObj.moCustNmCertiKey
			
		};
	fn_callAjaxAsync('/contract/updateSecNumExceptNameCerti.json', param, result.updateSecNumCerti);
}
var data = {
		init : function (){
			//console.log("data.init");
			/*
			 * 설치정보데이터 셋팅
			 * */
			var prodtSize = Number(g_smartScrptCntrtInfoListLength);
	    	if(prodtSize > 0){
	    		var count = 0;
	    		
	    		inner(count);
	    		
	    		function inner(v_count){
	    			if(v_count >= prodtSize){
	    				return;
	    			}
	    			
	    			var index = v_count;
	    			var inp_preferSvcOpenDh = "#inp_preferSvcOpenDh_"+index;  //희망일자
	    			var inp_instalCrclNetCd = "#inp_instalCrclNetCd_"+index;  //설치유통망코드
	    			
	    			if(fn_nvl($(inp_preferSvcOpenDh).val(),"") != ""){
	    				
	    				/*
	    				 * 설치점조회
	    				 * 
	    				 */
	    				var paramObj = {
    						instalPlceZipCd : $("#inp_addr_" + index).val() 		//설치우편번호*
    						, instalPlceAddr : $("#inp_addr2_" + index).val() 		//설치주소*
    						, instalPlceSuppAddr : $("#inp_addr3_" + index).val() 	//설치보조주소*
    						, refBaseAddr : $("#inp_refMastAddr_" + index).val()	//참조기본주소*
    						, refBaseSuppAddr : $("#inp_refSuppAddr_" + index).val() 	//참조보조주소*
    						, addrSeltnTypeCd : "3" 	//	주소선택구분코드*
    						, deptCd : g_sessionUserDeptCd 			//	판매자조직코드*
    						, eventNo : fn_nvl($("#inp_eventNo_" + index).val(),$("#inp_prdtCd_" + index).val()) 			//이벤트번호 * 이벤트번호로 SLT유통망 판단
    						, tempLoadType : "INIT"
	    				}
	    				fnApiCall_INF_025(index, paramObj, resultApi.INF_025);
	    				
	    				/*
	    				 * 설치희망일 시간 셋팅
	    				 *
	    				 */ 
	    				
	    				var v_pDh = $(inp_preferSvcOpenDh).val();
	    				var day = v_pDh.substr(0,4)+"-"+v_pDh.substr(4,2)+"-"+v_pDh.substr(6,2);
	    				var time = v_pDh.substr(8,2);
	    				$("#slt_installJum_"+index).val($(inp_instalCrclNetCd).val()); //설치유통망코드
	    				$("#inp_installDay_"+index).val(day);
	    				$("#slt_installJum_"+index).trigger('change');
	    				$("#slt_installTime_"+index).val(time);
	    				/*var paramObj2 = {
    						instalPlceZipCd : $("#inp_addr_" + index).val()			//설치우편번호	
    						, instalPlceAddr : $("#inp_addr2_" + index).val()			//설치주소	
    						, instalPlceSuppAddr : $("#inp_addr3_" + index).val()	//설치보조주소	
    						, refBaseAddr : $("#inp_refMastAddr_" + index).val()				//참조기본주소	
    						, refBaseSuppAddr : $("#inp_refSuppAddr_" + index).val()		//참조보조주소	
    						, addrSeltnTypeCd : "3"		//주소선택구분코드	
    						, instalCrclNetCd : $(inp_instalCrclNetCd).val()		//설치점	TV/인터넷인 경우
    						, preferSvcOpenDh : v_pDh.substr(0,8)   		 //개통희망일
    					}
    					fnApiCall_INF_015(index, paramObj2, resultApi.INF_015);*/
	    				
	    				//$("#slt_installJum_"+index).trigger('change');
	    				//inp_installDay_ 설치일자
	    				//slt_installTime_ 설치시간
	    			}
	    			
	    			
	    			inner(++count);
	    		}
	    	}
			/*
			 * 데이터 체크
			 * */
			data.nextCheckStep();
		},
		//데이터등록 : 가입고객정보
		dataInsertCustInfo : function (){
			var formObj = fnNextStep();
		    controller.ajaxSend( {
				url : contextPath + '/contract/saveReceiptCustInfo.json'
				, data : formObj
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var retCode = result.retCode;
					var retMsg = result.retMsg;
					if (retCode == "SUCC") {
						$("#inp_nextCheck_dataCustFlag").val("N");
					} else {
						/*var tab = ui.tabOnCheck();
						if(tab.indexOf("gae") > -1){
						}else{
						}*/
						/*
						 * 데이터 필수여부 확인
						 * */
						$("#inp_nextCheck_dataCustReqData").val("NO");
						/*
			        	 * 데이터 체크
			        	 * */
			        	data.nextCheckStep();
			        	
			        	/*
			        	 * 메시지 출력
			        	 * */
			        	
			        	g_msgObj.title = "";
			        	g_msgObj.msg1 = retMsg;
						g_msgObj.msg2 = "";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						//fnReqValCheckMsgOutput(retMsg);
						/*if(retCode == 'LOGIN'){
							goLogin();
						}else{
							fnReqValCheckMsgOutput(retMsg);
						}*/
				    	
					}
				}
		    });
		    
		},
		//데이터등록 : 설치정보
		dataInsertInstallInfo : function (){

			var prodtSize = Number(g_smartScrptCntrtInfoListLength);
			var prodtCompCnt = 0; 
			for(var i = 0; i < prodtSize; i++){
    			if($("#tab_comp_installInfo_"+i).attr("class").indexOf("completed") > -1){
    				prodtCompCnt++;
    			}
    		}
    		if(prodtSize == prodtCompCnt){
				var formObj = fnNextStep();
			    controller.ajaxSend( {
					url : contextPath + '/contract/saveReceiptSetPlaceTv.json'
					, data : formObj
					, dataType : 'json'
					, type : 'post'
					, isBlock : true
					, isOverLap : true
					, successCall:function(result) {
						var retCode = result.retCode;
						var retMsg = result.retMsg;
						if (retCode == "SUCC") {
							$("#inp_nextCheck_dataInstallFlag").val("N");
						} else {
							/*
							 * 데이터 필수여부 확인
							 * */
							$("#inp_nextCheck_dataInstallReqData").val("NO");
							var prodtSize = Number(g_smartScrptCntrtInfoListLength);
					    	if(prodtSize > 0){
					    		for(var i = 0; i < prodtSize; i++){
					    			$("#slt_installTime_"+i+" option:eq(0)").prop("selected", true);
					    		}
					    	}
							
							updateSelectOrDie();
							/*
				        	 * 데이터 체크
				        	 * */
				        	data.nextCheckStep();
				        	/*
				        	 * 메시지 출력
				        	 * */
					    	fnReqValCheckMsgOutput(retMsg);
						}
					}
			    });
    		}
		    
		},
		//데이터등록 : 납부정보
		dataInsertPayInfo : function (){
			var formObj = fnNextStep();
		    controller.ajaxSend( {
				url : contextPath + '/contract/saveReceiptPaymentInfo.json'
				, data : formObj
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var retCode = result.retCode;
					var retMsg = result.retMsg;
					if (retCode == "SUCC") {
						$("#inp_nextCheck_dataPayFlag").val("N");
					} else {
						var tab = ui.tabOnCheck();
						/*
						 * 데이터 필수여부 확인
						 * */
						$("#inp_nextCheck_dataPayReqData").val("NO");
						/*
			        	 * 데이터 체크
			        	 * */
			        	data.nextCheckStep();
			        	
						/*if(tab.indexOf("payAuto") > -1){
							$("#slt_auto_bankCd option:eq(0)").prop("selected", true);
							$("#inp_auto_acctNo").val("");
							$("#inp_auto_depOwnNm").val("");
							$("#inp_auto_acctJuminBizNo").val("");
							fnDisbClass("#btn_auto_accNoAuth", true,"#btn_auto_accNoAuth","disabled", "");	
							
							$("#inp_inf_payAutoCertiTime").val("");
							$("#inp_inf_payAutoCertiResult").val("N");
							updateSelectOrDie();
							
				        	 * 데이터 체크
				        	 * 
				        	data.nextCheckStep();
						}else{
							if(tab.indexOf("payCard") > -1){
								$("#slt_card_cardComp option:eq(0)").prop("selected", true);
								$("#inp_card_cardNo1").val("");
								$("#inp_card_cardNo2").val("");
								$("#inp_card_cardNo3").val("");
								$("#inp_card_cardNo4").val("");
								
								$("#inp_card_cardYYYYMM").val("");
								$("#inp_card_cardNabbNm").val("");
								$("#inp_card_cardJuminBizNo").val("");
								
								fnDisbClass("#btn_card_cardAuth", true,"#btn_card_cardAuth","disabled", "");
								
								$("#inp_inf_payCardCertiTime").val("");
								$("#inp_inf_payCardCertiResult").val("N");
								updateSelectOrDie();
								
					        	 * 데이터 체크
					        	 * 
					        	data.nextCheckStep();
							}
						}*/
			        	/*
			        	 * 메시지 출력
			        	 * */
				    	fnReqValCheckMsgOutput(retMsg);
				    	
					}
				}
		    });
		    
		},nextCheckTabOpClose : function(){
			var tabArr = new Array();
			var index = 0;
			var prodtSize = Number(g_smartScrptCntrtInfoListLength);
			//tab_comp_custInfo
			//tab_comp_installInfo_0
			tabArr[index++] = "tab_comp_custInfo";
			for(var i=0;i < prodtSize;i++){
				tabArr[index++] = "tab_comp_installInfo_" + i;
			}
			tabArr[index++] = "tab_comp_payInfo";
			
			for(var i=0;i < tabArr.length;i++){
				var tabInfo = tabArr[i];
				if($("#" + tabInfo).attr("class").indexOf("completed") > -1){
					$("#" + tabInfo).removeClass("open");
				}
			}
			for(var i=0;i < tabArr.length;i++){
				var tabInfo = tabArr[i];
				if($("#" + tabInfo).attr("class").indexOf("completed") > -1){
				}else{
					$("#" + tabInfo).addClass("open");
					break;
				}
			}
		},nextCheckTabClick : function(type){
			//e.stopPropagation();
			//e.preventDefault();
			//e.cancelBubble = true;
			var tabArr = new Array();
			var tabCompArr = new Array();
			var index = 0;
			var prodtSize = Number(g_smartScrptCntrtInfoListLength);
			tabArr[index++] = "tab_comp_custInfo:"+($("#tab_comp_custInfo").attr("class").indexOf("completed") > -1 ? 'completed' : '');
			for(var i=0;i < prodtSize;i++){
				tabArr[index++] = "tab_comp_installInfo_"+i+":"+($("#tab_comp_installInfo_"+i).attr("class").indexOf("completed") > -1 ? 'completed' : '');
			}
			tabArr[index++] = "tab_comp_payInfo:"+($("#tab_comp_payInfo").attr("class").indexOf("completed") > -1 ? 'completed' : '');
			
			var tabSltIdx = 0;
			for(var i=0;i < tabArr.length;i++){
				var tabInfo = tabArr[i];
				//console.log("tabInfo > " + tabInfo);
				var tabInfoSplit = tabInfo.split(":");
				if(tabInfoSplit[0] == type){
					tabSltIdx = i;
					break;
				}
			}
			//console.log("tabSltIdx >> " + tabSltIdx);
			var tabClass = "completed";
			if(tabSltIdx > 0){
				/*
				 * 전
				 * */
				for(var i=0;i < tabSltIdx;i++){
					var tabInfo = tabArr[i];
					var tabInfoSplit = tabInfo.split(":");
					
					if(tabInfoSplit[1] == "completed"){
						tabClass = tabInfoSplit[1];
					}else{
						tabClass = "";
						break;
					}
				}
				
				if(tabClass == ""){
					//console.log("tabClass :: " + $("#" + type).attr("class").indexOf("open") + "<>" +type);
					if($("#" + type).attr("class").indexOf("completed") > -1){
						$("#" + type).addClass("open");
						//console.log("1");
					}else{
						$("#" + type).removeClass("open");
						//console.log("2");
					}
				}else{
					for(var i=0;i < tabSltIdx;i++){
						var tabInfo = tabArr[i];
						var tabInfoSplit = tabInfo.split(":");
						$("#" + tabInfoSplit[0]).removeClass("open");
					}
					
					//$("#" + type).addClass("open");
					if($("#" + type).attr("class").indexOf("open") > -1){
						$("#" + type).addClass("open");
					}else{
						$("#" + type).removeClass("open");
					}
				}
				/*
				 * 후
				 * */
				for(var i=tabSltIdx+1;i < tabArr.length;i++){
					var tabInfo = tabArr[i];
					var tabInfoSplit = tabInfo.split(":");
					$("#" + tabInfoSplit[0]).removeClass("open");
				}
				/*
				 * 선택된것
				 * 
				var tabSltBfInfo = tabArr[tabSltIdx-1];
				var tabSltBfInfoSplit = tabSltBfInfo.split(":");
				console.log("tabSltBfInfoSplit >> " + tabSltBfInfoSplit + "<>" + type + " :: " + $("#" + type).attr("class").indexOf("open"));
				if(tabSltBfInfoSplit[1] == "completed"){
					if($("#" + type).attr("class").indexOf("open") > -1){
						$("#" + type).addClass("open");
						console.log('11');
					}else{
						$("#" + type).removeClass("open");
						console.log('22');
					}
				}
				console.log("tabSltBfInfoSplit >> " + tabSltBfInfoSplit + "<>" + type + " :: " + $("#" + type).attr("class").indexOf("open"));*/
				/*
				 * 후
				 *
				for(var i=(tabSltIdx+1);i < tabSltIdx;i++){
					var tabInfo = tabArr[i];
					var tabInfoSplit = tabInfo.split(":");
					
					if(tabInfoSplit[1] == "completed"){
						tabClass = tabInfoSplit[1];
					}else{
						tabClass = "";
						break;
					}
				} */
			}else{
				//index 0 일경우
				for(var i=1;i < tabArr.length;i++){
					var tabInfo = tabArr[i];
					var tabInfoSplit = tabInfo.split(":");
					$("#" + tabInfoSplit[0]).removeClass("open");
				}
			}
			/*
			 * 스크롤
			 * */
			fnScrollTopMoveObj($("#"+type));
		
		},
		//데이터체크 : 가입고객정보
		nextCheckCustInfo : function (){
			var tab = ui.tabOnCheck();
			var dataFlag = false;
			//console.log("nextCheckCustInfo tab :: " + tab);
			if(tab.indexOf("gae") > -1){
				/*
				 * 개인 > 주민등록 체크
				 * */
				if($("#inp_gae_custNm").val() != ""
	        		&& $("#inp_gae_juminNo1").val() != ""
	        		&& $("#inp_gae_juminNo2").val() != ""){
	        		if( ($("#inp_gae_juminNo1").val().length >= $("#inp_gae_juminNo1").attr("maxlength"))
	        			&& ($("#inp_gae_juminNo2").val().length >= $("#inp_gae_juminNo2").attr("maxlength"))){
	        			dataFlag = true;
	        		}else{
	        			dataFlag = false;
	        		}
	        	}
				if(!dataFlag){
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				
				/*
				 * 개인 > 주민등록 키
				 * */
				if($("#inp_inf_certiKey").val() != ""){
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				/*
				 * 개인 > 신분증 사진
				 * */
				
				/*
				 * sms인증체크
				 * */
				if(g_smsAuthUseYN == "Y"){
					if($("#inp_inf_moAplnCertiKey").val() != "" && $("#inp_inf_moAplnCertiDh").val() != ""){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
				}
				
				/*
				 * 개인 > 핸드폰 번호
				 * */
				if($("#slt_gae_hpNo1").val() != "" 
					&& $("#inp_gae_hpNo2").val() != "" 
					&& $("#inp_gae_hpNo3").val() != "" 
					&& $("#inp_gae_hpNo2").val().length == $("#inp_gae_hpNo2").attr("maxlength")
					&& $("#inp_gae_hpNo3").val().length == $("#inp_gae_hpNo3").attr("maxlength")
					){
					$("#inp_gae_hpNo2").blur();
					$("#inp_gae_hpNo3").blur();
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				/*
				 * 개인 본인
				 * */
				if(tab.indexOf("reqMe") > -1){}
				/*
				 * 개인 가족
				 * */
				if(tab.indexOf("reqFa") > -1){
					//주민등록체크
					if($("#inp_gae_fa_custNm").val() != ""
		        		&& $("#inp_gae_fa_juminNo1").val() != ""
		        		&& $("#inp_gae_fa_juminNo2").val() != ""
		        		&& $("#inp_gae_fa_juminNo1").val().length >= $("#inp_gae_fa_juminNo1").attr("maxlength")	 
		        		&& $("#inp_gae_fa_juminNo2").val().length >= $("#inp_gae_fa_juminNo2").attr("maxlength") ) {
							dataFlag = true;
		        	}else{
		        		dataFlag = false;
		        	}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//주민등록 키
					if($("#inp_inf_certiKey2").val() != "" && $("#inp_inf_certiTime2").val() != "" && $("#btn_gae_fa_custOk").attr("disabled") == "disabled"){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//가족 서류 
					
					//대리인 연락처
					if($("#slt_gae_fa_hpNo1").val() != "" 
							&& $("#inp_gae_fa_hpNo2").val() != "" 
							&& $("#inp_gae_fa_hpNo3").val() != "" 
							&& $("#inp_gae_fa_hpNo2").val().length == $("#inp_gae_fa_hpNo2").attr("maxlength")
							&& $("#inp_gae_fa_hpNo3").val().length == $("#inp_gae_fa_hpNo3").attr("maxlength")
					){
						$("#inp_gae_fa_hpNo2").blur();
						$("#inp_gae_fa_hpNo3").blur();
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					//console.log("slt_gae_fa_hpNo1 >> " + dataFlag);
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					
				}
				/*
				 * 개인 법정대리인
				 * */
				if(tab.indexOf("reqDae") > -1){
					//주민등록체크
					if($("#inp_gae_dae_custNm").val() != ""
		        		&& $("#inp_gae_dae_juminNo1").val() != ""
		        		&& $("#inp_gae_dae_juminNo2").val() != ""
		        		&& $("#inp_gae_dae_juminNo1").val().length >= $("#inp_gae_dae_juminNo1").attr("maxlength")	
		        		&& $("#inp_gae_dae_juminNo2").val().length >= $("#inp_gae_dae_juminNo2").attr("maxlength")	
					){
						dataFlag = true;
		        	}else{
		        		dataFlag = false;
		        	}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//주민등록 키
					if($("#inp_inf_certiKey3").val() != "" && $("#inp_inf_certiTime3").val() != "" && $("#btn_gae_dae_custOk").attr("disabled") == "disabled"){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//대리인 서류 
					
					//대리인 연락처
					if($("#slt_gae_dae_hpNo1").val() != "" 
						&& $("#inp_gae_dae_hpNo2").val() != "" 
						&& $("#inp_gae_dae_hpNo3").val() != "" 
						&& $("#inp_gae_dae_hpNo2").val().length == $("#inp_gae_dae_hpNo2").attr("maxlength")
						&& $("#inp_gae_dae_hpNo3").val().length == $("#inp_gae_dae_hpNo3").attr("maxlength")
					){
						$("#inp_gae_dae_hpNo2").blur();
						$("#inp_gae_dae_hpNo3").blur();
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
				}
			}else if(tab.indexOf("saup") > -1){
				//사업자 > 고객명 사업자번호 대표자명 법인번호/주민번호
				if($("#inp_saup_custNm").val() != ""
	        		&& $("#inp_saup_compNum1").val() != ""
	        		&& $("#inp_saup_compNum2").val() != ""
	        		&& $("#inp_saup_compNum3").val() != ""
	        		&& $("#inp_saup_compNum1").val().length == $("#inp_saup_compNum1").attr("maxlength")	
	        		&& $("#inp_saup_compNum2").val().length == $("#inp_saup_compNum2").attr("maxlength")
	        		&& $("#inp_saup_compNum3").val().length == $("#inp_saup_compNum3").attr("maxlength")
	        		&& $("#inp_saup_ceoNm").val() != ""
	        		&& $("#inp_saup_corpNm").val() != ""
	        		&& $("#inp_saup_corpNm").val().length == $("#inp_saup_corpNm").attr("maxlength")
				){
					dataFlag = true;
	        	}else{
	        		dataFlag = false;
	        	}
				//console.log("inp_saup_custNm >> " + dataFlag);
				if(!dataFlag){
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				//주민등록 키
				if($("#inp_inf_certiKey").val() != "" && $("#inp_inf_certiTime").val() != ""){
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				//console.log("inp_inf_certiKey >> " + dataFlag);
				if(!dataFlag){
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				//사업자 > 핸드폰 번호
				if($("#slt_saup_hpNo1").val() != "" 
					&& $("#inp_saup_hpNo2").val() != "" 
					&& $("#inp_saup_hpNo3").val() != "" 
					&& $("#inp_saup_hpNo2").val().length == $("#inp_saup_hpNo2").attr("maxlength")
					&& $("#inp_saup_hpNo3").val().length == $("#inp_saup_hpNo3").attr("maxlength")
				){
					$("#inp_saup_hpNo2").blur();
					$("#inp_saup_hpNo3").blur();
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				
				//사업자 업종구분
				if($("#slt_saup_compType").val() != "" 
					&& $("#inp_saup_compBiz").val() != "" 
					&& $("#inp_saup_compInds").val() != "" 
				){
					//$("#inp_saup_compBiz").blur();
					//$("#inp_saup_compInds").blur();
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				/*
				 * sms인증체크
				 * */
				if(g_smsAuthUseYN == "Y"){
					if($("#inp_inf_moAplnCertiKey").val() != "" && $("#inp_inf_moAplnCertiDh").val() != ""){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
				}
				
				//사업자 > 대표자 탭
				if(tab.indexOf("reqMe") > -1){
					//주민등록체크
					if($("#inp_saup_ceoNm2").val() != ""
		        		&& $("#inp_saup_juminNo1").val() != ""
		        		&& $("#inp_saup_juminNo2").val() != ""
		        		&& $("#inp_saup_juminNo1").val().length == $("#inp_saup_juminNo1").attr("maxlength")	
		        		&& $("#inp_saup_juminNo2").val().length == $("#inp_saup_juminNo2").attr("maxlength")	
					){
						dataFlag = true;
		        	}else{
		        		dataFlag = false;
		        	}
					//console.log("inp_saup_ceoNm2 >> " + dataFlag);
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//주민등록 키
					if($("#inp_inf_certiKey2").val() != "" && $("#inp_inf_certiTime2").val() != ""){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					//console.log("inp_inf_certiKey2 >> " + dataFlag);
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//대표자 서류 
					
					//대표자 연락처
					if($("#slt_saup_ceoHpNo1").val() != "" 
						&& $("#inp_saup_ceoHpNo2").val() != "" 
						&& $("#inp_saup_ceoHpNo3").val() != "" 
						&& $("#inp_saup_ceoHpNo2").val().length == $("#inp_saup_ceoHpNo2").attr("maxlength")
						&& $("#inp_saup_ceoHpNo3").val().length == $("#inp_saup_ceoHpNo3").attr("maxlength")
					){
						$("#inp_saup_ceoHpNo2").blur();
						$("#inp_saup_ceoHpNo3").blur();
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					//console.log("slt_saup_ceoHpNo1 >> " + dataFlag);
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
				}
				//사업자 > 직원 탭
				else if(tab.indexOf("reqJig") > -1){
					//주민등록체크
					if($("#inp_saup_jig_ceoNm").val() != ""
		        		&& $("#inp_saup_jig_juminNo1").val() != ""
		        		&& $("#inp_saup_jig_juminNo2").val() != ""
		        		&& $("#inp_saup_jig_juminNo1").val().length == $("#inp_saup_jig_juminNo1").attr("maxlength")	
		        		&& $("#inp_saup_jig_juminNo2").val().length == $("#inp_saup_jig_juminNo2").attr("maxlength")	
					){
						dataFlag = true;
		        	}else{
		        		dataFlag = false;
		        	}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//주민등록 키
					if($("#inp_inf_certiKey3").val() != "" && $("#inp_inf_certiTime3").val() != ""){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//직원 서류 
					
					//직원 연락처
					if($("#slt_saup_jig_ceoHpNo1").val() != "" 
						&& $("#inp_saup_jig_ceoHpNo2").val() != "" 
						&& $("#inp_saup_jig_ceoHpNo3").val() != "" 
						&& $("#inp_saup_jig_ceoHpNo2").val().length == $("#inp_saup_jig_ceoHpNo2").attr("maxlength")
						&& $("#inp_saup_jig_ceoHpNo3").val().length == $("#inp_saup_jig_ceoHpNo3").attr("maxlength")
					){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_custInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
				}
				
			}
			
			/*
			 * 필수값완료시 버튼 해제
			 * */
			if(dataFlag){
				if($("#inp_nextCheck_dataCustReqData").val() == "OK"){
					$("#tab_comp_custInfo").addClass("completed");
					fnDisbClass("#btnNextStep", false, "#btnNextStep", "red", "disabled");
					return true;
				}else{
					$("#tab_comp_custInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				
			}else{
				$("#tab_comp_custInfo").removeClass("completed");
				fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
				return false;
			}
			
		},
		//데이터체크 : 설치정보
		nextCheckInstallInfo : function (){
			/*
			 * 설치정보 체크
			 * */
			var prodtSize = Number(g_smartScrptCntrtInfoListLength);
			var arrData = new Array();
	    	if(prodtSize > 0){
	    		for(var i = 0; i < prodtSize; i++){
	    			arrData[i] = i+":"+"OK";
	    			//console.log("iiiiiiii >> " + i);
	    			//console.log("inp_addr_ >> "+i+" <> " + $("#inp_addr_"+i).val());
	    			//console.log("inp_addr2_ >> "+i+" <> "  + $("#inp_addr2_"+i).val());
	    			//console.log("inp_addr3_ >> "+i+" <> "  + $("#inp_addr3_"+i).val());
	    			//console.log("inp_intHost_ >>"+i+" <> "  + $("#inp_intHost_"+i).val());
	    			//console.log("slt_installJum_ >> "+i+" <> "  + $("#slt_installJum_"+i).val());
	    			//console.log("inp_installDay_ >> " +i+" <> " + $("#inp_installDay_"+i).val());
	    			//console.log("slt_installTime_ >> " +i+" <> " + $("#slt_installTime_"+i).val());/**/
	    			
	    			if($("#inp_addr_"+i).val() == ""){
	    				arrData[i] = i+":"+"NO";
	    				continue;
	    			}
	    			if($("#inp_addr2_"+i).val() == ""){
	    				arrData[i] = i+":"+"NO";
	    				continue;
	    			}
	    			if($("#inp_addr3_"+i).val() == ""){
	    				arrData[i] = i+":"+"NO";
	    				continue;
	    			}
	    			if($("#inp_prdtTypeCd_"+i).val() == "02"){
	    				if($("#inp_intHost_"+i).val() == ""){
	    					//dataFlag = false;
	    					arrData[i] = i+":"+"NO";
	    					continue;
	    				}
	    			}
	    			if($("#slt_installJum_"+i).val() == MSG.DEFAULT_KEY || $("#slt_installJum_"+i).val() == ""){
	    				arrData[i] = i+":"+"NO";
	    				continue;
	    			}
	    			if($("#inp_installDay_"+i).val() == ""){
	    				arrData[i] = i+":"+"NO";
	    				continue;
	    			}
	    			if($("#slt_installTime_"+i).val() == MSG.DEFAULT_KEY  || $("#slt_installTime_"+i).val() == ""){
	    				arrData[i] = i+":"+"NO";
	    				continue;
	    			}
	    		}
	    		if(arrData.length > 0){
	    			for(key in arrData){
	    				//console.log("key >> "+key + " :: "+ arrData[key]);
	    				var arrDataSplit = arrData[key].split(":");
	    				if(arrDataSplit[0] == key){
	    					if(arrDataSplit[1] == "OK"){
	    						//console.log("arrDataSplit::"+arrDataSplit[1]);
	    						$("#tab_comp_installInfo_"+key).addClass("completed");
			    				fnDisbClass("#btnNextStep", false, "#btnNextStep", "red", "disabled");
	    					}else{
	    						//console.log("arrDataSplit22::"+arrDataSplit[1]);
	    						$("#tab_comp_installInfo_"+key).removeClass("completed");
			    				fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
	    					}
	    				}
		    		}
	    		}else{
	    			for(var i = 0; i < prodtSize; i++){
	    				$("#tab_comp_installInfo_"+i).addClass("completed");
	    				fnDisbClass("#btnNextStep", false, "#btnNextStep", "red", "disabled");
	    			}
	    		}
	    		
	    		return arrData;
	    		/*if(dataFlag){
    				$("#tab_comp_installInfo_"+i).addClass("completed");
    				fnDisbClass("#btnNextStep", false, "#btnNextStep", "red", "disabled");
    				//return true;
    			}else{
    				$("#tab_comp_installInfo_"+i).removeClass("completed");
    				fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
    				//return false;
    			}*/
	    		
	    	}
	    	
		},//데이터체크 : 납부정보
		nextCheckPayInfo : function (){
			/*
			 * 납부정보 체크
			 * */
			let tab = ui.tabOnCheck();
			let dataFlag = false;
			
			if(tab.indexOf("payAuto") > -1){ 
				/*
				 * 자동이체
				 * */
				if($("#slt_auto_bankCd").val() != "" 
					&& $("#inp_auto_acctNo").val() != ""
	        		&& $("#inp_auto_depOwnNm").val() != ""
	        		&& $("#inp_auto_acctJuminBizNo").val() != ""){
	        		if( $("#inp_auto_acctJuminBizNo").val().length == 6 || $("#inp_auto_acctJuminBizNo").val().length == 10  ){
	        			dataFlag = true;
	        		}else{
	        			dataFlag = false;
	        		}
	        	}else{
	        		dataFlag = false;
	        	}
				if(!dataFlag){
					$("#tab_comp_payInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				//계좌인증 키
				if($("#inp_inf_payAutoCertiTime").val() != "" && $("#inp_inf_payAutoCertiResult").val() == "Y"){
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_payInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				//요금납부자 동의 
				//if(!$("input:checkbox[id='chk_auto_agree']").is(":checked")){
				if($("#chk_auto_agree").is(":checked")){
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_payInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				/*
				 * 요금확인 이메일(자동이체)
				 */
				
				if(tab.indexOf("chkpEmail") > -1){ //이메일
					//이메일 주소
					if($("#inp_chkp_email").val() != "" && $("#inp_chkp_email2").val()!= ""){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//청구 주소
					if($('input:radio[name="rdo_chkp_invceAddr"]:checked').val() == "N"){
						if($("#inp_chkp_addr1").val() != "" && $("#inp_chkp_addr2").val() != "" && $("#inp_chkp_addr3").val() != ""){
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//현금영수증 발행신청-핸드폰번호
					if($('input:radio[name="rdo_chkp_cashReceiptYn"]:checked').val() == "0"){
						if($("#slt_chkp_cashHpNo").val() != "" 
							&& $("#inp_chkp_cashHpNo2").val() != "" 
							&& $("#inp_chkp_cashHpNo3").val() != ""
								&& $("#inp_chkp_cashHpNo2").val().length == $("#inp_chkp_cashHpNo2").attr("maxlength")
								&& $("#inp_chkp_cashHpNo3").val().length == $("#inp_chkp_cashHpNo3").attr("maxlength")
								){
							$("#inp_chkp_cashHpNo2").blur();
							$("#inp_chkp_cashHpNo3").blur();
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
				}else if(tab.indexOf("chkpMobile") > -1){//모바일
					//모바일 핸드포 번호
					if($("#slt_chkpAuto_mobile_hpNo1").val() != "" 
						&& $("#inp_chkpAuto_mobile_hpNo2").val() != "" 
						&& $("#inp_chkpAuto_mobile_hpNo3").val() != ""
							&& $("#inp_chkpAuto_mobile_hpNo2").val().length == $("#inp_chkpAuto_mobile_hpNo2").attr("maxlength")
							&& $("#inp_chkpAuto_mobile_hpNo3").val().length == $("#inp_chkpAuto_mobile_hpNo3").attr("maxlength") ){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//모바일 > 청구주소
					if($('input:radio[name="rdo_chkpAuto_mobile_invceAddr"]:checked').val() == "N"){
						if($("#inp_chkpAuto_mobile_addr1").val() != "" && $("#inp_chkpAuto_mobile_addr2").val() != "" && $("#inp_chkpAuto_mobile_addr3").val() != ""){
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//모바일 > 현금영수증
					if($('input:radio[name="rdo_chkpAuto_mobile_cashReceiptYn"]:checked').val() == "0"){
						if($("#slt_chkpAuto_mobile_cashHpNo1").val() != "" 
							&& $("#inp_chkpAuto_mobile_cashHpNo2").val() != "" 
							&& $("#inp_chkpAuto_mobile_cashHpNo3").val() != ""
								&& $("#inp_chkpAuto_mobile_cashHpNo2").val().length == $("#inp_chkpAuto_mobile_cashHpNo2").attr("maxlength")
								&& $("#inp_chkpAuto_mobile_cashHpNo3").val().length == $("#inp_chkpAuto_mobile_cashHpNo3").attr("maxlength")
								){
							$("#inp_chkpAuto_mobile_cashHpNo2").blur();
							$("#inp_chkpAuto_mobile_cashHpNo3").blur();
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
		    	}else if(tab.indexOf("chkpGoji") > -1){//고지서
		    		//고지서 > 청구주소
					if($('input:radio[name="rdo_chkpAuto_goji_invceAddr"]:checked').val() == "N"){
						if($("#inp_chkpAuto_goji_addr1").val() != "" && $("#inp_chkpAuto_goji_addr2").val() != "" && $("#inp_chkpAuto_goji_addr3").val() != ""){
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//고지서 > 현금영수증
					if($('input:radio[name="rdo_chkpAuto_goji_cashReceiptYn"]:checked').val() == "0"){
						if($("#slt_chkpAuto_goji_cashHpNo1").val() != "" 
							&& $("#inp_chkpAuto_goji_cashHpNo2").val() != "" 
								&& $("#inp_chkpAuto_goji_cashHpNo3").val() != ""
									&& $("#inp_chkpAuto_goji_cashHpNo2").val().length == $("#inp_chkpAuto_goji_cashHpNo2").attr("maxlength")
									&& $("#inp_chkpAuto_goji_cashHpNo3").val().length == $("#inp_chkpAuto_goji_cashHpNo3").attr("maxlength")
									){
							$("#inp_chkpAuto_goji_cashHpNo2").blur();
							$("#inp_chkpAuto_goji_cashHpNo3").blur();
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
		    	}
	    	}else if(tab.indexOf("payCard") > -1){
	    		/*
	    		 * 카드이체
	    		 * */
	    		if($("#slt_card_cardComp").val() != "" 
					&& $("#inp_card_cardNo1").val() != "" && $("#inp_card_cardNo2").val() != "" && $("#inp_card_cardNo3").val() != "" && $("#inp_card_cardNo4").val() != ""
	        		&& $("#inp_card_cardYYYYMM").val() != ""
	        		&& $("#inp_card_cardNabbNm").val() != ""
	        		&& $("#inp_card_cardJuminBizNo").val() != ""){
	    			
	    			if( $("#inp_card_cardNo1").val().length == 4 
	    					&& $("#inp_card_cardNo2").val().length == 4  
	    					&& $("#inp_card_cardNo3").val().length == 4
	    					&& $("#inp_card_cardNo4").val().length == 4
	    					&& $("#inp_card_cardYYYYMM").val().length == 6){
	    				dataFlag = true;
	    			}else{
	    				dataFlag = false;
	    			}
	    			if(dataFlag){
	    				if( $("#inp_card_cardYYYYMM").val().length == 6){
		    				dataFlag = true;
		    			}else{
		    				dataFlag = false;
		    			}
	    			}
	    			
	    			if(dataFlag){
	    				if( $("#inp_card_cardJuminBizNo").val().length == 6 || $("#inp_card_cardJuminBizNo").val().length == 10  ){
		        			dataFlag = true;
		        		}else{
		        			dataFlag = false;
		        		}
	    			}
	        	}else{
	        		dataFlag = false;
	        	}
	    		
	    		if(!dataFlag){
					$("#tab_comp_payInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
	    		
				//카드인증 키
				if($("#inp_inf_payCardCertiTime").val() != "" && $("#inp_inf_payCardCertiResult").val() == "Y"){
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_payInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				//카드납부자 동의 
				if($("#chk_card_agree").is(":checked")){
					dataFlag = true;
				}else{
					dataFlag = false;
				}
				if(!dataFlag){
					$("#tab_comp_payInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				/*
				 * 요금확인 이메일(카드)
				 * 
				*/
				if(tab.indexOf("chkpCardEmail") > -1){ //이메일
					//이메일 주소
					if($("#inp_chkpCard_email").val() != "" && $("#inp_chkpCard_email2").val()!= ""){
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//청구 주소
					if($('input:radio[name="rdo_chkpCard_invceAddr"]:checked').val() == "N"){
						if($("#inp_chkpCard_addr1").val() != "" && $("#inp_chkpCard_addr2").val() != "" && $("#inp_chkpCard_addr3").val() != ""){
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//현금영수증 발행신청-핸드폰번호
					if($('input:radio[name="rdo_chkpCard_cashReceiptYn"]:checked').val() == "0"){
						if($("#slt_chkpCard_cashHpNo").val() != "" 
							&& $("#inp_chkpCard_cashHpNo2").val() != "" 
								&& $("#inp_chkpCard_cashHpNo3").val() != ""
									&& $("#inp_chkpCard_cashHpNo2").val().length == $("#inp_chkpCard_cashHpNo2").attr("maxlength")
									&& $("#inp_chkpCard_cashHpNo3").val().length == $("#inp_chkpCard_cashHpNo3").attr("maxlength")			
						){
							$("#inp_chkpCard_cashHpNo2").blur();
							$("#inp_chkpCard_cashHpNo3").blur();
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					
				}else if(tab.indexOf("chkpCardMobile") > -1){//모바일
					//모바일 핸드포 번호
					if($("#slt_chkpCard_mobile_hpNo1").val() != "" 
						&& $("#inp_chkpCard_mobile_hpNo2").val() != "" 
						&& $("#inp_chkpCard_mobile_hpNo3").val() != ""
							&& $("#inp_chkpCard_mobile_hpNo2").val().length == $("#inp_chkpCard_mobile_hpNo2").attr("maxlength")
							&& $("#inp_chkpCard_mobile_hpNo3").val().length == $("#inp_chkpCard_mobile_hpNo3").attr("maxlength")
							){
						$("#inp_chkpCard_mobile_hpNo2").blur();
						$("#inp_chkpCard_mobile_hpNo3").blur();
						dataFlag = true;
					}else{
						dataFlag = false;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//모바일 > 청구주소
					if($('input:radio[name="rdo_chkpCard_mobile_invceAddr"]:checked').val() == "N"){
						if($("#inp_chkpCard_mobile_addr1").val() != "" && $("#inp_chkpCard_mobile_addr2").val() != "" && $("#inp_chkpCard_mobile_addr3").val() != ""){
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//모바일 > 현금영수증
					if($('input:radio[name="rdo_chkpCard_mobile_cashReceiptYn"]:checked').val() == "0"){
						if($("#slt_chkpCard_mobile_cashHpNo1").val() != "" 
							&& $("#inp_chkpCard_mobile_cashHpNo2").val() != "" 
								&& $("#inp_chkpCard_mobile_cashHpNo3").val() != ""
									&& $("#inp_chkpCard_mobile_cashHpNo2").val().length == $("#inp_chkpCard_mobile_cashHpNo2").attr("maxlength")
									&& $("#inp_chkpCard_mobile_cashHpNo3").val().length == $("#inp_chkpCard_mobile_cashHpNo3").attr("maxlength")			
						){
							$("#inp_chkpCard_mobile_cashHpNo2").blur();
							$("#inp_chkpCard_mobile_cashHpNo3").blur();
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
		    	}else if(tab.indexOf("chkpCardGoji") > -1){//고지서
		    		//고지서 > 청구주소
					if($('input:radio[name="rdo_chkpCard_goji_invceAddr"]:checked').val() == "N"){
						if($("#inp_chkpCard_goji_addr1").val() != "" && $("#inp_chkpCard_goji_addr2").val() != "" && $("#inp_chkpCard_goji_addr3").val() != ""){
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
					//고지서 > 현금영수증
					if($('input:radio[name="rdo_chkpCard_goji_cashReceiptYn"]:checked').val() == "0"){
						if($("#slt_chkpCard_goji_cashHpNo1").val() != "" 
							&& $("#inp_chkpCard_goji_cashHpNo2").val() != "" 
							&& $("#inp_chkpCard_goji_cashHpNo3").val() != ""
								&& $("#inp_chkpCard_goji_cashHpNo2").val().length == $("#inp_chkpCard_goji_cashHpNo2").attr("maxlength")
								&& $("#inp_chkpCard_goji_cashHpNo3").val().length == $("#inp_chkpCard_goji_cashHpNo3").attr("maxlength")					
						){
							$("#inp_chkpCard_goji_cashHpNo2").blur();
							$("#inp_chkpCard_goji_cashHpNo3").blur();
							dataFlag = true;
						}else{
							dataFlag = false;
						}
					}else{
						dataFlag = true;
					}
					if(!dataFlag){
						$("#tab_comp_payInfo").removeClass("completed");
						fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
						return false;
					}
		    	}
	    	}
			if(dataFlag){
				if($("#inp_nextCheck_dataPayReqData").val() == "OK"){
					$("#tab_comp_payInfo").addClass("completed");
					fnDisbClass("#btnNextStep", false, "#btnNextStep", "red", "disabled");
					return true;
				}else{
					$("#tab_comp_payInfo").removeClass("completed");
					fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
					return false;
				}
				
			}else{
				$("#tab_comp_payInfo").removeClass("completed");
				fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
				return false;
			}
			
		},
		nextCheckStep : function (){
			var dataCustFlag = false;
			var dataInstallFlag = false;
			var arrDataInstallFlag = false;
			var dataPayFlag = false;
			dataCustFlag = data.nextCheckCustInfo();
			arrDataInstallFlag = data.nextCheckInstallInfo();
			dataPayFlag = data.nextCheckPayInfo();
			
			/*
			 * 데이터 필수여부 확인
			 * */
			$("#inp_nextCheck_dataCustReqData").val("OK");
			$("#inp_nextCheck_dataPayReqData").val("OK");
			$("#inp_nextCheck_dataInstallReqData").val("OK");
			if(arrDataInstallFlag.length == 1){
				var arrDataSplit = arrDataInstallFlag[key].split(":");
				if(arrDataSplit[0] == key){
					if(arrDataSplit[1] == "OK"){
						dataInstallFlag = true;
					}else{
						dataInstallFlag = false;
					}
				}
			}else{
				for(key in arrDataInstallFlag){
					var arrDataSplit = arrDataInstallFlag[key].split(":");
					if(arrDataSplit[0] == key){
						if(arrDataSplit[1] == "OK"){
							dataInstallFlag = true;
						}else{
							dataInstallFlag = false;
						}
					}
				}
			}
			//data.nextCheckTabOpClose();
			if(dataCustFlag && dataInstallFlag && dataPayFlag){
				fnDisbClass("#btnNextStep", false, "#btnNextStep", "red", "disabled");
			}else{
				fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
			}
			
		},
		//데이터 체크 후 인서트 
		nextCheck : function (){
			/*
			 * 전체 데이터 체크
			 * */
			
			var tab = ui.tabOnCheck();
			var dataCustFlag = false;
			var arrDataInstallFlag = null;
			var dataInstallFlag = false;
			var dataPayFlag = false;
			
			/*
			 * 데이터 필수여부 확인
			 * */
			$("#inp_nextCheck_dataCustReqData").val("OK");
			$("#inp_nextCheck_dataPayReqData").val("OK");
			$("#inp_nextCheck_dataInstallReqData").val("OK");
			dataCustFlag = data.nextCheckCustInfo();
			arrDataInstallFlag = data.nextCheckInstallInfo();
			dataPayFlag = data.nextCheckPayInfo();
			
			//console.log("nextCheck dataCustFlag > " + dataCustFlag + "<>" + $("#inp_nextCheck_dataCustFlag").val());
			//console.log("nextCheck dataPayFlag > " + dataPayFlag + "<>" + $("#inp_nextCheck_dataPayFlag").val());
			
			if(dataCustFlag){
				if($("#inp_nextCheck_dataCustFlag").val() == "Y"){
					data.dataInsertCustInfo();
				}
			}
			if(arrDataInstallFlag.length == 1){
				var arrDataSplit = arrDataInstallFlag[key].split(":");
				if(arrDataSplit[0] == key){
					if(arrDataSplit[1] == "OK"){
						if($("#inp_nextCheck_dataInstallFlag").val() == "Y"){
							data.dataInsertInstallInfo();
						}
						dataInstallFlag = true;
					}else{
						dataInstallFlag = false;
					}
				}
			}else{
				for(key in arrDataInstallFlag){
					//console.log("nextCheckStep arrDataInstallFlag > " + arrDataInstallFlag[key]);
					var arrDataSplit = arrDataInstallFlag[key].split(":");
					if(arrDataSplit[0] == key){
						if(arrDataSplit[1] == "OK"){
							if(dataInstallFlag){
								if($("#inp_nextCheck_dataInstallFlag").val() == "Y"){
									data.dataInsertInstallInfo();
								}
							}
							dataInstallFlag = true;
						}else{
							dataInstallFlag = false;
							break;
						}
					}
				}
			}
			
			if(dataPayFlag){
				if($("#inp_nextCheck_dataPayFlag").val() == "Y"){
					data.dataInsertPayInfo();
				}
			}
			//data.nextCheckTabOpClose();
			if(dataCustFlag && dataInstallFlag && dataPayFlag){
				fnDisbClass("#btnNextStep", false, "#btnNextStep", "red", "disabled");
				return true;
			}else{
				fnDisbClass("#btnNextStep", true, "#btnNextStep", "disabled", "red");
				return false;
			}
			
		},setFlag : function (flag){
			g_flag = flag;
		},resetSmsData : function (dispSmsDivFlag, dispAuthNoFlag){
			/*$("#slt_sms_mblCmc option:eq(0)").prop("selected", true);
			if($("#inp_inf_mblTelNo").val() == ""){
				$("#slt_sms_hpNo1 option:eq(0)").prop("selected", true);
				$("#inp_sms_hpNo2").val("");
				$("#inp_sms_hpNo3").val("");
			}
			$('input[id="chk_sms_meAllTerms"]').prop('checked', false);
			$('input[name="chk_sms_meTerms"]').prop('checked', false);*/
			
			$("#inp_sms_authNo").val("");
			$("#labe_sms_authNoTime").html("(03:00)");
			$("#btn_sms_recvAuthNo>span").html("인증번호 받기");
			if(dispSmsDivFlag){
				$("#div_gae_smsAuth").show();
			}else{
				$("#div_gae_smsAuth").hide();
			}
			if(dispAuthNoFlag){
				$("#div_sms_authNoTime").show();
			}else{
				$("#div_sms_authNoTime").hide();
				
			}
			data.setSmsAuthNo("");
			updateSelectOrDie();
		},setSmsAuthNo : function (key){
			g_smsAuthNo = key;
		},setInvceDataInfo : function (sYN,objForm,tabGbn){
			if(sYN == "Y"){//설치주소와 동일
				 fn_addHidden(objForm, "invceZipCd", $("#inp_addr_0").val()); 	//invceZipCd	청구처우편번호
		   		 fn_addHidden(objForm, "invceAddr", $("#inp_addr2_0").val() ); 	//invceAddr	청구처주소
		   		 fn_addHidden(objForm, "invceSuppAddr", $("#inp_addr3_0").val() ); //invceSuppAddr	청구처보조주소
		   		 fn_addHidden(objForm, "invceAddrSeltnTypeCd", $("#inp_addrSeltnTypeCd_0").val());  //invceAddrSeltnTypeCd	주소선택구분코드 CM380
		   		 fn_addHidden(objForm, "invceRefMastAddr", $("#inp_refMastAddr_0").val() ); //invceRefMastAddr	참조기본주소
		   		 fn_addHidden(objForm, "invceRefSuppAddr", $("#inp_refSuppAddr_0").val() ); //invceRefSuppAddr	참조보조주소
		   		 fn_addHidden(objForm, "invceRdNmVrfCd", $("#inp_addr_rdNmVrfCd_0").val() ); //invceRdNmVrfCd	도로명검증코드 CM381
		   		 fn_addHidden(objForm, "invceKtDongCd", $("#inp_addr_ktDongCd_0").val() );  //invceKtDongCd	kt동코드
		   		 fn_addHidden(objForm, "invceAddrBunjiCl", $("#inp_addr_addrBunjiCl_0").val() ); //invceAddrBunjiCl	주소번지유형
		   		 fn_addHidden(objForm, "invceAddrBunji", $("#inp_addr_addrBunji_0").val() ); //invceAddrBunji	주소번지
		   		 fn_addHidden(objForm, "invceAddrHo", $("#inp_addr_addrHo_0").val() ); //invceAddrHo	주소호
		   		 fn_addHidden(objForm, "invceRefAddr", $("#inp_refMastAddr_0").val() ); //invceRefAddr	참조주소
		   		 fn_addHidden(objForm, "invceKtBldId", fn_nvl($("#inp_addr_ktBldId_0").val(),"dummy")); //invceKtBldId	kt건물아이디
		   		 fn_addHidden(objForm, "invceKtRdNmId", fn_nvl($("#inp_addr_ktRdNmId_0").val(),"dummy")); //invceKtRdNmId	kt도로명아이디
		   		//청구정보
		   		 fn_addHidden(objForm, "invceAptCd", "dummy" ); //invceAptCd 아파트코드
		   		 fn_addHidden(objForm, "invceAptDong", "dummy" ); //invceAptDong	아파트동
		   		 fn_addHidden(objForm, "invceAptHo", "dummy" );  //invceAptHo	아파트호
		   		 fn_addHidden(objForm, "invceBldMgmtNo", "dummy" );  //invceBldMgmtNo	건물관리번호
			}else{//설치주소와 다름
				 let invceZipCd, invceAddr, invceSuppAddr, invceAddrSeltnTypeCd, invceRefMastAddr, invceRefSuppAddr, invceRdNmVrfCd;
				 let invceKtDongCd, invceAddrBunjiCl, invceAddrBunji, invceAddrHo, invceRefAddr, invceKtBldId, invceKtRdNmId, invceAptCd, invceAptDong, invceAptHo, invceBldMgmtNo;
				 
				 if(tabGbn == "chkpEmail"){
					 invceZipCd = $("#inp_chkp_addr1").val();
					 invceAddr = $("#inp_chkp_addr2").val();
					 invceSuppAddr = $("#inp_chkp_addr3").val();
					 invceAddrSeltnTypeCd = $("#inp_chkpAuto_email_invceAddrSeltnTypeCd").val();
					 invceRefMastAddr = $("#inp_chkpAuto_email_invceRefMastAddr").val();
					 invceRefSuppAddr = $("#inp_chkpAuto_email_invceRefSuppAddr").val();
					 invceRdNmVrfCd = $("#inp_chkpAuto_email_invceRdNmVrfCd").val();
					 invceKtDongCd = $("#inp_chkpAuto_email_invceKtDongCd").val();
					 invceAddrBunjiCl = $("#inp_chkpAuto_email_invceAddrBunjiCl").val();
					 invceAddrBunji = $("#inp_chkpAuto_email_invceAddrBunji").val();
					 invceAddrHo = $("#inp_chkpAuto_email_invceAddrHo").val();
					 invceRefAddr = $("#inp_chkpAuto_email_invceRefAddr").val();
					 invceKtBldId = $("#inp_chkpAuto_email_invceKtBldId").val();
					 invceKtRdNmId = $("#inp_chkpAuto_email_invceKtRdNmId").val();
				 }else if(tabGbn == "chkpMobile"){
					 invceZipCd = $("#inp_chkpAuto_mobile_addr1").val();
					 invceAddr = $("#inp_chkpAuto_mobile_addr2").val();
					 invceSuppAddr = $("#inp_chkpAuto_mobile_addr3").val();
					 invceAddrSeltnTypeCd = $("#inp_chkpAuto_mobile_invceAddrSeltnTypeCd").val();
					 invceRefMastAddr = $("#inp_chkpAuto_mobile_invceRefMastAddr").val();
					 invceRefSuppAddr = $("#inp_chkpAuto_mobile_invceRefSuppAddr").val();
					 invceRdNmVrfCd = $("#inp_chkpAuto_mobile_invceRdNmVrfCd").val();
					 invceKtDongCd = $("#inp_chkpAuto_mobile_invceKtDongCd").val();
					 invceAddrBunjiCl = $("#inp_chkpAuto_mobile_invceAddrBunjiCl").val();
					 invceAddrBunji = $("#inp_chkpAuto_mobile_invceAddrBunji").val();
					 invceAddrHo = $("#inp_chkpAuto_mobile_invceAddrHo").val();
					 invceRefAddr = $("#inp_chkpAuto_mobile_invceRefAddr").val();
					 invceKtBldId = $("#inp_chkpAuto_mobile_invceKtBldId").val();
					 invceKtRdNmId = $("#inp_chkpAuto_mobile_invceKtRdNmId").val();
				 }else if(tabGbn == "chkpGoji"){
					 invceZipCd = $("#inp_chkpAuto_goji_addr1").val();
					 invceAddr = $("#inp_chkpAuto_goji_addr2").val();
					 invceSuppAddr = $("#inp_chkpAuto_goji_addr3").val();
					 invceAddrSeltnTypeCd = $("#inp_chkpAuto_goji_invceAddrSeltnTypeCd").val();
					 invceRefMastAddr = $("#inp_chkpAuto_goji_invceRefMastAddr").val();
					 invceRefSuppAddr = $("#inp_chkpAuto_goji_invceRefSuppAddr").val();
					 invceRdNmVrfCd = $("#inp_chkpAuto_goji_invceRdNmVrfCd").val();
					 invceKtDongCd = $("#inp_chkpAuto_goji_invceKtDongCd").val();
					 invceAddrBunjiCl = $("#inp_chkpAuto_goji_invceAddrBunjiCl").val();
					 invceAddrBunji = $("#inp_chkpAuto_goji_invceAddrBunji").val();
					 invceAddrHo = $("#inp_chkpAuto_goji_invceAddrHo").val();
					 invceRefAddr = $("#inp_chkpAuto_goji_invceRefAddr").val();
					 invceKtBldId = $("#inp_chkpAuto_goji_invceKtBldId").val();
					 invceKtRdNmId = $("#inp_chkpAuto_goji_invceKtRdNmId").val();
				 }else if(tabGbn == "chkpCardEmail"){
					 invceZipCd = $("#inp_chkpCard_addr1").val();
					 invceAddr = $("#inp_chkpCard_addr2").val();
					 invceSuppAddr = $("#inp_chkpCard_addr3").val();
					 invceAddrSeltnTypeCd = $("#inp_chkpCard_email_invceAddrSeltnTypeCd").val();
					 invceRefMastAddr = $("#inp_chkpCard_email_invceRefMastAddr").val();
					 invceRefSuppAddr = $("#inp_chkpCard_email_invceRefSuppAddr").val();
					 invceRdNmVrfCd = $("#inp_chkpCard_email_invceRdNmVrfCd").val();
					 invceKtDongCd = $("#inp_chkpCard_email_invceKtDongCd").val();
					 invceAddrBunjiCl = $("#inp_chkpCard_email_invceAddrBunjiCl").val();
					 invceAddrBunji = $("#inp_chkpCard_email_invceAddrBunji").val();
					 invceAddrHo = $("#inp_chkpCard_email_invceAddrHo").val();
					 invceRefAddr = $("#inp_chkpCard_email_invceRefAddr").val();
					 invceKtBldId = $("#inp_chkpCard_email_invceKtBldId").val();
					 invceKtRdNmId = $("#inp_chkpCard_email_invceKtRdNmId").val();
				 }else if(tabGbn == "chkpCardMobile"){
					 invceZipCd = $("#inp_chkpCard_mobile_addr1").val();
					 invceAddr = $("#inp_chkpCard_mobile_addr2").val();
					 invceSuppAddr = $("#inp_chkpCard_mobile_addr3").val();
					 invceAddrSeltnTypeCd = $("#inp_chkpCard_mobile_invceAddrSeltnTypeCd").val();
					 invceRefMastAddr = $("#inp_chkpCard_mobile_invceRefMastAddr").val();
					 invceRefSuppAddr = $("#inp_chkpCard_mobile_invceRefSuppAddr").val();
					 invceRdNmVrfCd = $("#inp_chkpCard_mobile_invceRdNmVrfCd").val();
					 invceKtDongCd = $("#inp_chkpCard_mobile_invceKtDongCd").val();
					 invceAddrBunjiCl = $("#inp_chkpCard_mobile_invceAddrBunjiCl").val();
					 invceAddrBunji = $("#inp_chkpCard_mobile_invceAddrBunji").val();
					 invceAddrHo = $("#inp_chkpCard_mobile_invceAddrHo").val();
					 invceRefAddr = $("#inp_chkpCard_mobile_invceRefAddr").val();
					 invceKtBldId = $("#inp_chkpCard_mobile_invceKtBldId").val();
					 invceKtRdNmId = $("#inp_chkpCard_mobile_invceKtRdNmId").val();
				 }else if(tabGbn == "chkpCardGoji"){
					 invceZipCd = $("#inp_chkpCard_goji_addr1").val();
					 invceAddr = $("#inp_chkpCard_goji_addr2").val();
					 invceSuppAddr = $("#inp_chkpCard_goji_addr3").val();
					 invceAddrSeltnTypeCd = $("#inp_chkpCard_goji_invceAddrSeltnTypeCd").val();
					 invceRefMastAddr = $("#inp_chkpCard_goji_invceRefMastAddr").val();
					 invceRefSuppAddr = $("#inp_chkpCard_goji_invceRefSuppAddr").val();
					 invceRdNmVrfCd = $("#inp_chkpCard_goji_invceRdNmVrfCd").val();
					 invceKtDongCd = $("#inp_chkpCard_goji_invceKtDongCd").val();
					 invceAddrBunjiCl = $("#inp_chkpCard_goji_invceAddrBunjiCl").val();
					 invceAddrBunji = $("#inp_chkpCard_goji_invceAddrBunji").val();
					 invceAddrHo = $("#inp_chkpCard_goji_invceAddrHo").val();
					 invceRefAddr = $("#inp_chkpCard_goji_invceRefAddr").val();
					 invceKtBldId = $("#inp_chkpCard_goji_invceKtBldId").val();
					 invceKtRdNmId = $("#inp_chkpCard_goji_invceKtRdNmId").val();
				 }
				 fn_addHidden(objForm, "invceZipCd", invceZipCd); 	//청구처우편번호
		   		 fn_addHidden(objForm, "invceAddr", invceAddr); 	//	청구처주소
		   		 fn_addHidden(objForm, "invceSuppAddr", invceSuppAddr); //	청구처보조주소
		   		 fn_addHidden(objForm, "invceAddrSeltnTypeCd", invceAddrSeltnTypeCd);  //주소선택구분코드 CM380
		   		 fn_addHidden(objForm, "invceRefMastAddr", invceRefMastAddr); //참조기본주소
		   		 fn_addHidden(objForm, "invceRefSuppAddr", invceRefSuppAddr); //참조보조주소
		   		 fn_addHidden(objForm, "invceRdNmVrfCd", invceRdNmVrfCd); //도로명검증코드 CM381
		   		 fn_addHidden(objForm, "invceKtDongCd", invceKtDongCd);  //kt동코드
		   		 fn_addHidden(objForm, "invceAddrBunjiCl", invceAddrBunjiCl); //주소번지유형
		   		 fn_addHidden(objForm, "invceAddrBunji", invceAddrBunji); //주소번지
		   		 fn_addHidden(objForm, "invceAddrHo", invceAddrHo); //주소호
		   		 fn_addHidden(objForm, "invceRefAddr", invceRefAddr); //참조주소
		   		 fn_addHidden(objForm, "invceKtBldId", invceKtBldId); //kt건물아이디
		   		 fn_addHidden(objForm, "invceKtRdNmId", invceKtRdNmId); //kt도로명아이디
		   		//청구정보
		   		 fn_addHidden(objForm, "invceAptCd", "dummy" ); // 아파트코드
		   		 fn_addHidden(objForm, "invceAptDong", "dummy" ); //아파트동
		   		 fn_addHidden(objForm, "invceAptHo", "dummy" );  //아파트호
		   		 fn_addHidden(objForm, "invceBldMgmtNo", "dummy" );  //건물관리번호
			}
			 
		},setInvceZipAddrDataInfo : function (paramObj, tabGbn){
			if(tabGbn == "chkpEmail"){
				$("#inp_chkp_addr1").val(paramObj.instalPlceZipCd);
				if(paramObj.searchGubun == "J"){
					$("#inp_chkp_addr2").val(paramObj.jibunAddr);
					$("#inp_chkp_addr3").val(paramObj.jibunSuppAddr);
					$("#inp_chkpAuto_email_invceAddrSeltnTypeCd").val("3");
					$("#inp_chkpAuto_email_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpAuto_email_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}else{
					$("#inp_chkp_addr2").val(paramObj.rdNmAddr);
					$("#inp_chkp_addr3").val(paramObj.rdNmSuppAddr);
					$("#inp_chkpAuto_email_invceAddrSeltnTypeCd").val("4");
					$("#inp_chkpAuto_email_invceRefMastAddr").val(paramObj.jibunAddr);
					$("#inp_chkpAuto_email_invceRefSuppAddr").val(paramObj.jibunSuppAddr);
				}
				$("#inp_chkpAuto_email_invceRdNmVrfCd").val(paramObj.rdNmVrfCd);
				$("#inp_chkpAuto_email_invceKtDongCd").val(paramObj.ktDongCd);
				$("#inp_chkpAuto_email_invceAddrBunjiCl").val(paramObj.addrBunjiCl);
				$("#inp_chkpAuto_email_invceAddrBunji").val(paramObj.addrBunji);
				$("#inp_chkpAuto_email_invceAddrHo").val(paramObj.addrHo);
				
				let invceRefAddr = $("#inp_chkpAuto_email_invceRefMastAddr").val()+" "+$("#inp_chkpAuto_email_invceRefSuppAddr").val();
				$("#inp_chkpAuto_email_invceRefAddr").val(invceRefAddr);
				$("#inp_chkpAuto_email_invceKtBldId").val(fn_nvl(paramObj.ktBldId,"dummy"));
				$("#inp_chkpAuto_email_invceKtRdNmId").val(fn_nvl(paramObj.ktRdNmId,"dummy"));
			}else if(tabGbn == "chkpMobile"){
				$("#inp_chkpAuto_mobile_addr1").val(paramObj.instalPlceZipCd);
				if(paramObj.searchGubun == "J"){
					$("#inp_chkpAuto_mobile_addr2").val(paramObj.jibunAddr);
					$("#inp_chkpAuto_mobile_addr3").val(paramObj.jibunSuppAddr);
					$("#inp_chkpAuto_mobile_invceAddrSeltnTypeCd").val("3");
					$("#inp_chkpAuto_mobile_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpAuto_mobile_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}else{
					$("#inp_chkpAuto_mobile_addr2").val(paramObj.rdNmAddr);
					$("#inp_chkpAuto_mobile_addr3").val(paramObj.rdNmSuppAddr);
					$("#inp_chkpAuto_mobile_invceAddrSeltnTypeCd").val("4");
					$("#inp_chkpAuto_mobile_invceRefMastAddr").val(paramObj.jibunAddr);
					$("#inp_chkpAuto_mobile_invceRefSuppAddr").val(paramObj.jibunSuppAddr);
				}
				$("#inp_chkpAuto_mobile_invceRdNmVrfCd").val(paramObj.rdNmVrfCd);
				$("#inp_chkpAuto_mobile_invceKtDongCd").val(paramObj.ktDongCd);
				$("#inp_chkpAuto_mobile_invceAddrBunjiCl").val(paramObj.addrBunjiCl);
				$("#inp_chkpAuto_mobile_invceAddrBunji").val(paramObj.addrBunji);
				$("#inp_chkpAuto_mobile_invceAddrHo").val(paramObj.addrHo);
				
				let invceRefAddr = $("#inp_chkpAuto_mobile_invceRefMastAddr").val()+" "+$("#inp_chkpAuto_mobile_invceRefSuppAddr").val();
				$("#inp_chkpAuto_mobile_invceRefAddr").val(invceRefAddr);
				$("#inp_chkpAuto_mobile_invceKtBldId").val(fn_nvl(paramObj.ktBldId,"dummy"));
				$("#inp_chkpAuto_mobile_invceKtRdNmId").val(fn_nvl(paramObj.ktRdNmId,"dummy"));
			}else if(tabGbn == "chkpGoji"){
				$("#inp_chkpAuto_goji_addr1").val(paramObj.instalPlceZipCd);
				if(paramObj.searchGubun == "J"){
					$("#inp_chkpAuto_goji_addr2").val(paramObj.jibunAddr);
					$("#inp_chkpAuto_goji_addr3").val(paramObj.jibunSuppAddr);
					$("#inp_chkpAuto_goji_invceAddrSeltnTypeCd").val("3");
					$("#inp_chkpAuto_goji_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpAuto_goji_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}else{
					$("#inp_chkpAuto_goji_addr2").val(paramObj.rdNmAddr);
					$("#inp_chkpAuto_goji_addr3").val(paramObj.rdNmSuppAddr);
					$("#inp_chkpAuto_goji_invceAddrSeltnTypeCd").val("4");
					$("#inp_chkpAuto_goji_invceRefMastAddr").val(paramObj.jibunAddr);
					$("#inp_chkpAuto_goji_invceRefSuppAddr").val(paramObj.jibunSuppAddr);
				}
				$("#inp_chkpAuto_goji_invceRdNmVrfCd").val(paramObj.rdNmVrfCd);
				$("#inp_chkpAuto_goji_invceKtDongCd").val(paramObj.ktDongCd);
				$("#inp_chkpAuto_goji_invceAddrBunjiCl").val(paramObj.addrBunjiCl);
				$("#inp_chkpAuto_goji_invceAddrBunji").val(paramObj.addrBunji);
				$("#inp_chkpAuto_goji_invceAddrHo").val(paramObj.addrHo);
				
				let invceRefAddr = $("#inp_chkpAuto_goji_invceRefMastAddr").val()+" "+$("#inp_chkpAuto_goji_invceRefSuppAddr").val();
				$("#inp_chkpAuto_goji_invceRefAddr").val(invceRefAddr);
				$("#inp_chkpAuto_goji_invceKtBldId").val(fn_nvl(paramObj.ktBldId,"dummy"));
				$("#inp_chkpAuto_goji_invceKtRdNmId").val(fn_nvl(paramObj.ktRdNmId,"dummy"));
			}else if(tabGbn == "chkpCardEmail"){
				$("#inp_chkpCard_addr1").val(paramObj.instalPlceZipCd);
				if(paramObj.searchGubun == "J"){
					$("#inp_chkpCard_addr2").val(paramObj.jibunAddr);
					$("#inp_chkpCard_addr3").val(paramObj.jibunSuppAddr);
					$("#inp_chkpCard_email_invceAddrSeltnTypeCd").val("3");
					$("#inp_chkpCard_email_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_email_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}else{
					$("#inp_chkpCard_addr2").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_addr3").val(paramObj.rdNmSuppAddr);
					$("#inp_chkpCard_email_invceAddrSeltnTypeCd").val("4");
					$("#inp_chkpCard_email_invceRefMastAddr").val(paramObj.jibunAddr);
					$("#inp_chkpCard_email_invceRefSuppAddr").val(paramObj.jibunSuppAddr);
				}
				$("#inp_chkpCard_email_invceRdNmVrfCd").val(paramObj.rdNmVrfCd);
				$("#inp_chkpCard_email_invceKtDongCd").val(paramObj.ktDongCd);
				$("#inp_chkpCard_email_invceAddrBunjiCl").val(paramObj.addrBunjiCl);
				$("#inp_chkpCard_email_invceAddrBunji").val(paramObj.addrBunji);
				$("#inp_chkpCard_email_invceAddrHo").val(paramObj.addrHo);
				
				let invceRefAddr = $("#inp_chkpCard_email_invceRefMastAddr").val()+" "+$("#inp_chkpCard_email_invceRefSuppAddr").val();
				$("#inp_chkpCard_email_invceRefAddr").val(invceRefAddr);
				$("#inp_chkpCard_email_invceKtBldId").val(fn_nvl(paramObj.ktBldId,"dummy"));
				$("#inp_chkpCard_email_invceKtRdNmId").val(fn_nvl(paramObj.ktRdNmId,"dummy"));
			}else if(tabGbn == "chkpCardMobile"){
				$("#inp_chkpCard_mobile_addr1").val(paramObj.instalPlceZipCd);
				if(paramObj.searchGubun == "J"){
					$("#inp_chkpCard_mobile_addr2").val(paramObj.jibunAddr);
					$("#inp_chkpCard_mobile_addr3").val(paramObj.jibunSuppAddr);
					$("#inp_chkpCard_mobile_invceAddrSeltnTypeCd").val("3");
					$("#inp_chkpCard_mobile_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_mobile_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}else{
					$("#inp_chkpCard_mobile_addr2").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_mobile_addr3").val(paramObj.rdNmSuppAddr);
					$("#inp_chkpCard_mobile_invceAddrSeltnTypeCd").val("4");
					$("#inp_chkpCard_mobile_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_mobile_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}
				$("#inp_chkpCard_mobile_invceRdNmVrfCd").val(paramObj.rdNmVrfCd);
				$("#inp_chkpCard_mobile_invceKtDongCd").val(paramObj.ktDongCd);
				$("#inp_chkpCard_mobile_invceAddrBunjiCl").val(paramObj.addrBunjiCl);
				$("#inp_chkpCard_mobile_invceAddrBunji").val(paramObj.addrBunji);
				$("#inp_chkpCard_mobile_invceAddrHo").val(paramObj.addrHo);
				
				let invceRefAddr = $("#inp_chkpCard_mobile_invceRefMastAddr").val()+" "+$("#inp_chkpCard_mobile_invceRefSuppAddr").val();
				$("#inp_chkpCard_mobile_invceRefAddr").val(invceRefAddr);
				$("#inp_chkpCard_mobile_invceKtBldId").val(fn_nvl(paramObj.ktBldId,"dummy"));
				$("#inp_chkpCard_mobile_invceKtRdNmId").val(fn_nvl(paramObj.ktRdNmId,"dummy"));
				
			}else if(tabGbn == "chkpCardGoji"){
				$("#inp_chkpCard_goji_addr1").val(paramObj.instalPlceZipCd);
				if(paramObj.searchGubun == "J"){
					$("#inp_chkpCard_goji_addr2").val(paramObj.jibunAddr);
					$("#inp_chkpCard_goji_addr3").val(paramObj.jibunSuppAddr);
					$("#inp_chkpCard_goji_invceAddrSeltnTypeCd").val("3");
					$("#inp_chkpCard_goji_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_goji_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}else{
					$("#inp_chkpCard_goji_addr2").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_goji_addr3").val(paramObj.rdNmSuppAddr);
					$("#inp_chkpCard_goji_invceAddrSeltnTypeCd").val("4");
					$("#inp_chkpCard_goji_invceRefMastAddr").val(paramObj.rdNmAddr);
					$("#inp_chkpCard_goji_invceRefSuppAddr").val(paramObj.rdNmSuppAddr);
				}
				$("#inp_chkpCard_goji_invceRdNmVrfCd").val(paramObj.rdNmVrfCd);
				$("#inp_chkpCard_goji_invceKtDongCd").val(paramObj.ktDongCd);
				$("#inp_chkpCard_goji_invceAddrBunjiCl").val(paramObj.addrBunjiCl);
				$("#inp_chkpCard_goji_invceAddrBunji").val(paramObj.addrBunji);
				$("#inp_chkpCard_goji_invceAddrHo").val(paramObj.addrHo);
				
				let invceRefAddr = $("#inp_chkpCard_goji_invceRefMastAddr").val()+" "+$("#inp_chkpCard_goji_invceRefSuppAddr").val();
				$("#inp_chkpCard_goji_invceRefAddr").val(invceRefAddr);
				$("#inp_chkpCard_goji_invceKtBldId").val(fn_nvl(paramObj.ktBldId,"dummy"));
				$("#inp_chkpCard_goji_invceKtRdNmId").val(fn_nvl(paramObj.ktRdNmId,"dummy"));
			}
			data.nextCheck();
		}, juminDataCheck : function (jumin1, jumin2){
			/*
			 * 주민번호 형식체크
			 **/ 
			/**/if(!fn_isJuminByVal(jumin1, jumin2)){
				return MSG.CHK_JUMIN_ERROR;
			}
			var resultJumin = "";
			/*
			 * 내외국인체크
			 * */
			var juminNation = fnCmmJuminNation(jumin1, jumin2);
			if(juminNation == "2"){
				resultJumin = resultJumin + MSG.CHK_NATION_FO;
			}else{
				resultJumin = resultJumin + MSG.CHK_NATION_KO;
				/*
				 * 내국인 미성년체크
				 * */
				if(fn_isAdultByValue(jumin1, jumin2)){
					//미성년
					resultJumin = resultJumin+"_"+MSG.CHK_ADULT_NO;
					
				}else{
					//성인
					resultJumin = resultJumin+"_"+MSG.CHK_ADULT_OK;
				}
			}
			/*
			 * 남녀구분
			 * */
			var gender = fn_setBirthSexFromJumin(jumin1, jumin2);
			if(gender == 0){
				resultJumin =  resultJumin+"_"+MSG.CHK_SEX_M;
			}else{
				resultJumin =  resultJumin+"_"+MSG.CHK_SEX_W;
			}
			
			return resultJumin;
		}
	}

var ui = {
	init : function(){
		//console.log("ui.init");
		//sms display 컨트럴
		
		if(g_smsAuthUseYN == "Y"){
			if($("#inp_custTypeCd").val() == "1" || $("#inp_custTypeCd").val() == "2"){
				if($("#inp_inf_certiKey").val() == "" && $("#inp_inf_certiTime").val() == ""){
					data.resetSmsData(true,false);
				}else{
					
				}
			}else{
				if($$("#inp_inf_certiKey").val() == ""){
					
				}else{
					$("#div_saup_mobile").show();
					var smsbox = $('#div_gae_smsAuth');
					var smsOKbox = $('#div_sms_authOK');
					
					$("#div_saup_smsAuthHome").append(smsbox);
					$("#div_saup_smsAuthHome").append(smsOKbox);	
					
					if($("#inp_inf_moAplnCertiKey").val() != "" && $("#inp_inf_moAplnCertiDh").val() != ""){
						data.resetSmsData(false,false);
					}else{
						data.resetSmsData(true,false);
					}
				}
			}
			/*if($("#inp_custTypeCd").val() != "1" && $("#inp_inf_certiKey").val() != ""){
				$("#div_saup_mobile").show();
				var smsbox = $('#div_gae_smsAuth');
				var smsOKbox = $('#div_sms_authOK');
				$("#div_saup_smsAuthHome").append(smsbox);
				$("#div_saup_smsAuthHome").append(smsOKbox);	
				if($("#inp_inf_moAplnCertiKey").val() != "" && $("#inp_inf_moAplnCertiDh").val() != ""){
					data.resetSmsData(false,false);
				}else{
					data.resetSmsData(true,false);
				}
			}else{
				console.log("data.init nono--------------------------------");
				
			}*/
		}
		ui.tabReqTypeGubun();
	},
	//신청자별 탭구분
	tabReqTypeGubun : function(){
		var juminBizNo = $("#inp_juminBizNo").val();
		var tab = ui.tabOnCheck();
		if(tab.indexOf("gae") > -1){
			if(fn_nvl(juminBizNo,"") == ""){
				juminBizNo = $("#inp_gae_juminNo1").val() +""+ $("#inp_gae_juminNo2").val();
			}
		}else{
			if(tab.indexOf("saup") > -1){
				if(tab.indexOf("reqMe") > -1){
					juminBizNo = $("#inp_saup_juminNo1").val() +""+ $("#inp_saup_juminNo2").val();
				}else if(tab.indexOf("reqJig") > -1){
					juminBizNo = $("#inp_saup_jig_juminNo1").val() +""+ $("#inp_saup_jig_juminNo2").val();
				}
			}
		}
		if(juminBizNo.length == 13){
			var jumin1 = juminBizNo.substr(0,6);
			var jumin2 = juminBizNo.substr(6);
			
			var resultjuminCheck = data.juminDataCheck(jumin1, jumin2);
			var juminNation = (resultjuminCheck.indexOf(MSG.CHK_NATION_KO) > -1) ? '1' : '2';
			var adultGubun = (resultjuminCheck.indexOf(MSG.CHK_ADULT_OK) > -1) ? MSG.CHK_ADULT_OK : MSG.CHK_ADULT_NO;
			var genderGubun = (resultjuminCheck.indexOf(MSG.CHK_SEX_M) > -1) ? MSG.CHK_SEX_M : MSG.CHK_SEX_W;
			
			if(tab.indexOf("gae") > -1){
				/*
				 * 신청자 탭구분 
				 * 개인(성인) : 본인, 가족, 법정대리인
				 * 미성년자 : 법정대리인
				 * */
				/*
				 * 사업자 과세비과세 출력
				 * */
				$("#div_chkpAuto_email_taxgbn").hide(); //계좌이체 > 요금확인 > 이메일
				$("#div_chkpAuto_mobile_taxgbn").hide();//계좌이체 > 요금확인 > 모바일
				$("#div_chkpAuto_goji_taxgbn").hide();	//계좌이체 > 요금확인 > 고지서
				
				
				$("#div_chkpCard_email_taxgbn").hide(); //카드 > 요금확인 > 이메일
				$("#div_chkpCard_mobile_taxgbn").hide();//카드 > 요금확인 > 모바일
				$("#div_chkpCard_goji_taxgbn").hide();//카드 > 요금확인 > 고지서
				
				$("#div_chkpAuto_email_taxgbnText").hide(); //계좌이체 > 요금확인 > 이메일텍스트
				$("#div_chkpAuto_mobile_taxgbnText").hide(); //계좌이체 > 요금확인 > 모바일텍스트
				$("#div_chkpAuto_goji_taxgbnText").hide(); //계좌이체 > 요금확인 > 고지텍스트
				
				$("#div_chkpCard_email_taxgbnText").hide(); //카드 > 요금확인 > 이메일텍스트
				$("#div_chkpCard_mobile_taxgbnText").hide(); //카드 > 요금확인 > 모바일텍스트
				$("#div_chkpCard_goji_taxgbnText").hide(); //카드 > 요금확인 > 고지텍스트
				
				if(juminNation == "1"){
					if(adultGubun != MSG.CHK_ADULT_OK){
						/*
						 * 미성년자
						 * */
						$("#div_tab_gae_req").hide();
						$("#div_tab_gae_reqFa").hide();
						$("#div_tab_gae_reqDae").trigger('click');
						/*
						 * 신분증 촬영부분
						 * */
						$("#aoz_div_gae_id_camDoc1").hide();  //신청자 신분증
						$("#aoz_ul_gae_dae_id_camDoc1").hide();  //법정대리 신분증
						$("#aoz_ul_gae_dae_id_camDoc3").hide();  //법정대리 위임장
						
						
					}else{
						/*
						 * 신분증 촬영부분
						 * */
						$("#aoz_div_gae_id_camDoc1").show();
					}
				}else{
					/*
					 * 신청자 탭구분 
					 * 외국 : 본인
					 **/ 
					$("#div_tab_gae_req").show();
					$("#div_tab_gae_reqFa").hide();
					$("#div_tab_gae_reqDae").hide();
					/*
					 * 신분증 촬영부분
					 * */
					$("#aoz_div_gae_id_camDoc1").show();
					/*
					 * 납부정보 
					 * 외국인 신용카드만 가능
					 * 신용카드는 모바일 이메일만 가능
					 * */
					$("#div_tab_pay_auto").hide();
					$("#div_tab_pay_card").trigger('click');
					//요금확인
					$("#div_tab_chkpCard_goji").hide();
					
				}
			}else{
				var v_custType = $("#inp_custTypeCd").val();
				/*
				 * 6 : 공공기관
				 * 5 : 외국법인
				 * 4 : 법인
				 * 3 : 개인사업자
				 * */
				if(tab.indexOf("saup") > -1){
					/*
					 * 납부정보 요금확인
					 * 사업자 이메일, 고지서만 가능
					 * */
					$("#div_tab_chkp_mobile").hide(); //요금확인 계좌 > 모바일
					$("#div_tab_chkpCard_mobile").hide(); //요금확인 카드 > 모바일
					/*
					 * 사업자 과세비과세 출력
					 * */
					$("#div_chkpAuto_email_taxgbn").show(); //계좌이체 > 요금확인 > 이메일
					$("#div_chkpAuto_mobile_taxgbn").show();//계좌이체 > 요금확인 > 모바일
					$("#div_chkpAuto_goji_taxgbn").show();	//계좌이체 > 요금확인 > 고지서
					
					
					/*$("#div_chkpCard_email_taxgbn").show(); //카드 > 요금확인 > 이메일
					$("#div_chkpCard_mobile_taxgbn").show();//카드 > 요금확인 > 모바일
					$("#div_chkpCard_goji_taxgbn").show();//카드 > 요금확인 > 고지서
					
					$("#div_chkpAuto_email_taxgbnText").show(); //계좌이체 > 요금확인 > 이메일텍스트
					$("#div_chkpAuto_mobile_taxgbnText").show(); //계좌이체 > 요금확인 > 모바일텍스트
					$("#div_chkpAuto_goji_taxgbnText").show(); //계좌이체 > 요금확인 > 고지텍스트
					
					$("#div_chkpCard_email_taxgbnText").show(); //카드 > 요금확인 > 이메일텍스트
					$("#div_chkpCard_mobile_taxgbnText").show(); //카드 > 요금확인 > 모바일텍스트
					$("#div_chkpCard_goji_taxgbnText").show(); //카드 > 요금확인 > 고지텍스트
*/					
					if(tab.indexOf("reqMe") > -1){
						$("#aoz_ul_saup_ceo_id_camDoc1").show();//내국인신분증
						$("#aoz_ul_saup_ceo_id_camDoc4").show();//외국인신분증
						$("#aoz_ul_saup_ceo_id_camDoc2").show();//사업자 등록증
						$("#aoz_ul_saup_ceo_id_camDoc3").show();//법인 등록증
						
						/*대표*/
						if(v_custType == "3"){
							/*
							 * 개인사업자 
							 * */
							//$("#aoz_ul_saup_ceo_id_camDoc3").hide();//대표자 법인인감증명서
							//$("#aoz_ul_saup_jig_id_camDoc3").hide();//직원 법인인감증명서
							if(juminNation == "1"){
								$("#aoz_ul_saup_ceo_id_camDoc1").show(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc4").hide(); //외국인 신분증
								
								$("#aoz_ul_saup_ceo_id_camDoc2").show(); //사업자 등록증
								$("#aoz_ul_saup_ceo_id_camDoc3").hide(); //사업자 등록증
							}else{
								//외국인
								$("#aoz_ul_saup_ceo_id_camDoc1").hide(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc4").show(); //외국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc2").show(); //사업자 등록증
								$("#aoz_ul_saup_ceo_id_camDoc3").hide(); //법인 등록증
							}
						}else if(v_custType == "4"){
							/*
							 * 법인
							 * */
							if(juminNation == "1"){
								$("#aoz_ul_saup_ceo_id_camDoc1").show(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc4").hide(); //외국인 신분증
							}else{
								//외국인
								$("#aoz_ul_saup_ceo_id_camDoc1").hide(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc4").show(); //외국인 신분증
								
							}
						}else if(v_custType == "5"){
							/*
							 * 외국법인
							 * */
							if(juminNation == "1"){
								$("#aoz_ul_saup_ceo_id_camDoc1").show(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc4").hide(); //외국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc2").show(); //사업자 등록증
								$("#aoz_ul_saup_ceo_id_camDoc3").hide(); //사업자 등록증
							}else{
								//외국인
								$("#aoz_ul_saup_ceo_id_camDoc1").hide(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc4").show(); //외국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc2").show(); //사업자 등록증
								$("#aoz_ul_saup_ceo_id_camDoc3").hide(); //법인 등록증
							}
						}else if(v_custType == "6"){
							/*
							 * 공공기관
							 * */
							if(juminNation == "1"){
								$("#aoz_ul_saup_ceo_id_camDoc1").show(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc4").hide(); //외국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc2").show(); //사업자 등록증
								$("#aoz_ul_saup_ceo_id_camDoc3").hide(); //사업자 등록증
							}else{
								//외국인
								$("#aoz_ul_saup_ceo_id_camDoc4").show(); //외국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc1").hide(); //내국인 신분증
								$("#aoz_ul_saup_ceo_id_camDoc2").show(); //사업자 등록증
								$("#aoz_ul_saup_ceo_id_camDoc3").hide(); //법인 등록증
							}
						}
						
					}else{
						if(tab.indexOf("reqJig") > -1){
							$("#aoz_ul_saup_jig_id_camDoc1").show();//내국인 신분증
							$("#aoz_ul_saup_jig_id_camDoc6").show();//외국인 신분증
							
							$("#aoz_ul_saup_jig_id_camDoc2").show();//사업자 등록증
							$("#aoz_ul_saup_jig_id_camDoc3").show();//법인 증명서
							$("#aoz_ul_saup_jig_id_camDoc4").show();//재직증명서
							$("#aoz_ul_saup_jig_id_camDoc5").show();//위임장(사원증,재직증명)
							
							/*직원*/
							if(v_custType == "3"){
								/*
								 * 개인사업자 
								 * */
								if(juminNation == "1"){
									$("#aoz_ul_saup_jig_id_camDoc1").show(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").hide(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc3").hide();//법인 증명서
									$("#aoz_ul_saup_jig_id_camDoc5").hide();//위임장(사원증,재직증명)
								}else{
									//외국인
									$("#aoz_ul_saup_jig_id_camDoc1").hide(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").show(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc3").hide();//법인 증명서
									$("#aoz_ul_saup_jig_id_camDoc5").hide();//위임장(사원증,재직증명)
								}
							}else if(v_custType == "4"){
								/*
								 * 법인
								 * */
								if(juminNation == "1"){
									$("#aoz_ul_saup_jig_id_camDoc1").show(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").hide(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc5").hide();//위임장(사원증,재직증명)
								}else{
									//외국인
									$("#aoz_ul_saup_jig_id_camDoc1").hide(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").show(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc5").hide();//위임장(사원증,재직증명)
								}
							}else if(v_custType == "5"){
								/*
								 * 외국법인
								 * */
								if(juminNation == "1"){
									$("#aoz_ul_saup_jig_id_camDoc1").show(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").hide(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc4").hide();//재직증명서
								}else{
									$("#aoz_ul_saup_jig_id_camDoc1").hide(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").show(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc4").hide();//재직증명서
								}
							}else if(v_custType == "6"){
								/*
								 * 공공기관
								 * */
								if(juminNation == "1"){
									$("#aoz_ul_saup_jig_id_camDoc1").show(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").hide(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc5").hide();//위임장(사원증,재직증명)
								}else{
									$("#aoz_ul_saup_jig_id_camDoc1").hide(); //내국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc6").hide(); //외국인 신분증
									$("#aoz_ul_saup_jig_id_camDoc5").hide();//위임장(사원증,재직증명)
								}
							}
						}
						
					}
				}
			}
		}
		/*
		 * 납부정보
		 * 
		if(tab.indexOf("payAuto") > -1){//자동이체
			
		}else if(tab.indexOf("payCard") > -1){//카드이체
			$("#div_tab_chkpCard_email").show();
			$("#div_tab_chkpCard_mobile").show(); 
			$("#div_tab_chkpCard_goji").hide(); 
		}*/
		
	},
	tabOnCheck : function(){	
		var tab = "";
		if($("#div_tab_gae").attr("class").indexOf("active") > -1){
			if($("#div_tab_gae_req").attr("class").indexOf("active") > -1){
				tab = "gae_reqMe"; //개인 > 본인
			}else if($("#div_tab_gae_reqFa").attr("class").indexOf("active") > -1){
				tab = "gae_reqFa"; //개인 > 가족
			}else if($("#div_tab_gae_reqDae").attr("class").indexOf("active") > -1){
				tab = "gae_reqDae"; //개인 > 법정대리인
			}
			
		}else if($("#div_tab_saup").attr("class").indexOf("active") > -1){
			if($("#div_tab_saup_req").attr("class").indexOf("active") > -1){
				tab = "saup_reqMe"; //사업자 > 본인(대표자)
			}else if($("#div_tab_saup_reqJig").attr("class").indexOf("active") > -1){
				tab = "saup_reqJig"; //사업자 > 직원
			}
		}
		/*
		 * 요금납부구분
		 * */
		if($("#div_tab_pay_auto").attr("class").indexOf("active") > -1){
			tab = tab + "_payAuto";
			/*
			 * 요금확인방법 구분(자동이체)
			 * */
			if($("#div_tab_chkp_email").attr("class").indexOf("active") > -1){
				tab = tab + "_chkpEmail";
			}else if($("#div_tab_chkp_mobile").attr("class").indexOf("active") > -1){
				tab = tab + "_chkpMobile";
			}else if($("#div_tab_chkp_goji").attr("class").indexOf("active") > -1){
				tab = tab + "_chkpGoji";
			}
		}else if($("#div_tab_pay_card").attr("class").indexOf("active") > -1){
			tab = tab + "_payCard";
			/*
			 * 요금확인방법 구분(카드)
			 * */
			if($("#div_tab_chkpCard_email").attr("class").indexOf("active") > -1){
				tab = tab + "_chkpCardEmail";
			}else if($("#div_tab_chkpCard_mobile").attr("class").indexOf("active") > -1){
				tab = tab + "_chkpCardMobile";
			}else if($("#div_tab_chkpCard_goji").attr("class").indexOf("active") > -1){
				tab = tab + "_chkpCardGoji";
			}
		}
		return tab;
	},
	tabAuthCheck : function(){//개인,사업자 인증체크	
		//, #inp_gae_juminNo1, #inp_gae_juminNo2
		var tab = "";
		if($("#inp_gae_custNm").attr("disabled") == "disabled"
			&& $("#inp_gae_juminNo1").attr("disabled") == "disabled"
			&& $("#inp_gae_juminNo2").attr("disabled") == "disabled"){
			tab = "gae";
			return tab;
		}else{
			//#inp_saup_custNm, #inp_saup_compNum1, #inp_saup_compNum2, #inp_saup_compNum3, #inp_saup_ceoNm, #inp_saup_corpNm
			if($("#inp_saup_custNm").attr("disabled") == "disabled"
				&& $("#inp_saup_compNum1").attr("disabled") == "disabled"
				&& $("#inp_saup_compNum2").attr("disabled") == "disabled"
				&& $("#inp_saup_compNum3").attr("disabled") == "disabled"){
				tab = "saup";
				return tab;
			}
		}
	},
	on : function(){
		//상단 탭 - 개인
		$('#div_tab_gae').on({
			click :function(event){
	        	
	        	var tab = ui.tabAuthCheck();
	        	//console.log('div_tab_gae :: ' + tab);
	        	if(tab == "gae"){
	        		$("#cust").show();
		        	$("#cmpy").hide();
		        	//과세구분
		        	//$("#div_chkp_email_taxgbn").hide();
		        	//$("#div_chkpCard_email_taxgbn").hide();
		        	
	        	}else if(tab == "saup"){
	        		$("#cmpy").show();
		        	$("#cust").hide();
		        	$("#div_tab_saup").addClass("active");
		        	$("#div_tab_gae").removeClass("active");
		        	
		        	//과세구분
		        	//$("#div_chkp_email_taxgbn").show();
		        	//$("#div_chkpCard_email_taxgbn").show();
	        	}else{
	        		$("#cust").show();
		        	$("#cmpy").hide();
		        	//과세구분
		        	//$("#div_chkp_email_taxgbn").hide();
		        	//$("#div_chkpCard_email_taxgbn").hide();
	        	}
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
		
	    });
		//상단 탭 - 사업자
		$('#div_tab_saup').on({
			click :function(event){
	        	
	        	/*$("#cust").show();
	        	$("#cmpy").hide();
	        	$("#div_tab_gae").addClass("active");
	        	$("#div_tab_saup").removeClass("active");
	        	g_msgObj.msg1 = "개발중";
	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
	        	return;*/
	        	var tab = ui.tabAuthCheck();
	        	//console.log('div_tab_saup :: ' + tab);
	        	if(tab == "gae"){
	        		$("#cust").show();
		        	$("#cmpy").hide();
		        	$("#div_tab_gae").addClass("active");
		        	$("#div_tab_saup").removeClass("active");
	        	}else if(tab == "saup"){
	        		$("#cmpy").show();
		        	$("#cust").hide();
	        	}else{
	        		$("#cmpy").show();
		        	$("#cust").hide();
	        	}
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//중단 탭 - 개인 > 본인
		$('#div_tab_gae_req').on({
			click :function(event){
	        	//console.log('div_tab_gae_req');
	        	//div_sms_authOK
	    		//if($("#div_sms_authOK").css("display") != "none"){
	    		//}
	        	//data.resetSmsData(false, false);
	        	//$("#div_sms_authOK").hide();
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	//data.nextCheck();
	        	data.nextCheckStep();
	        }
	    });
		//중단 탭 - 개인 > 가족
		$('#div_tab_gae_reqFa').on({
			click :function(event){
	        	//console.log('div_tab_gae_reqFa');
	        	//data.resetSmsData(true, false);
	        	//$("#div_sms_authOK").hide();
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	//data.nextCheck();
	        	data.nextCheckStep();
	        }
	    });
		//중단 탭 - 개인 > 대리인
		$('#div_tab_gae_reqDae').on({
			click :function(event){
	        	//console.log('div_tab_gae_reqDae');
	        	//data.resetSmsData(true, false);
	        	//$("#div_sms_authOK").hide();
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	//data.nextCheck();
	        	data.nextCheckStep();
	        }
	    });
		//중단 탭 - 사업 > 대표자
		$('#div_tab_saup_req').on({
			click :function(event){
	        	//console.log('div_tab_gae_reqFa');
	        	//data.resetSmsData(true, false);
	        	//$("#div_sms_authOK").hide();
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	//data.nextCheck();
	        	data.nextCheckStep();
	        }
	    });
		//중단 탭 - 사업 > 직원
		$('#div_tab_saup_reqJig').on({
			click :function(event){
	        	//console.log('div_tab_gae_reqFa');
	        	//data.resetSmsData(true, false);
	        	//$("#div_sms_authOK").hide();
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	//data.nextCheck();
	        	data.nextCheckStep();
	        }
	    });
		//납부정보 > 자동이체
		$('#div_tab_pay_auto').on({
			click :function(event){
	        	//console.log('div_tab_pay_auto');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//납부정보 > 카드이체
		$('#div_tab_pay_card').on({
			click :function(event){
	        	//console.log('div_tab_pay_card');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//요금확인 > 자동이체 > 이메일
		$('#div_tab_chkp_email').on({
			click :function(event){
	        	//console.log('div_tab_chkp_email');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//요금확인 > 자동이체  > 모바일
		$('#div_tab_chkp_mobile').on({
			click :function(event){
	        	//console.log('div_tab_chkp_mobile');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//요금확인 > 자동이체  > 고지서
		$('#div_tab_chkp_goji').on({
			click :function(event){
	        	//console.log('div_tab_chkp_goji');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//요금확인 > 카드이체 > 이메일
		$('#div_tab_chkpCard_email').on({
			click :function(event){
	        	//console.log('div_tab_chkpCard_email');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//요금확인 > 카드이체  > 모바일
		$('#div_tab_chkpCard_mobile').on({
			click :function(event){
	        	//console.log('div_tab_chkpCard_mobile');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
		//요금확인 > 카드이체  > 고지서
		$('#div_tab_chkpCard_goji').on({
			click :function(event){
	        	//console.log('div_tab_chkpCard_goji');
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
	    });
	}
}



var evtGae = {
		on : function(){
			//SMS인증
			$("#slt_sms_hpNo1, #inp_sms_hpNo2, #inp_sms_hpNo3").on("keyup change", function(e) {
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_sms_hpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_sms_hpNo1","inp_sms_hpNo2");
					}
				}else if($(this).attr("id") == "inp_sms_hpNo2"){
					fnNextFocus("inp_sms_hpNo2","inp_sms_hpNo3");
				}
			});
			//개인 - 고객명, 주민1, 주민2
			$('#inp_gae_custNm, #inp_gae_juminNo1, #inp_gae_juminNo2').on({
				keyup :function(event){
					if($("#inp_inf_certiKey").val() != ""){
						return;
					}
					//console.log($("#inp_gae_custNm").attr("maxlength"));
		        	//console.log('id :: ' + $(this).attr("id") + " <> " + $(this).attr("maxlength") + " <val> " + $(this).val());
		        	if($("#inp_gae_custNm").val() != ""
		        		&& $("#inp_gae_juminNo1").val() != ""
		        		&& $("#inp_gae_juminNo2").val() != ""){
		        		if( ($("#inp_gae_juminNo1").val().length >= $("#inp_gae_juminNo1").attr("maxlength"))
		        			&& ($("#inp_gae_juminNo2").val().length >= $("#inp_gae_juminNo2").attr("maxlength"))){
		        			fnDisbClass("#btn_gae_custOk", false,"#btn_gae_custOk","", "disabled");
		        		}else{
		        			fnDisbClass("#btn_gae_custOk", true,"#btn_gae_custOk","disabled", "");
		        		}
		        	}
		        	
		        	
		        	/*
		        	 * 포커스이동
		        	 * */
		        	fnNextFocus("inp_gae_juminNo1", "inp_gae_juminNo2");
		        	/*
		        	 * 변경구분
		        	 * */
		        	$("#inp_nextCheck_dataCustFlag").val("Y");
		        	/*
		        	 * 데이터 체크
		        	 * */
		        	data.nextCheckStep();
		        }
	    	});
			//개인 > 핸드폰 번호
			$("#slt_gae_hpNo1, #inp_gae_hpNo2, #inp_gae_hpNo3").on("keyup change", function(e) {
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_gae_hpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_gae_hpNo1","inp_gae_hpNo2");
					}
				}else if($(this).attr("id") == "inp_gae_hpNo2"){
					fnNextFocus("inp_gae_hpNo2","inp_gae_hpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataCustFlag").val("Y");
				/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheck();
				
			});
			//개인 > 유선전화번호(선택)
			$("#slt_gae_telNo1, #inp_gae_telNo2, #inp_gae_telNo3").on("keyup change", function() {
				if($(this).attr("id") == "slt_gae_telNo1"){
					if($(this).val() != ""){
						fnNextFocus('slt_gae_telNo1','inp_gae_telNo2');
					}
				}else if($(this).attr("id") == "inp_gae_telNo2"){
					fnNextFocus('inp_gae_telNo2','inp_gae_telNo3');
				}
				
			});
			//개인 > 감면구분 선택
			/*$("#slt_gae_gam").on("change",function(){
				if($("input:checkbox[id='chk_gae_gam']").is(":checked")){
					
		        	 * 데이터 체크
		        	 * 
		        	data.nextCheck();
				}
			});*/
			//개인 > 가족 - 고객명 주민1 주민2
			$('#inp_gae_fa_custNm, #inp_gae_fa_juminNo1, #inp_gae_fa_juminNo2').on({
				keyup :function(event){
					if($("#inp_gae_fa_custNm").val() != ""
		        		&& $("#inp_gae_fa_juminNo1").val() != ""
		        		&& $("#inp_gae_fa_juminNo2").val() != ""){
		        		if( ($("#inp_gae_fa_juminNo1").val().length >= $("#inp_gae_fa_juminNo1").attr("maxlength"))
		        			&& ($("#inp_gae_fa_juminNo2").val().length >= $("#inp_gae_fa_juminNo2").attr("maxlength"))){
		        			fnDisbClass("#btn_gae_fa_custOk", false,"#btn_gae_fa_custOk","", "disabled");
		        		}else{
		        			fnDisbClass("#btn_gae_fa_custOk", true,"#btn_gae_fa_custOk","disabled", "");
		        		}
		        	}
					/*
					 * 포커스이동
					 * */
					fnNextFocus("inp_gae_fa_juminNo1", "inp_gae_fa_juminNo2");
					/*
		        	 * 변경구분
		        	 * */
		        	$("#inp_nextCheck_dataCustFlag").val("Y");
					/*
		        	 * 데이터 체크
		        	 * */
		        	data.nextCheckStep();
				}
			});
			//개인 > 가족 핸드폰 번호
			$("#slt_gae_fa_hpNo1, #inp_gae_fa_hpNo2, #inp_gae_fa_hpNo3").on("keyup change", function() {
				//console.log("inp_gae_fa_hpNo2");
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_gae_fa_hpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_gae_fa_hpNo1","inp_gae_fa_hpNo2");
					}
				}else if($(this).attr("id") == "inp_gae_fa_hpNo2"){
					fnNextFocus("inp_gae_fa_hpNo2","inp_gae_fa_hpNo3");
				}
				
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataCustFlag").val("Y");
				/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheck();
			});
			//개인 > 법정대리인 - 고객명 주민1 주민2
			$('#inp_gae_dae_custNm, #inp_gae_dae_juminNo1, #inp_gae_dae_juminNo2').on({
				keyup :function(event){
					if($("#inp_gae_dae_custNm").val() != ""
		        		&& $("#inp_gae_dae_juminNo1").val() != ""
		        		&& $("#inp_gae_dae_juminNo2").val() != ""){
		        		if( ($("#inp_gae_dae_juminNo1").val().length >= $("#inp_gae_dae_juminNo1").attr("maxlength"))
		        			&& ($("#inp_gae_dae_juminNo2").val().length >= $("#inp_gae_dae_juminNo2").attr("maxlength"))){
		        			fnDisbClass("#btn_gae_dae_custOk", false,"#btn_gae_dae_custOk","", "disabled");
		        		}else{
		        			fnDisbClass("#btn_gae_dae_custOk", true,"#btn_gae_dae_custOk","disabled", "");
		        		}
		        	}
					/*
					 * 포커스이동
					 * */
					fnNextFocus("inp_gae_dae_juminNo1", "inp_gae_dae_juminNo2");
					
					/*
		        	 * 변경구분
		        	 * */
		        	$("#inp_nextCheck_dataCustFlag").val("Y");
					/*
		        	 * 데이터 체크
		        	 * */
		        	data.nextCheckStep();
				}
			});
			//개인 > 법정대리 핸드폰 번호
			$("#slt_gae_dae_hpNo1, #inp_gae_dae_hpNo2, #inp_gae_dae_hpNo3").on("keyup change", function() {
				//console.log("inp_gae_dae_hpNo2");
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_gae_dae_hpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_gae_dae_hpNo1","inp_gae_dae_hpNo2");
					}
				}else if($(this).attr("id") == "inp_gae_dae_hpNo2"){
					fnNextFocus("inp_gae_dae_hpNo2","inp_gae_dae_hpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataCustFlag").val("Y");
				/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheck();
			});
			
			//개인 (본인,가족,법정대리인)- 고객정보확인 버튼, 사업자 대표자 직원 인증 포함
			$('#btn_gae_custOk, #btn_gae_fa_custOk, #btn_gae_dae_custOk, #btn_saup_custOk2,#btn_saup_jig_custOk').on({
				click :function(event){
		        	//console.log('btn_gae_custOk >> ' + $(this).attr("id"));
		        	var btnId = $(this).attr("id");
		        	if(g_flag){
	        			data.setFlag(false);
	        			var custNm = $("#inp_gae_custNm").val();
	        			var jumin1 = $("#inp_gae_juminNo1").val();
	        			var jumin2 = $("#inp_gae_juminNo2").val();
	        			var callType = "gae";
	        			if(btnId == "btn_gae_fa_custOk"){
	        				custNm = $("#inp_gae_fa_custNm").val();
	        				jumin1 = $("#inp_gae_fa_juminNo1").val();
	        				jumin2 = $("#inp_gae_fa_juminNo2").val();
	        				callType = "gae_fa";
	        			}else if(btnId == "btn_gae_dae_custOk"){
	        				custNm = $("#inp_gae_dae_custNm").val();
	        				jumin1 = $("#inp_gae_dae_juminNo1").val();
	        				jumin2 = $("#inp_gae_dae_juminNo2").val();
	        				callType = "gae_dae";
	        			}else if(btnId == "btn_saup_custOk2"){
	        				custNm = $("#inp_saup_ceoNm2").val();
	        				jumin1 = $("#inp_saup_juminNo1").val();
	        				jumin2 = $("#inp_saup_juminNo2").val();
	        				callType = "saup";
	        			}else if(btnId == "btn_saup_jig_custOk"){
	        				custNm = $("#inp_saup_jig_ceoNm").val();
	        				jumin1 = $("#inp_saup_jig_juminNo1").val();
	        				jumin2 = $("#inp_saup_jig_juminNo2").val();
	        				callType = "saup_jig";
	        			}
	        				
	        			var resultjuminCheck = data.juminDataCheck(jumin1, jumin2);
	        			//console.log("resultjuminCheck >> " + resultjuminCheck);
	        			if(MSG.CHK_JUMIN_ERROR != resultjuminCheck){
	        				var jumin = jumin1+""+jumin2;	
	        				var juminNation = (resultjuminCheck.indexOf(MSG.CHK_NATION_KO) > -1) ? '1' : '2';
	        				var adultGubun = (resultjuminCheck.indexOf(MSG.CHK_ADULT_OK) > -1) ? MSG.CHK_ADULT_OK : MSG.CHK_ADULT_NO;
	        				var genderGubun = (resultjuminCheck.indexOf(MSG.CHK_SEX_M) > -1) ? MSG.CHK_SEX_M : MSG.CHK_SEX_W;
	        				
	        				//$("#inp_nationGubun").val(juminNation);//1 내국 2 외국
	        				//$("#inp_adultGubun").val(adultGubun);
	        				//$("#inp_genderGubun").val(genderGubun);
	        				/*
	        				 * 외국인일경우 실명인증 제외 
	        				 * */
	        				if(juminNation == "2"){
	        					var v_custTypeCd = "";
	        					var v_certiKey = "";
	        					var v_aplnTypeCd = "";
	        					var v_custNmCertiTypeCd = "04";
	        					if(callType == "gae"){
	        						/*
		        					 * 인증시간 셋팅
		        					 * */
		        					$("#inp_inf_certiKey").val(juminNation +":"+ jumin);
		        					fnSetCertiTime("inp_inf_certiTime");
		        					
	        						/*
	        						 * 데이터 셋팅
	        						 * */
	        						
	        						v_certiKey = $("#inp_inf_certiKey").val();
	        						$("#inp_custTypeCd").val("2");
	        						v_custTypeCd = $("#inp_custTypeCd").val();
	        						$("#inp_aplnTypeCd").val("01"); //본인
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moCustNmCertiTypeCd").val();
	        						
	        						/*
	        						 * 버튼처리
	        						 * */
		        					fnDisbClass("#inp_gae_custNm", true, "", "", "");
		        					fnDisbClass("#inp_gae_juminNo1", true, "", "", "");
		        					fnDisbClass("#inp_gae_juminNo2", true, "", "", "");
		        					fnDisbClass("#btn_gae_custOk", true, "#btn_gae_custOk", "disabled", "");
		        					/*
		        					 * //aoz 버튼 disabled 처리
		        					 * */
		        					fnDisbClass("#aoz_btn_gae_id_cam", true, "#aoz_btn_gae_id_cam", "disabled", "");
		        					fnDisbClass("#aoz_btn_gae_id_camInfoPop", true, "#aoz_btn_gae_id_camInfoPop", "disabled", "");
		        					//텍스트 변경
		        					$("#aoz_input_gae_id_camDoc1").attr("placeholder","신분증(외국인 등록증 혹은 국내 거소신고증)");
		        					
		        					
	        					}else if(callType == "gae_fa"){
	        						/*
	        						 * 인증시간 셋팅
	        						 * */
	        						$("#inp_inf_certiKey2").val(juminNation +":"+ jumin);
	        						fnSetCertiTime("inp_inf_certiTime2");
	        						/*
	        						 * 데이터 셋팅
	        						 * */
	        						v_certiKey = $("#inp_inf_certiKey2").val();
	        						v_custTypeCd = "2";
	        						$("#inp_aplnTypeCd").val("02"); //가족
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd").val();
	        						/*
	        						 * 버튼처리
	        						 * */
	        						fnDisbClass("#inp_gae_fa_custNm", true, "", "", "");
	        						fnDisbClass("#inp_gae_fa_juminNo1", true, "", "", "");
	        						fnDisbClass("#inp_gae_fa_juminNo2", true, "", "", "");
	        						fnDisbClass("#btn_gae_fa_custOk", true, "#btn_gae_fa_custOk", "disabled", "");
	        						/*
	        						 * //aoz 버튼 disabled 처리
	        						 * */
	        						fnDisbClass("#aoz_btn_gae_fa_id_cam", true, "#aoz_btn_gae_fa_id_cam", "disabled", "");
	        						fnDisbClass("#aoz_btn_gae_fa_id_camInfoPop", true, "#aoz_btn_gae_fa_id_camInfoPop", "disabled", "");
	        						
	        						/*
	        						 * 법정대리인 인증되어있으면 초기화처리
	        						 * */
	        						$("#inp_inf_certiKey3").val("");
	        						$("#inp_inf_certiTime3").val("");
	        						/*
	        						 * 법정대리인 버튼 활성화처리
	        						 * */
	        						fnDisbClass("#inp_gae_dae_custNm", false, "", "", "");
	        						fnDisbClass("#inp_gae_dae_juminNo1", false, "", "", "");
	        						fnDisbClass("#inp_gae_dae_juminNo2", false, "", "", "");
	        						fnDisbClass("#btn_gae_dae_custOk", false, "#btn_gae_dae_custOk", "", "disabled");
	        						fnDisbClass("#aoz_btn_gae_dae_id_cam", false, "#aoz_btn_gae_dae_id_cam", "", "disabled");
	        						fnDisbClass("#aoz_btn_gae_dae_id_camInfoPop", false, "#aoz_btn_gae_dae_id_camInfoPop", "", "disabled");
	        					}else if(callType == "gae_dae"){
	        						/*
	        						 * 인증시간 셋팅
	        						 * */
	        						$("#inp_inf_certiKey3").val(juminNation +":"+ jumin);
	        						fnSetCertiTime("inp_inf_certiTime3");
	        						/*
	        						 * 데이터 셋팅
	        						 * */
	        						v_certiKey = $("#inp_inf_certiKey3").val();
	        						v_custTypeCd = "2";
	        						$("#inp_aplnTypeCd").val("05"); //법정대리
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd2").val();
	        						/*
	        						 * 버튼처리
	        						 * */
	        						fnDisbClass("#inp_gae_dae_custNm", true, "", "", "");
	        						fnDisbClass("#inp_gae_dae_juminNo1", true, "", "", "");
	        						fnDisbClass("#inp_gae_dae_juminNo2", true, "", "", "");
	        						fnDisbClass("#btn_gae_dae_custOk", true, "#btn_gae_dae_custOk", "disabled", "");
	        						
	        						/*
	        						 * //aoz 버튼 disabled 처리
	        						 * */
	        						fnDisbClass("#aoz_btn_gae_dae_id_cam", true, "#aoz_btn_gae_dae_id_cam", "disabled", "");
	        						fnDisbClass("#aoz_btn_gae_dae_id_camInfoPop", true, "#aoz_btn_gae_dae_id_camInfoPop", "disabled", "");
	        						/*
	        						 * 가족 인증되어있으면 초기화처리
	        						 * */
	        						$("#inp_inf_certiKey2").val("");
	        						$("#inp_inf_certiTime2").val("");
	        						/*
	        						 * 가족 버튼 활성화처리
	        						 * */
	        						fnDisbClass("#inp_gae_fa_custNm", false, "", "", "");
	        						fnDisbClass("#inp_gae_fa_juminNo1", false, "", "", "");
	        						fnDisbClass("#inp_gae_fa_juminNo2", false, "", "", "");
	        						fnDisbClass("#btn_gae_fa_custOk", false, "#btn_gae_fa_custOk", "", "disabled");
	        						fnDisbClass("#aoz_btn_gae_fa_id_cam", false, "#aoz_btn_gae_fa_id_cam", "", "disabled");
	        						fnDisbClass("#aoz_btn_gae_fa_id_camInfoPop", false, "#aoz_btn_gae_fa_id_camInfoPop", "", "disabled");
	        						
	        					}else if(callType == "saup"){
	        						/*
	        						 * 인증시간 셋팅
	        						 * */
	        						$("#inp_inf_certiKey2").val(juminNation +":"+ jumin);
	        						fnSetCertiTime("inp_inf_certiTime2");
	        						/*
	        						 * 데이터 셋팅
	        						 * */
	        						v_certiKey = $("#inp_inf_certiKey2").val();
	        						v_custTypeCd = $("#inp_custTypeCd").val();
	        						$("#inp_aplnTypeCd").val("03"); //대표자
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd").val();
	        						
	        						/*
	        						 * 버튼처리
	        						 * */
	        						fnDisbClass("#inp_saup_ceoNm2", true, "", "", "");
	        						fnDisbClass("#inp_saup_juminNo1", true, "", "", "");
	        						fnDisbClass("#inp_saup_juminNo2", true, "", "", "");
	        						fnDisbClass("#btn_saup_custOk2", true, "#btn_saup_custOk2", "disabled", "");
	        						//렌탈일때만 sms 호출
	        						//data.resetSmsData(true,false);

	        						/*
	        						 * //aoz 버튼 disabled 처리
	        						 * */
	        						fnDisbClass("#aoz_btn_saup_id_cam", true, "#aoz_btn_saup_id_cam", "disabled", "");
	        						fnDisbClass("#aoz_btn_saup_id_camInfoPop", true, "#aoz_btn_saup_id_camInfoPop", "disabled", "");
	        						
	        						/*
	        						 * 사업-직원 인증되어있으면 초기화처리
	        						 * */
	        						$("#inp_inf_certiKey3").val("");
	        						$("#inp_inf_certiTime3").val("");
	        						/*
	        						 * 사업-직원 버튼 활성화처리
	        						 * */
	        						fnDisbClass("#inp_saup_jig_ceoNm", false, "", "", "");
	        						fnDisbClass("#inp_saup_jig_juminNo1", false, "", "", "");
	        						fnDisbClass("#inp_saup_jig_juminNo2", false, "", "", "");
	        						fnDisbClass("#btn_saup_jig_custOk", false, "#btn_saup_jig_custOk", "", "disabled");
	        						fnDisbClass("#aoz_btn_saup_jig_id_cam", false, "#aoz_btn_saup_jig_id_cam", "", "disabled");
	        						fnDisbClass("#aoz_btn_saup_jig_id_camInfoPop", false, "#aoz_btn_saup_jig_id_camInfoPop", "", "disabled");
	        					}else if(callType == "saup_jig"){
	        						/*
	        						 * 인증시간 셋팅
	        						 * */
	        						$("#inp_inf_certiKey3").val(juminNation +":"+ jumin);
	        						fnSetCertiTime("inp_inf_certiTime3");
	        						/*
	        						 * 데이터 셋팅
	        						 * */
	        						v_certiKey = $("#inp_inf_certiKey3").val();
	        						v_custTypeCd = $("#inp_custTypeCd").val();
	        						$("#inp_aplnTypeCd").val("04"); //직원 
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd2").val();
	        						/*
	        						 * 버튼처리
	        						 * */
	        						fnDisbClass("#inp_saup_jig_ceoNm", true, "", "", "");
	        						fnDisbClass("#inp_saup_jig_juminNo1", true, "", "", "");
	        						fnDisbClass("#inp_saup_jig_juminNo2", true, "", "", "");
	        						fnDisbClass("#btn_saup_jig_custOk", true, "#btn_saup_jig_custOk", "disabled", "");
	        						//렌탈일때만 sms 호출
	        						//data.resetSmsData(true,false);
	        						/*
	        						 * //aoz 버튼 disabled 처리
	        						 * */
	        						fnDisbClass("#aoz_btn_saup_jig_id_cam", true, "#aoz_btn_saup_jig_id_cam", "disabled", "");
	        						fnDisbClass("#aoz_btn_saup_jig_id_camInfoPop", true, "#aoz_btn_saup_jig_id_camInfoPop", "disabled", "");
	        						
	        						/*
	        						 * 사업-대표자 인증되어있으면 초기화처리
	        						 * */
	        						$("#inp_inf_certiKey2").val("");
	        						$("#inp_inf_certiTime2").val("");
	        						
	        						/*
	        						 * 사업-대표자 버튼 활성화처리
	        						 * */
	        						fnDisbClass("#inp_saup_ceoNm2", false, "", "", "");
	        						fnDisbClass("#inp_saup_juminNo1", false, "", "", "");
	        						fnDisbClass("#inp_saup_juminNo2", false, "", "", "");
	        						fnDisbClass("#btn_saup_custOk2", false, "#btn_saup_custOk2", "", "disabled");
	        						fnDisbClass("#aoz_btn_saup_id_cam", false, "#aoz_btn_saup_id_cam", "", "disabled");
	        						fnDisbClass("#aoz_btn_saup_id_camInfoPop", false, "#aoz_btn_saup_id_camInfoPop", "", "disabled");
	        					}
	        					
	        					
	        					/*
	        					 * sms div 보여주기
	        					 * */
	        					$("#div_gae_mobile").show();
	        					//렌탈일때만 sms 호출
	        					//data.resetSmsData(true,false);
	        					
	        					/*
	        					 * 주민번호 이상없을 경우 개인정보 업데이트
	        					 * */
	        					var param = {
        							 moRecvNo : $("#smartRecvNo").val()
        							, custNm : custNm
        							, juminBizNo : jumin
        							, moCustNmCertiKey : v_certiKey
        							, custTypeCd : v_custTypeCd
        							, aplnTypeCd : v_aplnTypeCd
        							, custNmCertiTypeCd : fn_nvl(v_custNmCertiTypeCd,"")
	        					}
	        					fnUpdateSecNumCerti(callType,param);
	        					
	        				}else{
	        					/*
	        					 * 국내자 실명인증
	        					 * */
	        					var v_aplnTypeCd = "01";
	        					var v_custTypeCd = "1";
	        					var v_custNmCertiTypeCd = "";
	        				/*	신청자구분코드	CM377	01	8885810	20140203	29991231	본인
	        					신청자구분코드	CM377	02	8885812	20140203	29991231	가족
	        					신청자구분코드	CM377	03	8885814	20140203	29991231	대표자
	        					신청자구분코드	CM377	04	8885816	20140203	29991231	직원
	        					신청자구분코드	CM377	05	8885818	20140203	29991231	법정대리인
	        					신청자구분코드	CM377	99	8885820	20140203	29991231	기타
	        					APLN_TYPE_CD adultFlag
	        					*/

	        					if(callType == "gae"){
	        						$("#inp_aplnTypeCd").val("01"); //본인
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moCustNmCertiTypeCd").val();
	        					}else if(callType == "gae_fa"){
	        						$("#inp_aplnTypeCd").val("02"); //가족
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd").val();
	        					}else if(callType == "gae_dae"){
	        						$("#inp_aplnTypeCd").val("05"); //법정대리
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd2").val();
	        					}else if(callType == "saup"){
	        						$("#inp_aplnTypeCd").val("03"); //대표자
	        						v_custTypeCd = $("#inp_custTypeCd").val();
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd").val();
	        						
	        					}else if(callType == "saup_jig"){
	        						$("#inp_aplnTypeCd").val("04"); //직원
	        						v_custTypeCd = $("#inp_custTypeCd").val();
	        						v_aplnTypeCd = $("#inp_aplnTypeCd").val();
	        						v_custNmCertiTypeCd = $("#inp_moAplnNmCertiTypeCd2").val();
	        					}
        						
	        					
	        					fnCustAuthCofirm(callType, $("#smartRecvNo").val(), custNm, jumin, "", v_custTypeCd, v_aplnTypeCd, fn_nvl(v_custNmCertiTypeCd,"")); //1 개인 //신분증 인증 구분 나중에 추가
	        				}
		        			
	        			}else{
	        				g_msgObj.msg1 = "주민등록번호 확인";
	        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
	        			}
		        	}
		        	/*
		        	if($(this).attr("id") == "btn_gae_custOk"){
		        		
		        	}else if($(this).attr("id") == "btn_gae_fa_custOk"){
		        		if(g_flag){
		        			data.setFlag(false);
		        			
		        			var jumin1 = $("#inp_gae_fa_juminNo1").val();
		        			var jumin2 = $("#inp_gae_fa_juminNo2").val();
		        			var jumin = jumin1+""+jumin2;
		        			var resultjuminCheck = data.juminDataCheck(jumin1, jumin2);
		        			
		        			//aplnTypeCd 02 가족 대리05
		        			//$("#inp_custTypeCd").val("1");
        					//fnCustAuthCofirm("gae_fa", $("#smartRecvNo").val(), $("#inp_gae_fa_custNm").val(), jumin,"03", "1"); //1 개인 //신분증 인증 구분 나중에 추가
		        			
		        			
		        			fnApiCall_INF_010("gae_fa", $("#inp_gae_fa_custNm").val(), jumin, resultApi.INF_010);
		        		}
		        		
		        	}else if($(this).attr("id") == "btn_gae_dae_custOk"){
		        		if(g_flag){
		        			data.setFlag(false);
		        			var jumin = $("#inp_gae_dae_juminNo1").val()+""+$("#inp_gae_dae_juminNo2").val();
		        			fnApiCall_INF_010("gae_dae", $("#inp_gae_dae_custNm").val(), jumin, resultApi.INF_010);
		        		}
		        	}*/
		        	data.setFlag(true);
		        }
		    });
			
			//개인 - 유선전화번호(선택) 체크박스
			$('#chk_gae_telNo').on({
				click :function(event){
		        	//console.log('chk_gae_telNo');
		        		$("#slt_gae_telNo1 option:eq(0)").prop("selected", true);
		        		$("#slt_gae_telNo1").val("");
		        		$("#inp_gae_telNo2").val("");
			        	$("#inp_gae_telNo3").val("");
			        	updateSelectOrDie();
		        }
		    });
			//개인 - 고객혜택정보제공(선택) 체크박스
			$('#chk_gae_cusInfo').on({
				click :function(event){
		        	//console.log('chk_gae_cusInfo');
		        	/* 전체 Checked 해제 */
		        	$('input[name="chk_gae_cusInfo"]').each(function() {
		        	    $(this).prop('checked', false);
		        	});
		        }
		    });
			//개인 - 감면(선택) 체크박스
			$('#chk_gae_gam').on({
				click :function(event){
		        	//console.log('chk_gae_gam');
		        	$("#slt_gae_gam option:eq(0)").prop("selected", true);
		        	updateSelectOrDie();
		        }
		    });
			//sms1번 전체약관 동의 체크박스
			$('#chk_sms_meAllTerms').on({
				click :function(event){
		        	//console.log('chk_sms_meAllTerms');
		        	if($("input:checkbox[id='chk_sms_meAllTerms']").is(":checked")){
		        		$('input[name="chk_sms_meTerms"]').prop('checked', true);
		        	}else{
		        		$('input[name="chk_sms_meTerms"]').prop('checked', false);
		        	}
		        }
		    });
			//sms1번 인증번호 받기 버튼 클릭
			$('#btn_sms_recvAuthNo').on({
				click :function(event){
		        	//console.log('btn_sms_recvAuthNo');
		        	if($("#slt_sms_mblCmc").val() == ""){
		        		g_msgObj.msg1 = "통신사를 먼저 선택해 주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		return;
		        	}
		        	if($("#slt_sms_hpNo1").val() == ""){
		        		g_msgObj.msg1 = "휴대폰 번호를 먼저 입력해주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		return;
		        	}
		        	if($.trim($("#inp_sms_hpNo2").val()) == ""){
		        		g_msgObj.msg1 = "휴대폰 번호를 먼저 입력해주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		$("#inp_sms_hpNo2").focus();
		        		return;
		        	}
		        	if($.trim($("#inp_sms_hpNo3").val()) == ""){
		        		g_msgObj.msg1 = "휴대폰 번호를 먼저 입력해주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		$("#inp_sms_hpNo3").focus();
		        		return;
		        	}
		        	if(!$("input:checkbox[id='chk_sms_meTerms1']").is(":checked")){
		        		g_msgObj.msg1 = "개인정보 이용 동의 동의 약관에 동의해주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		return;
		        	}
		        	if(!$("input:checkbox[id='chk_sms_meTerms2']").is(":checked")){
		        		g_msgObj.msg1 = "고유식별정보 처리 동의 약관에 동의해주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		return;
		        	}
		        	if(!$("input:checkbox[id='chk_sms_meTerms3']").is(":checked")){
		        		g_msgObj.msg1 = "통신사 이용 약관에 동의해주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		return;
		        	}
		        	if(!$("input:checkbox[id='chk_sms_meTerms4']").is(":checked")){
		        		g_msgObj.msg1 = "서비스 이용 약관에 동의해주세요.";
        	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		        		return;
		        	}
		        	//주민번호 인증 유무 체크
		        	/*
	    			 * sms인증에 필요한 데이터 조합 
	    			 * */
		        	var tab = ui.tabOnCheck();
		        	var custNm = $("#inp_gae_custNm").val();
		        	var jumin = $("#inp_juminBizNo").val(); 
		        	
		        	if(tab.indexOf("saup") > -1){
		        		if(tab.indexOf("reqMe") > -1){
		        			custNm = $("#inp_saup_ceoNm2").val();
		        			jumin = $("#inp_saup_juminNo1").val()+""+$("#inp_saup_juminNo2").val();
		        		}else if(tab.indexOf("reqJig") > -1){	
		        			custNm = $("#inp_saup_jig_ceoNm").val();;
		        			jumin = $("#inp_saup_jig_juminNo1").val()+""+$("#inp_saup_jig_juminNo2").val();
		        		}
		        	}
	    			var juminNo1 = jumin.substr(0,6);
	    			var juminNo2 = jumin.substr(6);
	    			var birthday = fn_getBirthByVal(juminNo1, juminNo2);
	    			//남녀구분
	    			var gender = fn_setBirthSexFromJumin(juminNo1, juminNo2);
	    			//내국인외국인
	    			var nation = fnCmmJuminNation(juminNo1, juminNo2);
	    			//통신사
	    			var phoneCorp = $("#slt_sms_mblCmc").val();
	    			//모바일번호
	    			var mobileNo1 = $("#slt_sms_hpNo1").val();
	    			var mobileNo2 = $("#inp_sms_hpNo2").val();
	    			var mobileNo3 = $("#inp_sms_hpNo3").val();
	    			var mobile = mobileNo1+"-"+mobileNo2+"-"+mobileNo3; //010-1111-2222
	    			//부가서비스 안내동의
	    			//"chk_sms_meTerms5" 부가서비스 안내 동의
	    			var checkMeTerms5 = "N";
	    			if($("input:checkbox[id='chk_sms_meTerms5']").is(":checked")){
	    				checkMeTerms5 = "Y";
	    			}
	    			//-------sms인증에 필요한 데이터 조합
	    			/*
	    			console.log("birthday > " + birthday);
	    			console.log("gender > " + gender);
	    			console.log("nation > " + nation);
	    			console.log("phoneCorp > " + phoneCorp);
	    			console.log("mobile > " + mobile);
	    			console.log("checkMeTerms5 > " + checkMeTerms5);*/
	    			//return;
		        	//--주민번호 인증 유무 체크
		        	
		        	var btnText = fn_replaceAll($("#btn_sms_recvAuthNo>span").html()," ","");
	        		//인터페이스 호출
	        		if(g_flag){
	        			data.setFlag(false);
	        			var param = {
	        					custNm : custNm
	        					, birthDt : birthday
	        					, gender : gender
	        					, nation : nation
	        					, phoneCorp : phoneCorp
	        					, mblTelNo : mobile
	        					, exSvcGuideAgreeYn : checkMeTerms5
	        			};
	        			
	        			fnApiCall_INF_022("", param, resultApi.INF_022);
	        		}
	        		
		        	if(btnText == "인증번호받기"){
		        		$("#btn_sms_recvAuthNo>span").html("인증번호 다시받기");
		        	}else {
		        	}
		        	setTimeout(function() { 
		        		data.setFlag(true);
		    		}, 500);
		        	
		        	
		        }
		    });
			//sms인증버튼
			$('#btn_sms_authOK').on({
				click :function(event){
					//console.log("g_timerSecond >> " + g_timerSecond);
					if(g_timerSecond == 0){
						fnPOPMessagePopup("SMS_NO_TIME_OUT");
						return;
					}
					if($.trim($("#inp_sms_authNo").val()) == ""){
						fnPOPMessagePopup("SMS_NO_INPUT");
						$("#inp_sms_authNo").focus();
		        		return;
		        	}
					
	    			//통신사
	    			var phoneCorp = $("#slt_sms_mblCmc").val();
	    			//모바일번호
	    			var mobileNo1 = $("#slt_sms_hpNo1").val();
	    			var mobileNo2 = $("#inp_sms_hpNo2").val();
	    			var mobileNo3 = $("#inp_sms_hpNo3").val();
	    			var mobile = mobileNo1+"-"+mobileNo2+"-"+mobileNo3; 
	    			
	    			$("#inp_inf_moAplnCertiMblCoCd").val(phoneCorp);
	    			$("#inp_inf_moAplnCertiMblTelNo").val(mobile);
	    			
					var paramObj = {
							smsNum : $("#inp_sms_authNo").val()
						, certiNum : $("#inp_inf_moAplnCertiKey").val()
						, certiChkKey1 : $("#inp_inf_moAplnCertiKey1").val()
						, certiChkKey2 : $("#inp_inf_moAplnCertiKey2").val()
						, certiChkKey3 : $("#inp_inf_moAplnCertiKey3").val()
						, moRecvNo : $("#smartRecvNo").val()
						, moAplnCertiMblCoCd : phoneCorp
						, moAplnCertiMblTelNo : mobile
						, moAplnCertiKey : $("#inp_inf_moAplnCertiKey").val()
					}
					
					
					fnSmsValidCheck(paramObj, resultApi.INF_023);
					
					/*if(g_smsAuthNo == $("#inp_sms_authNo").val()){
						fnPOPMessagePopup("SMS_AUTH_OK");
						
						var AuthTimer = new $ComTimer()
						if(g_timerID != "undefined" && g_timerID != "" && g_timerID != null){
							AuthTimer.fnStop();
						}
						data.resetSmsData(false,false);
						//인증완료 - 신청자 정보 탭 변경 불가하게
						$("#div_sms_authOK").show();
					}else{
						fnPOPMessagePopup("SMS_AUTH_FAIL");
					}*/
				}
			});
			//계좌인증 버튼
			$('#btn_auto_accNoAuth').on({
				click :function(event){
					//console.log("btn_auto_accNoAuth");
					g_msgObj.title = "";
					g_msgObj.msg1 = "";
					g_msgObj.msg2 = "";
					var bankCd = $("#slt_auto_bankCd").val();
					
					if(!$("#chk_auto_agree").is(":checked")){
						g_msgObj.msg1 = "요금납부자 동의를 체크해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						return;
					}
					if(bankCd == ""){
						g_msgObj.msg1 = "은행명을 선택해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
			        	return;
					}
					if($("#inp_auto_acctNo").val() == ""){
						g_msgObj.msg1 = "계좌번호를 입력해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
			        	return;
					}
					if($("#inp_auto_depOwnNm").val() == ""){
						g_msgObj.msg1 = "납부자명을 입력해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
			        	return;
					}
					if($("#inp_auto_acctJuminBizNo").val() == ""){
						g_msgObj.msg1 = "생년월일/사업자번호를 입력해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
			        	return;
					}
					
					var birthSaupNo = $("#inp_auto_acctJuminBizNo").val();
					if(birthSaupNo.length == 6){
					}else {
						if(!fn_isBusiNoByValue(birthSaupNo)){
							g_msgObj.msg1 = "사업자번호를 확인해주세요.";
	    		        	fnPOPMessagePopup("CUSTOM", g_msgObj);
	    		        	return;
	        			}
					}
					
					var bankCdLen = $("#inp_auto_acctNo").val().length; //계좌번호 길이
					var lastBankCdNum = bankCd.substr(bankCdLen-1);
					/*
					 * 은행별 자릿수 체크
					 * */
					
					if(bankCd == "011"){//농협중앙회
						if(bankCdLen >= 10 && 14 >= bankCdLen){
							g_msgObj.msg1 = "납부방법 자동이체 은행의 계좌번호 자리수가 잘못 입력되었습니다.";
							fnPOPMessagePopup("CUSTOM", g_msgObj);
							return;
						}
						if(bankCdLen == 13){
							if( !(lastBankCdNum == "1" || lastBankCdNum == "2" || lastBankCdNum == "8") ){
								g_msgObj.msg1 = "입력하신 계좌번호는 농협중앙회 계좌가 아닙니다.";
								fnPOPMessagePopup("CUSTOM", g_msgObj);
								return;
							}
						}
					}else if(bankCd == "012"){//단위농협
						if(bankCdLen >= 13 && 14 >= bankCdLen){
							g_msgObj.msg1 = "납부방법 자동이체 은행의 계좌번호 자리수가 잘못 입력되었습니다.";
							fnPOPMessagePopup("CUSTOM", g_msgObj);
							return;
						}
						if(bankCdLen == 13){
							if( !(lastBankCdNum == "3" || lastBankCdNum == "4" || lastBankCdNum == "5" || lastBankCdNum == "9") ){
								g_msgObj.msg1 = "입력하신 계좌번호는 단위농협 계좌가 아닙니다.";
								fnPOPMessagePopup("CUSTOM", g_msgObj);
								return;
							}
						}
					}else if(bankCd == "016"){//축협
						if(bankCdLen != 13){
							g_msgObj.msg1 = "납부방법 자동이체 은행의 계좌번호 자리수가 잘못 입력되었습니다.";
							fnPOPMessagePopup("CUSTOM", g_msgObj);
							return;
						}
					}else if(bankCd == "060"){//B.O.A은행
						if(!bankCd.startsWith("6070")){
							g_msgObj.msg1 = "입력하신 계좌번호는 B.O.A은행 계좌가 아닙니다.";
							fnPOPMessagePopup("CUSTOM", g_msgObj);
							return;
						}
					}else if(bankCd == "003"){//기업은행
						//console.log("bankCdLen >> " + bankCdLen);
						if(bankCdLen != 14){
							g_msgObj.msg1 = "납부방법 자동이체 은행의 계좌번호 자리수가 잘못 입력되었습니다.";
							fnPOPMessagePopup("CUSTOM", g_msgObj);
							return;
						}
					}
					
					if(g_flag){
	        			data.setFlag(false);
						var param = {
								bankCd : $("#slt_auto_bankCd").val()
	        					, acctNo :  $("#inp_auto_acctNo").val()
	        					, depOwnNm : $("#inp_auto_depOwnNm").val()
	        					, acctJuminBizNo : $("#inp_auto_acctJuminBizNo").val()
	        			};
						fnApiCall_INF_016("", param, resultApi.INF_016);
		        	}
		        	data.setFlag(true);
					
				}
			});
			//카드인증
			$('#btn_card_cardAuth').on({
				click :function(event){
					//console.log("btn_card_cardAuth");
					g_msgObj.title = "";
					g_msgObj.msg1 = "";
					g_msgObj.msg2 = "";
					
					if(!$("#chk_card_agree").is(":checked")){
						g_msgObj.msg1 = "요금납부자 동의를 체크해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						return;
					}
					if($("#slt_card_cardComp").val() == ""){
						g_msgObj.msg1 = "카드사를 선택해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						return;
					}
					if($("#inp_card_cardNo1").val().length != 4
							&& $("#inp_card_cardNo2").val().length != 4
							&& $("#inp_card_cardNo3").val().length != 4
							&& $("#inp_card_cardNo4").val().length != 4 ){
						g_msgObj.msg1 = "카드번호를 입력해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						return;
					}
					var cardYYYYMM = $("#inp_card_cardYYYYMM").val();
					if(cardYYYYMM == "" ){
						g_msgObj.msg1 = "카드유효기간을 입력해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						return;
					}
					
					if(!fn_isYearMonth(cardYYYYMM.substr(0,4), cardYYYYMM.substr(4))){
						g_msgObj.msg1 = "카드유효기간을 확인해주세요.";
    		        	fnPOPMessagePopup("CUSTOM", g_msgObj);
    		        	return;
        			}
					var nowDate = fn_getNowDateTime().substr(0,6);//201809
					if(Number(nowDate) > Number(cardYYYYMM)){
						g_msgObj.msg1 = "카드유효기간을 확인해주세요.";
    		        	fnPOPMessagePopup("CUSTOM", g_msgObj);
    		        	return;
					}
					if($("#inp_card_cardNabbNm").val() == "" ){
						g_msgObj.msg1 = "납부자명을 입력해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						return;
					}
					if($("#inp_card_cardJuminBizNo").val() == "" ){
						g_msgObj.msg1 = "생년월일/사업자번호를 입력해주세요.";
			        	fnPOPMessagePopup("CUSTOM", g_msgObj);
						return;
					}
					var birthSaupNo = $("#inp_card_cardJuminBizNo").val();
					if(birthSaupNo.length == 6){
					}else {
						if(!fn_isBusiNoByValue(birthSaupNo)){
							g_msgObj.msg1 = "사업자번호를 확인해주세요.";
	    		        	fnPOPMessagePopup("CUSTOM", g_msgObj);
	    		        	return;
	        			}
					}
					var v_juminNoCheck = "P";
					//$("#inp_custTypeCd").val("6");
					if($("#inp_custTypeCd").val() == "4" || $("#inp_custTypeCd").val() == "5" || $("#inp_custTypeCd").val() == "6"){
						v_juminNoCheck = "C";
					}
					var param = {
							creditCardKindCd : $("#slt_card_cardComp").val()
        					, creditCardNo :  $("#inp_card_cardNo1").val()+""+$("#inp_card_cardNo2").val()+""+$("#inp_card_cardNo3").val()+""+$("#inp_card_cardNo4").val()
        					, creditCardValidPerdDm : $("#inp_card_cardYYYYMM").val()
        					, creditCardOwnerNm : $("#inp_card_cardNabbNm").val()
        					, acctJuminBizNo : $("#inp_card_cardJuminBizNo").val()
        					, juminNoCheck : v_juminNoCheck   //P : 개인, C :법인
        			};
					fnApiCall_INF_017("", param, resultApi.INF_017);
				}
			});
			//개인,사업 > 자동이체
			$("#inp_auto_acctNo, #inp_auto_depOwnNm, #inp_auto_acctJuminBizNo, #slt_auto_bankCd").on("keyup change", function() {
				if($("#slt_auto_bankCd").val() != "" 
					&& $("#inp_auto_acctNo").val() != ""
	        		&& $("#inp_auto_depOwnNm").val() != ""
	        		&& $("#inp_auto_acctJuminBizNo").val() != ""
	        		&& $("#inp_auto_acctNo").val().length >= 10 ){
	        		if( $("#inp_auto_acctJuminBizNo").val().length == 6 || $("#inp_auto_acctJuminBizNo").val().length == 10  ){
	        			fnDisbClass("#btn_auto_accNoAuth", false,"#btn_auto_accNoAuth","", "disabled");
	        		}else{
	        			fnDisbClass("#btn_auto_accNoAuth", true,"#btn_auto_accNoAuth","disabled", "");
	        		}
	        	}else{
	        		fnDisbClass("#btn_auto_accNoAuth", true,"#btn_auto_accNoAuth","disabled", "");
	        	}
				if($("#slt_auto_bankCd").val() == ""){
					$("#inp_auto_acctNo").val("");
					$("#inp_auto_depOwnNm").val("");
					$("#inp_auto_acctJuminBizNo").val("");
				}
				if($("#inp_inf_payAutoCertiResult").val() == "Y" && $("#inp_inf_payAutoCertiTime").val() != ""){
					$("#inp_inf_payAutoCertiResult").val("N");
					$("#inp_inf_payAutoCertiTime").val("");
				}
				/*
				 * 포커스 이동
				 * */
				if($(this).attr("id") == "inp_auto_acctNo"){
					fnNextFocus('inp_auto_acctNo','inp_auto_depOwnNm');
				}
				
			});
			//개인,사업 > 카드인증
			$("#inp_card_cardNo1, #inp_card_cardNo2, #inp_card_cardNo3, #inp_card_cardNo4, #inp_card_cardYYYYMM, #inp_card_cardNabbNm, #inp_card_cardJuminBizNo, #slt_card_cardComp").on("keyup change", function() {
				if($("#slt_card_cardComp").val() != ""
					&& $("#inp_card_cardNo1").val() != ""
					&& $("#inp_card_cardNo2").val() != ""
					&& $("#inp_card_cardNo3").val() != ""
					&& $("#inp_card_cardNo4").val() != ""
					&& $("#inp_card_cardYYYYMM").val() != ""
	        		&& $("#inp_card_cardNabbNm").val() != ""
	        		&& $("#inp_card_cardJuminBizNo").val() != ""){
					
	        		if( $("#inp_card_cardNo1").val().length == 4 
	        				&& $("#inp_card_cardNo2").val().length == 4  
	        				&& $("#inp_card_cardNo3").val().length == 4
	        				&& $("#inp_card_cardNo4").val().length == 4
	        				&& $("#inp_card_cardYYYYMM").val().length == 6){
	        			fnDisbClass("#btn_card_cardAuth", false,"#btn_card_cardAuth","", "disabled");
	        		}else{
	        			fnDisbClass("#btn_card_cardAuth", true,"#btn_card_cardAuth","disabled", "");
	        			return;
	        		}
	        		if( $("#inp_card_cardJuminBizNo").val().length == 6 || $("#inp_card_cardJuminBizNo").val().length == 10  ){
	        			fnDisbClass("#btn_card_cardAuth", false,"#btn_card_cardAuth","", "disabled");
	        		}else{
	        			fnDisbClass("#btn_card_cardAuth", true,"#btn_card_cardAuth","disabled", "");
	        			return;
	        		}
	        		if( $("#inp_card_cardYYYYMM").val().length == 6){
	        			fnDisbClass("#btn_card_cardAuth", false,"#btn_card_cardAuth","", "disabled");
	        		}else{
	        			fnDisbClass("#btn_card_cardAuth", true,"#btn_card_cardAuth","disabled", "");
	        			return;
	        		}
	        	}else{
	        		fnDisbClass("#btn_card_cardAuth", true,"#btn_card_cardAuth","disabled", "");
	        	}
				if($("#inp_inf_payCardCertiResult").val() == "Y" && $("#inp_inf_payCardCertiTime").val() != ""){
					$("#inp_inf_payCardCertiResult").val("N");
					$("#inp_inf_payCardCertiTime").val("");
				}
				
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_card_cardComp"){
					if($(this).val() != ""){
						fnNextFocus("slt_card_cardComp","inp_card_cardNo1");
					}
				}else if($(this).attr("id") == "inp_card_cardNo1"){
					fnNextFocus("inp_card_cardNo1","inp_card_cardNo2");
				}else if($(this).attr("id") == "inp_card_cardNo2"){
					fnNextFocus("inp_card_cardNo2","inp_card_cardNo3");
				}else if($(this).attr("id") == "inp_card_cardNo3"){
					fnNextFocus("inp_card_cardNo3","inp_card_cardNo4");
				}else if($(this).attr("id") == "inp_card_cardNo4"){
					fnNextFocus("inp_card_cardNo4","inp_card_cardYYYYMM");
				}else if($(this).attr("id") == "inp_card_cardYYYYMM"){
					fnNextFocus("inp_card_cardYYYYMM","inp_card_cardNabbNm");
				}
			});
			//요금ㄴ납부자 동의 체크박스
			$("#chk_auto_agree").on("click",function(){
				//console.log("chk_auto_agree : " + $("#chk_auto_agree").is(":checked"));
				
				/*
				 * 데이터 체크
				 * */
				data.nextCheckStep();
			});
			// 요금확인(자동이체) > 이메일
			$("#slt_chkp_email3").on("change",function(){
				fnEmail(this,$("#inp_chkp_email2"));
			});
			//요금확인(자동이체) > 이메일주소
			$("#inp_chkp_email, #inp_chkp_email2, #slt_chkp_email3").on("change", function() {
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(자동이체) > 이메일 > 청구주소
			$('input:radio[name="rdo_chkp_invceAddr"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkp_invceAddr"]:checked').val();
				if(value == "Y"){
					$("#div_chkp_invceAddr").show();
					$("#div_chkp_invceAddrText").show();
					$("#div_chkp_invceAddr2").hide();
				}else{
					$("#div_chkp_invceAddr").hide();
					$("#div_chkp_invceAddrText").hide();
					$("#div_chkp_invceAddr2").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(자동이체) > 이메일 > 현금영수증 발행 신청 탭
			$('input:radio[name="rdo_chkp_cashReceiptYn"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkp_cashReceiptYn"]:checked').val();
				if(value == "0"){
					$("#div_chkp_cashHpNo").show();
				}else{
					$("#div_chkp_cashHpNo").hide();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(자동이체) > 이메일주소 > 현금영수증 핸드폰번호
			$("#slt_chkp_cashHpNo, #inp_chkp_cashHpNo2, #inp_chkp_cashHpNo3").on("keyup change", function() {
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkp_cashHpNo"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkp_cashHpNo","inp_chkp_cashHpNo2");
					}
				}else if($(this).attr("id") == "inp_chkp_cashHpNo2"){
					fnNextFocus("inp_chkp_cashHpNo2","inp_chkp_cashHpNo3");
				}
	        	
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(자동이체) > 이메일주소 > 과세구분선택
			$('input:radio[name="rdo_chkpAuto_email_taxTypeCd"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpAuto_email_taxTypeCd"]:checked').val();
				if(value == "1"){
					$("#div_chkpAuto_email_taxgbnText").hide();
				}else{
					$("#div_chkpAuto_email_taxgbnText").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(자동이체) > 모바일 > 과세구분선택
			$('input:radio[name="rdo_chkpAuto_mobile_taxTypeCd"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpAuto_mobile_taxTypeCd"]:checked').val();
				if(value == "1"){
					$("#div_chkpAuto_mobile_taxgbnText").hide();
				}else{
					$("#div_chkpAuto_mobile_taxgbnText").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(자동이체) > 고지 > 과세구분선택
			$('input:radio[name="rdo_chkpAuto_goji_taxTypeCd"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpAuto_goji_taxTypeCd"]:checked').val();
				if(value == "1"){
					$("#div_chkpAuto_goji_taxgbnText").hide();
				}else{
					$("#div_chkpAuto_goji_taxgbnText").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			
			//요금확인(카드이체) > 모바일 > 요금정보 확인 핸드폰번호 
			$("#slt_chkpAuto_mobile_hpNo1, #inp_chkpAuto_mobile_hpNo2, #inp_chkpAuto_mobile_hpNo3").on("keyup change", function() {
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkpAuto_mobile_hpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkpAuto_mobile_hpNo1","inp_chkpAuto_mobile_hpNo2");
					}
				}else if($(this).attr("id") == "inp_chkpAuto_mobile_hpNo2"){
					fnNextFocus("inp_chkpAuto_mobile_hpNo2","inp_chkpAuto_mobile_hpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(자동이체) > 모바일 > 청구주소
			$('input:radio[name="rdo_chkpAuto_mobile_invceAddr"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpAuto_mobile_invceAddr"]:checked').val();
				if(value == "Y"){
					$("#div_chkpAuto_mobile_invceAddr").show();
					$("#div_chkpAuto_mobile_invceAddrText").show();
					$("#div_chkpAuto_mobile_invceAddr2").hide();
				}else{
					$("#div_chkpAuto_mobile_invceAddr").hide();
					$("#div_chkpAuto_mobile_invceAddrText").hide();
					$("#div_chkpAuto_mobile_invceAddr2").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(자동이체) > 모바일 > 현금영수증 발행 신청 탭
			$('input:radio[name="rdo_chkpAuto_mobile_cashReceiptYn"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpAuto_mobile_cashReceiptYn"]:checked').val();
				if(value == "0"){
					$("#div_chkpAuto_mobile_cashHpNo").show();
				}else{
					$("#div_chkpAuto_mobile_cashHpNo").hide();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(자동이체) > 모바일 > 현금영수증 핸드폰번호 
			$("#slt_chkpAuto_mobile_cashHpNo1, #inp_chkpAuto_mobile_cashHpNo2, #inp_chkpAuto_mobile_cashHpNo3").on("keyup change", function() {
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkpAuto_mobile_cashHpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkpAuto_mobile_cashHpNo1","inp_chkpAuto_mobile_cashHpNo2");
					}
				}else if($(this).attr("id") == "inp_chkpAuto_mobile_cashHpNo2"){
					fnNextFocus("inp_chkpAuto_mobile_cashHpNo2","inp_chkpAuto_mobile_cashHpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(자동이체) > 고지서 > 청구주소
			$('input:radio[name="rdo_chkpAuto_goji_invceAddr"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpAuto_goji_invceAddr"]:checked').val();
				if(value == "Y"){
					$("#div_chkpAuto_goji_invceAddr").show();
					$("#div_chkpAuto_goji_invceAddrText").show();
					$("#div_chkpAuto_goji_invceAddr2").hide();
				}else{
					$("#div_chkpAuto_goji_invceAddr").hide();
					$("#div_chkpAuto_goji_invceAddrText").hide();
					$("#div_chkpAuto_goji_invceAddr2").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(자동이체) > 고지서 > 현금영수증 핸드폰번호
			$("#slt_chkpAuto_goji_cashHpNo1, #inp_chkpAuto_goji_cashHpNo2, #inp_chkpAuto_goji_cashHpNo3").on("keyup change", function() {
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkpAuto_goji_cashHpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkpAuto_goji_cashHpNo1","inp_chkpAuto_goji_cashHpNo2");
					}
				}else if($(this).attr("id") == "inp_chkpAuto_goji_cashHpNo2"){
					fnNextFocus("inp_chkpAuto_goji_cashHpNo2","inp_chkpAuto_goji_cashHpNo3");
				}
				
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			
			
			// 요금확인(자동이체) > 고지서 > 현금영수증 발행 신청 탭
			$('input:radio[name="rdo_chkpAuto_goji_cashReceiptYn"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpAuto_goji_cashReceiptYn"]:checked').val();
				if(value == "0"){
					$("#div_chkpAuto_goji_cashHpNo").show();
				}else{
					$("#div_chkpAuto_goji_cashHpNo").hide();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(카드이체) > 이메일
			$("#slt_chkpCard_email3").on("change",function(){
				fnEmail(this,$("#inp_chkpCard_email2"));
			});
			
			//요금확인(카드이체) > 이메일주소
			$("#inp_chkpCard_email, #inp_chkpCard_email2, #slt_chkpCard_email3").on("change", function() {
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(카드이체) > 이메일 > 청구주소
			$('input:radio[name="rdo_chkpCard_invceAddr"]').on("change",function(){
				//console.log("1");
				var value = $('input:radio[name="rdo_chkpCard_invceAddr"]:checked').val();
				if(value == "Y"){
					$("#div_chkpCard_invceAddr").show();
					$("#div_chkpCard_invceAddrText").show();
					$("#div_chkpCard_invceAddr2").hide();
				}else{
					$("#div_chkpCard_invceAddr").hide();
					$("#div_chkpCard_invceAddrText").hide();
					$("#div_chkpCard_invceAddr2").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(카드이체) > 이메일 > 현금영수증 발행 신청 탭
			$('input:radio[name="rdo_chkpCard_cashReceiptYn"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_cashReceiptYn"]:checked').val();
				if(value == "0"){
					$("#div_chkpCard_cashHpNo").show();
				}else{
					$("#div_chkpCard_cashHpNo").hide();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(카드이체) > 이메일주소 > 현금영수증 핸드폰번호
			$("#slt_chkpCard_cashHpNo, #inp_chkpCard_cashHpNo2, #inp_chkpCard_cashHpNo3").on("keyup change", function() {
				
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkpCard_cashHpNo"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkpCard_cashHpNo","inp_chkpCard_cashHpNo2");
					}
				}else if($(this).attr("id") == "inp_chkpCard_cashHpNo2"){
					fnNextFocus("inp_chkpCard_cashHpNo2","inp_chkpCard_cashHpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(카드이체) > 이메일주소 > 과세구분선택
			$('input:radio[name="rdo_chkpCard_email_taxTypeCd"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_email_taxTypeCd"]:checked').val();
				if(value == "1"){
					$("#div_chkpCard_email_taxgbnText").hide();
				}else{
					$("#div_chkpCard_email_taxgbnText").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(카드이체) > 모바일 > 과세구분선택
			$('input:radio[name="rdo_chkpCard_mobile_taxTypeCd"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_mobile_taxTypeCd"]:checked').val();
				if(value == "1"){
					$("#div_chkpCard_mobile_taxgbnText").hide();
				}else{
					$("#div_chkpCard_mobile_taxgbnText").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(카드이체) > 고지 > 과세구분선택
			$('input:radio[name="rdo_chkpCard_goji_taxTypeCd"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_goji_taxTypeCd"]:checked').val();
				if(value == "1"){
					$("#div_chkpCard_goji_taxgbnText").hide();
				}else{
					$("#div_chkpCard_goji_taxgbnText").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(카드이체) > 모바일 > 요금정보 확인 핸드폰번호 
			$("#slt_chkpCard_mobile_hpNo1, #inp_chkpCard_mobile_hpNo2, #inp_chkpCard_mobile_hpNo3").on("keyup change", function() {
				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkpCard_mobile_hpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkpCard_mobile_hpNo1","inp_chkpCard_mobile_hpNo2");
					}
				}else if($(this).attr("id") == "inp_chkpCard_mobile_hpNo2"){
					fnNextFocus("inp_chkpCard_mobile_hpNo2","inp_chkpCard_mobile_hpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(카드이체) > 모바일 > 청구주소
			$('input:radio[name="rdo_chkpCard_mobile_invceAddr"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_mobile_invceAddr"]:checked').val();
				if(value == "Y"){
					$("#div_chkpCard_mobile_invceAddr").show();
					$("#div_chkpCard_mobile_invceAddrText").show();
					$("#div_chkpCard_mobile_invceAddr2").hide();
				}else{
					$("#div_chkpCard_mobile_invceAddr").hide();
					$("#div_chkpCard_mobile_invceAddrText").hide();
					$("#div_chkpCard_mobile_invceAddr2").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(카드이체) > 모바일 > 현금영수증 발행 신청 탭
			$('input:radio[name="rdo_chkpCard_mobile_cashReceiptYn"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_mobile_cashReceiptYn"]:checked').val();
				if(value == "0"){
					$("#div_chkpCard_mobile_cashHpNo").show();
				}else{
					$("#div_chkpCard_mobile_cashHpNo").hide();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(카드이체) > 모바일 > 현금영수증 핸드폰번호 
			$("#slt_chkpCard_mobile_cashHpNo1, #inp_chkpCard_mobile_cashHpNo2, #inp_chkpCard_mobile_cashHpNo3").on("keyup change", function() {

				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkpCard_mobile_cashHpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkpCard_mobile_cashHpNo1","inp_chkpCard_mobile_cashHpNo2");
					}
				}else if($(this).attr("id") == "inp_chkpCard_mobile_cashHpNo2"){
					fnNextFocus("inp_chkpCard_mobile_cashHpNo2","inp_chkpCard_mobile_cashHpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(카드이체) > 고지서 > 청구주소
			$('input:radio[name="rdo_chkpCard_goji_invceAddr"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_goji_invceAddr"]:checked').val();
				if(value == "Y"){
					$("#div_chkpCard_goji_invceAddr").show();
					$("#div_chkpCard_goji_invceAddrText").show();
					$("#div_chkpCard_goji_invceAddr2").hide();
				}else{
					$("#div_chkpCard_goji_invceAddr").hide();
					$("#div_chkpCard_goji_invceAddrText").hide();
					$("#div_chkpCard_goji_invceAddr2").show();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			// 요금확인(카드이체) > 고지서 > 현금영수증 발행 신청 탭
			$('input:radio[name="rdo_chkpCard_goji_cashReceiptYn"]').on("change",function(){
				var value = $('input:radio[name="rdo_chkpCard_goji_cashReceiptYn"]:checked').val();
				if(value == "0"){
					$("#div_chkpCard_goji_cashHpNo").show();
				}else{
					$("#div_chkpCard_goji_cashHpNo").hide();
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			//요금확인(카드이체) > 고지서 > 현금영수증 핸드폰번호
			$("#slt_chkpCard_goji_cashHpNo1, #inp_chkpCard_goji_cashHpNo2, #inp_chkpCard_goji_cashHpNo3").on("keyup change", function() {

				/*
				 * 포커스이동				 
				 * */
				if($(this).attr("id") == "slt_chkpCard_goji_cashHpNo1"){
					if($(this).val() != ""){
						fnNextFocus("slt_chkpCard_goji_cashHpNo1","inp_chkpCard_goji_cashHpNo2");
					}
				}else if($(this).attr("id") == "inp_chkpCard_goji_cashHpNo2"){
					fnNextFocus("inp_chkpCard_goji_cashHpNo2","inp_chkpCard_goji_cashHpNo3");
				}
				/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataPayFlag").val("Y");
				/*
				 * 데이터 체크
				 * */
				data.nextCheck();
			});
			
			/*
			 * 설치정보 이벤트 체크
			 * */
			$('input[name="inp_install_addr1"],input[name="inp_install_addr2"],input[name="inp_install_addr3"],input[name="inp_installDay"],select[name="slt_installJum"],select[name="slt_installTime"]').on("change",function(){
				//console.log("설치정보 이벤트 체크");
				/*
	        	 * 변경구분
	        	 */ 
	        	$("#inp_nextCheck_dataInstallFlag").val("Y");
	        	//날짜체크 
	        	
	        	
				/*
				 * 데이터 체크
				 */ 
	        	
	        	//setTimeout(function() { 
	        		data.nextCheck();
	        	//}, 100);
	        	
				
			});
		}
	}

var evtSaup = {
	on : function(){
		//사업자 - 고객명, 사업자번호, 대표자명, 법인번호/주민번호 
		$('#inp_saup_custNm, #inp_saup_compNum1, #inp_saup_compNum2, #inp_saup_compNum3, #inp_saup_ceoNm, #inp_saup_corpNm').on({
			keyup :function(event){
	        	if($("#inp_saup_custNm").val() != ""
	        		&& $("#inp_saup_compNum1").val() != ""
	        		&& $("#inp_saup_compNum2").val() != ""
	        		&& $("#inp_saup_ceoNm").val() != ""
	        		&& $("#inp_saup_corpNm").val() != "") {
	        		
	        		if( ($("#inp_saup_compNum1").val().length >= $("#inp_saup_compNum1").attr("maxlength"))
	        			&& ($("#inp_saup_compNum2").val().length >= $("#inp_saup_compNum2").attr("maxlength"))
	        			&& ($("#inp_saup_compNum3").val().length >= $("#inp_saup_compNum3").attr("maxlength"))
	        			&& ($("#inp_saup_corpNm").val().length >= $("#inp_saup_corpNm").attr("maxlength")) ){
	        			fnDisbClass("#btn_saup_custOk", false,"#btn_saup_custOk","", "disabled");
	        		}else{
	        			fnDisbClass("#btn_saup_custOk", true,"#btn_saup_custOk","disabled", "");
	        		}
	        	}
	        	/*
	        	 * 포커스이동				 
	        	 * */
	        	if($(this).attr("id") == "inp_saup_compNum1"){
	        		fnNextFocus("inp_saup_compNum1","inp_saup_compNum2");
	        	}else if($(this).attr("id") == "inp_saup_compNum2"){
	        		fnNextFocus("inp_saup_compNum2","inp_saup_compNum3");
	        	}else if($(this).attr("id") == "inp_saup_compNum3"){
	        		fnNextFocus("inp_saup_compNum3","inp_saup_ceoNm");
	        	}
	        	/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataCustFlag").val("Y");
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
		
    	});
		//사업자 > 대표자 : 대표자명, 대표자주민
		$('#inp_saup_ceoNm2, #inp_saup_juminNo1, #inp_saup_juminNo2').on({
			keyup :function(event){
	        	if($("#inp_saup_ceoNm2").val() != ""
	        		&& $("#inp_saup_juminNo1").val() != ""
	        		&& $("#inp_saup_juminNo2").val() != "") {
	        		
	        		if( ($("#inp_saup_juminNo1").val().length >= $("#inp_saup_juminNo1").attr("maxlength"))
	        			&& ($("#inp_saup_juminNo2").val().length >= $("#inp_saup_juminNo2").attr("maxlength"))
	        			){
	        			fnDisbClass("#btn_saup_custOk2", false,"#btn_saup_custOk2","", "disabled");
	        		}else{
	        			fnDisbClass("#btn_saup_custOk2", true,"#btn_saup_custOk2","disabled", "");
	        		}
	        	}
	        	/*
	        	 * 포커스이동				 
	        	 * */
	        	if($(this).attr("id") == "inp_saup_juminNo1"){
	        		fnNextFocus("inp_saup_juminNo1","inp_saup_juminNo2");
	        	}
	        	
	        	/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataCustFlag").val("Y");
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
    	});
		
		//사업자 > 대표자 본인 : 핸드폰 번호
		$("#slt_saup_hpNo1, #inp_saup_hpNo2, #inp_saup_hpNo3").on("keyup change", function() {
			/*
			 * 포커스이동				 
			 * */
			if($(this).attr("id") == "slt_saup_hpNo1"){
				if($(this).val() != ""){
					fnNextFocus("slt_saup_hpNo1","inp_saup_hpNo2");
				}
			}else if($(this).attr("id") == "inp_saup_hpNo2"){
				fnNextFocus("inp_saup_hpNo2","inp_saup_hpNo3");
			}
			/*
        	 * 변경구분
        	 * */
        	$("#inp_nextCheck_dataCustFlag").val("Y");
			/*
        	 * 데이터 체크
        	 * */
        	data.nextCheck();
		});
		//사업자 > 유선전화번호(선택)
		$("#slt_saup_telNo1, #inp_saup_telNo2, #inp_saup_telNo3").on("keyup change", function() {
			if($(this).attr("id") == "slt_saup_telNo1"){
				if($(this).val() != ""){
					fnNextFocus('slt_saup_telNo1','inp_saup_telNo2');
				}
			}else if($(this).attr("id") == "inp_saup_telNo2"){
				fnNextFocus('inp_saup_telNo2','inp_saup_telNo3');
			}
		});
		//사업자 > 대표자 본인 : 업종구분 업태내용 종목(업종내용)
		$("#slt_saup_compType, #inp_saup_compBiz, #inp_saup_compInds").on("keyup change", function() {
			/*
        	 * 변경구분
        	 * */
        	$("#inp_nextCheck_dataCustFlag").val("Y");
			/*
        	 * 데이터 체크
        	 * */
        	data.nextCheck();
		});
		//사업자 > 대표자 : 핸드폰 번호
		$("#slt_saup_ceoHpNo1, #inp_saup_ceoHpNo2, #inp_saup_ceoHpNo3").on("keyup change", function() {
			/*
			 * 포커스이동				 
			 * */
			if($(this).attr("id") == "slt_saup_ceoHpNo1"){
				if($(this).val() != ""){
					fnNextFocus("slt_saup_ceoHpNo1","inp_saup_ceoHpNo2");
				}
			}else if($(this).attr("id") == "inp_saup_ceoHpNo2"){
				fnNextFocus("inp_saup_ceoHpNo2","inp_saup_ceoHpNo3");
			}
			/*
        	 * 변경구분
        	 * */
        	$("#inp_nextCheck_dataCustFlag").val("Y");
			/*
        	 * 데이터 체크
        	 * */
        	data.nextCheck();
		});
		
		//사업자 > 직원 : 대표자명, 대표자주민
		$('#inp_saup_jig_ceoNm, #inp_saup_jig_juminNo1, #inp_saup_jig_juminNo2').on({
			keyup :function(event){
	        	if($("#inp_saup_jig_ceoNm").val() != ""
	        		&& $("#inp_saup_jig_juminNo1").val() != ""
	        		&& $("#inp_saup_jig_juminNo2").val() != "") {
	        		
	        		if( ($("#inp_saup_jig_juminNo1").val().length >= $("#inp_saup_jig_juminNo1").attr("maxlength"))
	        			&& ($("#inp_saup_jig_juminNo2").val().length >= $("#inp_saup_jig_juminNo2").attr("maxlength"))
	        			){
	        			fnDisbClass("#btn_saup_jig_custOk", false,"#btn_saup_jig_custOk","", "disabled");
	        		}else{
	        			fnDisbClass("#btn_saup_jig_custOk", true,"#btn_saup_jig_custOk","disabled", "");
	        		}
	        	}
	        	/*
	        	 * 변경구분
	        	 * */
	        	$("#inp_nextCheck_dataCustFlag").val("Y");
	        	/*
	        	 * 데이터 체크
	        	 * */
	        	data.nextCheckStep();
	        }
    	});
		//사업자 > 직원 : 핸드폰 번호
		$("#slt_saup_jig_ceoHpNo1, #inp_saup_jig_ceoHpNo2, #inp_saup_jig_ceoHpNo3").on("keyup change", function() {
			/*
        	 * 변경구분
        	 * */
        	$("#inp_nextCheck_dataCustFlag").val("Y");
			/*
        	 * 데이터 체크
        	 * */
        	data.nextCheck();
		});
		//사업자- 고객정보확인 버튼
		$('#btn_saup_custOk').on({
			click :function(event){
	        	//console.log('btn_saup_custOk >> ' + $(this).attr("id"));
	        	if(g_flag){
        			data.setFlag(false);
        			//function fnApiCall_INF_011(v_tartgetId, v_custNm, v_juminBizNo, resultFunc)
        			/*
        			------------------사업자
					# 버튼 클릭 이후 사업자번호에 따라 정보 표시 113-86-41728
						- 01~80, 89~99 : 3 개인사업자 -> 대표자 주민번호 필수입력
						- 81, 82, 85~88 : 4 법인 -> 법인등록번호 필수입력
						
						- 83 : 6 공공기관
						- 84 : 5 외국법인 -> 법인등록번호 필수입력
						
						fn_isBusiNoByValue 사업자번호유효성체크
						fn_isBupinNumber 법인유효성
						inp_saup_compNum1 2 3
					*/	
        			var saupGubun = $("#inp_saup_compNum2").val();
        			var saupNo = $("#inp_saup_compNum1").val()+""+$("#inp_saup_compNum2").val()+""+$("#inp_saup_compNum3").val();
        			if(!fn_isBusiNoByValue(saupNo)){
        				g_msgObj.msg1 = "사업자번호를 확인해주세요";
    		        	fnPOPMessagePopup("CUSTOM", g_msgObj);
    		        	data.setFlag(true);
    		        	return;
        			}
        			if(saupGubun == "83"){
        				/*
        				 * 공공기관
        				 * */
        				$("#inp_custTypeCd").val("6");
        			}else if(saupGubun == "84"){
        				/*
        				 * 외국법인
        				 * */
        				$("#inp_custTypeCd").val("5");
        			}else if(saupGubun == "81" || saupGubun == "82" || saupGubun == "85" || saupGubun == "86" || saupGubun == "87" || saupGubun == "88"){
        				/*
        				 * 법인
        				 * */
        				$("#inp_custTypeCd").val("4");
        			}else{
        				/*
        				 * 개인사업자
        				 * */
        				$("#inp_custTypeCd").val("3");
        			}
        			if($("#inp_custTypeCd").val() == "3"){//개인사업자 - 대표자 주민번호
        				//주민번호 유효성 체크
        				var jumin = $("#inp_saup_corpNm").val();
        				var jumin1 = jumin.substr(0,6);
    	    			var jumin2 = jumin.substr(6);
        				if(!fn_isJuminByVal(jumin1, jumin2)){
        					g_msgObj.msg1 = "주민번호 확인";
        		        	fnPOPMessagePopup("CUSTOM", g_msgObj);
        		        	data.setFlag(true);
        					return;
        				}
        			}else{//그 외 법인번호
        				//법인번호 유효성 체크 
        				if(!fn_isBupinNumber($("#inp_saup_corpNm").val())){
        					g_msgObj.msg1 = "법인번호 확인";
        		        	fnPOPMessagePopup("CUSTOM", g_msgObj);
        		        	data.setFlag(true);
        		        	return;
            			}
        			}
        			fnSaupAuthCofirm("saup", $("#smartRecvNo").val(), $("#inp_saup_custNm").val(), saupNo,$("#inp_saup_ceoNm").val(),$("#inp_saup_corpNm").val(), $("#inp_custTypeCd").val());
	        		//fnApiCall_INF_011("saup",$("#inp_saup_ceoNm").val(),saupNo,resultApi.INF_011);
	        	}
	        	data.setFlag(true);
	        }
	    });
		//사업자 > 직원 - 고객정보확인 버튼(실명인증)(사용안함)
		/*
		 $('#btn_saup_custOk2,#btn_saup_jig_custOk').on({
			click :function(event){
	        	console.log('btn_gae_custOk >> ' + $(this).attr("id"));
	        	if($(this).attr("id") == "btn_saup_custOk2"){
	        		if(g_flag){
	        			data.setFlag(false);
	        			var jumin = $("#inp_saup_juminNo1").val()+""+$("#inp_saup_juminNo2").val();
	        			fnApiCall_INF_010("saup", $("#inp_saup_ceoNm2").val(), jumin, resultApi.INF_010);
		        		//fnApiCall_INF_010("saup", resultApi.INF_010);
		        	}
	        	}else if($(this).attr("id") == "btn_saup_jig_custOk"){
	        		if(g_flag){
	        			data.setFlag(false);
	        			var jumin = $("#inp_saup_jig_juminNo1").val()+""+$("#inp_saup_jig_juminNo2").val();
		        		fnApiCall_INF_010("saup_jig", $("#inp_saup_jig_ceoNm").val(), jumin, resultApi.INF_010);
		        	}
	        	}
	        	
	        	data.setFlag(true);
	        }
	    });
	    */
		//사업자 - 유선전화번호(선택) 체크박스
		$('#chk_saup_telNo').on({
			click :function(event){
	        	//console.log('chk_saup_telNo');
	        		$("#slt_saup_telNo1 option:eq(0)").prop("selected", true);
	        		$("#slt_saup_telNo1").val("");
	        		$("#inp_saup_telNo2").val("");
		        	$("#inp_saup_telNo3").val("");
		        	updateSelectOrDie();
	        }
	    });
		//사업자 - 고객혜택정보제공(선택) 체크박스
		$('#chk_saup_cusInfo').on({
			click :function(event){
	        	//console.log('chk_saup_cusInfo');
	        	/* 전체 Checked 해제 */
	        	$('input[name="chk_saup_cusInfo"]').each(function() {
	        	    $(this).prop('checked', false);
	        	});
	        }
	    });
		//사업자 - 감면(선택) 체크박스
		$('#chk_saup_gam').on({
			click :function(event){
	        	//console.log('chk_saup_gam');
	        	$("#slt_saup_gam option:eq(0)").prop("selected", true);
	        	updateSelectOrDie();
	        }
	    });
	}
}
var result = {
	/*
	 * 개인 확인 Result
	 * */
	CustAuthCofirm : function(result){
		var retCode = result.retCode;
		var retMsg = result.retMsg;
		var target = result.contractReq.targetId;
		
		if(retCode == "SUCC"){
			//성공팝업
			fnPOPMessagePopup("CUST_AUTH_OK");
			
			var rowData = result.retApi;
			var resultNameCheckRes = result.retApi.resultNameCheckRes;  //실명인증 inf010
			var resultCustValidCheckRes = result.retApi.resultCustValidCheckRes; //고객가입가능 확인 inf013
			var resultCustInstallSearchRes = result.retApi.resultCustInstallSearchRes; ////기존 고객정보, 청구정보, 설치정보) inf020
			var resultCustPrdtInfoSearchRes = result.retApi.resultCustPrdtInfoSearchRes; //기존 TV/인터넷 가입계약번호) inf021
			
			
			/*
			 * 설치정보 셋팅
			 * */
			var resultCntrtInfoList = result.retApi.resultCntrtInfoList; //상품정보 - 미리 주소정보 업데이트 
			if(resultCntrtInfoList != null && resultCntrtInfoList.length > 0){
				for(var i=0;i<resultCntrtInfoList.length;i++){
					var index = i;
					$("#inp_addr_"+index).val(resultCntrtInfoList[i].instalPlceZipCd);
					$("#inp_addr2_"+index).val(resultCntrtInfoList[i].instalPlceAddr);
					$("#inp_addr3_"+index).val(resultCntrtInfoList[i].instalPlceSuppAddr);

					$("#inp_refMastAddr_"+index).val(resultCntrtInfoList[i].refMastAddr);
					$("#inp_refSuppAddr_"+index).val(resultCntrtInfoList[i].refSuppAddr);

					$("#inp_addrSeltnTypeCd_"+index).val(resultCntrtInfoList[i].addrSeltnTypeCd);
					$("#inp_addr_jibunAddr_"+index).val(resultCntrtInfoList[i].jibunAddr);  //지번기본주소
					$("#inp_addr_jibunSuppAddr_"+index).val(resultCntrtInfoList[i].jibunSuppAddr);  //지번보조주소

					$("#inp_addr_ktOfceCd_"+index).val(resultCntrtInfoList[i].ktOfceCd);  //KT수용국코드
					$("#inp_addr_ktOfceNm_"+index).val(resultCntrtInfoList[i].ktOfceNm);  //KT수용국코드명
					$("#inp_addr_ktDongCd_"+index).val(resultCntrtInfoList[i].ktDongCd);  //KT동코드

					$("#inp_addr_addrBunjiCl_"+index).val(resultCntrtInfoList[i].addrBunjiCl); //	주소번지유형
					$("#inp_addr_addrBunji_"+index).val(resultCntrtInfoList[i].addrBunji);//번지
					$("#inp_addr_addrHo_"+index).val(resultCntrtInfoList[i].addrHo);//호

					$("#inp_addr_ktBldId_"+index).val(fn_nvl(resultCntrtInfoList[i].ktBldId,""));  //KT건물아이디
					$("#inp_addr_rdNmVrfCd_"+index).val(resultCntrtInfoList[i].rdNmVrfCd); //	도로명검증코드
					$("#inp_addr_rdNmAddr_"+index).val(resultCntrtInfoList[i].rdNmAddr); //	도로명기본주소
					$("#inp_addr_rdNmSuppAddr_"+index).val(resultCntrtInfoList[i].rdNmSuppAddr); //	도로명보조주소
					$("#inp_addr_ktRdNmId_"+index).val(resultCntrtInfoList[i].ktRdNmId);  //kt도로명아이디
					fnSetCertiTime("inp_instalPossDh_" + index);
					fnDisbClass("#btn_installOk_"+index, false, "#btn_installOk_"+index, "", "disabled");
					
					/*
					 * 청구주소 매핑
					 * */
					if(index == "0"){
						var msg = "("+$("#inp_addr_0").val()+") " + $("#inp_addr2_0").val() + " " + $("#inp_addr3_0").val();
						//자동이체 > 이메일
						$("#div_chkp_invceAddrText").show();
						$("#div_chkp_invceAddrText").html(msg);
						//자동이체 > 모바일
						$("#div_chkpAuto_mobile_invceAddrText").show();
						$("#div_chkpAuto_mobile_invceAddrText").html(msg);
						//자동이체 > 고지서
						$("#div_chkpAuto_goji_invceAddrText").show();
						$("#div_chkpAuto_goji_invceAddrText").html(msg);
						
						//카드이체 > 이메일
						$("#div_chkpCard_invceAddrText").show();
						$("#div_chkpCard_invceAddrText").html(msg);
						
						//카드이체 > 모바일
						$("#div_chkpCard_mobile_invceAddrText").show();
						$("#div_chkpCard_mobile_invceAddrText").html(msg);
						
						//카드이체 > 고지서
						$("#div_chkpCard_goji_invceAddrText").show();
						$("#div_chkpCard_goji_invceAddrText").html(msg);
					}/**/
				}
			}
			
			/*
			 * 납부정보
			 * */
			var responseInvceInfoVO = result.retApi.resultCustInstallSearchRes.responseInvceInfoVO;
			//alert(responseInvceInfoVO);
			//div_tab_pay_auto div_tab_pay_card
			if(responseInvceInfoVO != null){
				if(responseInvceInfoVO.payMthCd == "2" || responseInvceInfoVO.payMthCd == "3"){
					if(responseInvceInfoVO.payMthCd == "2"){
						$("#div_tab_pay_card").trigger('click');
					}else{
						$("#div_tab_pay_auto").trigger('click');
						$("#slt_auto_bankCd").val(responseInvceInfoVO.bankCd);
						$("#inp_auto_acctNo").val(responseInvceInfoVO.acctNo);
						$("#inp_auto_depOwnNm").val(responseInvceInfoVO.depOwnNm);
						$("#inp_auto_acctJuminBizNo").val(responseInvceInfoVO.acctJuminBizNo);
						fnDisbClass("#btn_auto_accNoAuth", false,"#btn_auto_accNoAuth","", "disabled");
					}
				}
			}
			
			/*
			 * 개인/사업자별 구분
			 * */
			if(target == "gae"){
				/*
				 * 인증시간 넣기 나중에 대상별로 구분
				 * */
				$("#inp_inf_certiKey").val(resultNameCheckRes.certiKey); //inf010 데이터 실명인증키
				fnSetCertiTime("inp_inf_certiTime");
				/*
				 * 버튼처리
				 * */
				fnDisbClass("#inp_gae_custNm", true, "", "", "");
				fnDisbClass("#inp_gae_juminNo1", true, "", "", "");
				fnDisbClass("#inp_gae_juminNo2", true, "", "", "");
				fnDisbClass("#btn_gae_custOk", true, "#btn_gae_custOk", "disabled", "");
				
				/*
				 * 기존 고객정보
				 * */
				var responseCustInfoVO = resultCustInstallSearchRes.responseCustInfoVO;
				if(resultCustInstallSearchRes.rsltCd == "000"){ 
					//고객설치정보 있음
					$("#inp_inf_custNo").val(responseCustInfoVO.custNo); //inf020 데이터 고객번호
					$("#inp_inf_telNo").val(responseCustInfoVO.telNo); //inf020 데이터 전화번호
					$("#inp_inf_mblTelNo").val(responseCustInfoVO.mblTelNo); //inf020 데이터 모바일번호
					$("#inp_inf_smsRecvYn").val(responseCustInfoVO.smsRecvYn); //inf020 데이터 sms 수신여부  수신여부 0: 수신 , 1 : 미수신
					$("#inp_inf_emailRecvYn").val(responseCustInfoVO.emailRecvYn); //inf020 데이터 이메일 수신여부
					$("#inp_inf_telRecvYn").val(responseCustInfoVO.telRecvYn); //inf020 데이터 전화 수신여부
					$("#inp_inf_reduTypeCd").val(responseCustInfoVO.reduTypeCd); //inf020 데이터 감면구분코드
					//신규-재약정
					$("#inp_moEntrType").val("R");
				}else{
					//신규-재약정
					$("#inp_moEntrType").val("N");
				}
				
				//전화 셋팅
				if(fn_nvl($("#inp_inf_telNo").val(),"") != ""){
					var arrTelNo = $("#inp_inf_telNo").val().split("-");
					$("#slt_gae_telNo1").val(arrTelNo[0]); //개인-전화번호1
					$("#inp_gae_telNo2").val(arrTelNo[1]); //개인-전화번호2
					$("#inp_gae_telNo3").val(arrTelNo[2]); //개인-전화번호3
					//체크박스 - 유선전화번호(선택) 셋팅
					$('input[id="chk_gae_telNo"]').prop('checked', true);
					$("#div_chk_gae_telNo").find(".checkCt").toggle();		
					$("#div_chk_gae_telNo").toggleClass("open");	
				}
				//모바일 셋팅
				if(fn_nvl($("#inp_inf_mblTelNo").val(),"") != ""){
					var arrMblTelNo = $("#inp_inf_mblTelNo").val().split("-");
					$("#slt_gae_hpNo1").val(arrMblTelNo[0]); //개인-핸폰번호1
					$("#inp_gae_hpNo2").val(arrMblTelNo[1]); //개인-핸폰번호2
					$("#inp_gae_hpNo3").val(arrMblTelNo[2]); //개인-핸폰번호3
					//sms인증 모바일 번호 셋팅
					$("#slt_sms_hpNo1").val(arrMblTelNo[0]); //개인sms인증-핸폰번호1
					$("#inp_sms_hpNo2").val(arrMblTelNo[1]); //개인sms인증-핸폰번호2
					$("#inp_sms_hpNo3").val(arrMblTelNo[2]); //개인sms인증-핸폰번호3
				}
				//체크박스 - 고객혜택제공 셋팅
				if($("#inp_inf_smsRecvYn").val() == "0" || $("#inp_inf_emailRecvYn").val() == "0" || $("#inp_inf_telRecvYn").val() == "0"){
					$('input[id="chk_gae_cusInfo"]').prop('checked', true);
					if($("#inp_inf_smsRecvYn").val() == "0"){
						$('input[id="chk_gae_cusInfoSMS"]').prop('checked', true);
					}
					if($("#inp_inf_emailRecvYn").val() == "0"){
						$('input[id="chk_gae_cusInfoEMAIL"]').prop('checked', true);
					}
					if($("#inp_inf_telRecvYn").val() == "0"){
						$('input[id="chk_gae_cusInfoTEL"]').prop('checked', true);
					}
					$("#div_chk_gae_cusInfo").find(".checkCt").toggle();		
					$("#div_chk_gae_cusInfo").toggleClass("open");	
				}
				//감면구분 셋팅
				if($("#inp_inf_reduTypeCd").val() != ""){
					$('input[id="chk_gae_gam"]').prop('checked', true);
					$("#slt_gae_gam").val($("#inp_inf_reduTypeCd").val());
					$("#div_chk_gae_gam").find(".checkCt").toggle();		
					$("#div_chk_gae_gam").toggleClass("open");
					
				}
				//주민
				$("#inp_juminBizNo").val(result.contractReq.juminBizNo);
				//$("#aoz_input_gae_id_camDoc1").attr("placeholder","신분증(주민등록증, 운전면허증, 여권)");
				/*
				 * //aoz 버튼 disabled 처리
				 * */
				fnDisbClass("#aoz_btn_gae_id_cam", true, "#aoz_btn_gae_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_gae_id_camInfoPop", true, "#aoz_btn_gae_id_camInfoPop", "disabled", "");
				
				/*
				 * sms div 보여주기
				 * */
				$("#div_gae_mobile").show();
				
			}else if(target == "gae_fa"){
				/*
				 * 인증시간 셋팅
				 * */
				$("#inp_inf_certiKey2").val(resultNameCheckRes.certiKey);
				fnSetCertiTime("inp_inf_certiTime2");
				/*
				 * 데이터 셋팅
				 * */
				
				
				/*
				 * 버튼처리
				 * */
				fnDisbClass("#inp_gae_fa_custNm", true, "", "", "");
				fnDisbClass("#inp_gae_fa_juminNo1", true, "", "", "");
				fnDisbClass("#inp_gae_fa_juminNo2", true, "", "", "");
				fnDisbClass("#btn_gae_fa_custOk", true, "#btn_gae_fa_custOk", "disabled", "");
				/*
				 * //aoz 버튼 disabled 처리
				 * */
				fnDisbClass("#aoz_btn_gae_fa_id_cam", true, "#aoz_btn_gae_fa_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_gae_fa_id_camInfoPop", true, "#aoz_btn_gae_fa_id_camInfoPop", "disabled", "");
				
				/*
				 * 법정대리인 인증되어있으면 초기화처리
				 * */
				$("#inp_inf_certiKey3").val("");
				$("#inp_inf_certiTime3").val("");
				/*
				 * 법정대리인 버튼 활성화처리
				 * */
				fnDisbClass("#inp_gae_dae_custNm", false, "", "", "");
				fnDisbClass("#inp_gae_dae_juminNo1", false, "", "", "");
				fnDisbClass("#inp_gae_dae_juminNo2", false, "", "", "");
				fnDisbClass("#btn_gae_dae_custOk", false, "#btn_gae_dae_custOk", "", "disabled");
				fnDisbClass("#aoz_btn_gae_dae_id_cam", false, "#aoz_btn_gae_dae_id_cam", "", "disabled");
				fnDisbClass("#aoz_btn_gae_dae_id_camInfoPop", false, "#aoz_btn_gae_dae_id_camInfoPop", "", "disabled");
				
			}else if(target == "gae_dae"){
				
				/*
				 * 인증시간 셋팅
				 * */
				$("#inp_inf_certiKey3").val(resultNameCheckRes.certiKey);
				fnSetCertiTime("inp_inf_certiTime3");
				/*
				 * 데이터 셋팅
				 * */
				/*
				 * 버튼처리
				 * */
				fnDisbClass("#inp_gae_dae_custNm", true, "", "", "");
				fnDisbClass("#inp_gae_dae_juminNo1", true, "", "", "");
				fnDisbClass("#inp_gae_dae_juminNo2", true, "", "", "");
				fnDisbClass("#btn_gae_dae_custOk", true, "#btn_gae_dae_custOk", "disabled", "");
				
				/*
				 * //aoz 버튼 disabled 처리
				 * */
				fnDisbClass("#aoz_btn_gae_dae_id_cam", true, "#aoz_btn_gae_dae_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_gae_dae_id_camInfoPop", true, "#aoz_btn_gae_dae_id_camInfoPop", "disabled", "");
				/*
				 * 가족 인증되어있으면 초기화처리
				 * */
				$("#inp_inf_certiKey2").val("");
				$("#inp_inf_certiTime2").val("");
				/*
				 * 가족 버튼 활성화처리
				 * */
				fnDisbClass("#inp_gae_fa_custNm", false, "", "", "");
				fnDisbClass("#inp_gae_fa_juminNo1", false, "", "", "");
				fnDisbClass("#inp_gae_fa_juminNo2", false, "", "", "");
				fnDisbClass("#btn_gae_fa_custOk", false, "#btn_gae_fa_custOk", "", "disabled");
				fnDisbClass("#aoz_btn_gae_fa_id_cam", false, "#aoz_btn_gae_fa_id_cam", "", "disabled");
				fnDisbClass("#aoz_btn_gae_fa_id_camInfoPop", false, "#aoz_btn_gae_fa_id_camInfoPop", "", "disabled");
				
			}else if(target == "saup"){
				
				
				/*
				 * 인증시간 셋팅
				 * */
				$("#inp_inf_certiKey2").val(resultNameCheckRes.certiKey);
				fnSetCertiTime("inp_inf_certiTime2");
				
				/*
				 * 버튼처리
				 * */
				fnDisbClass("#inp_saup_ceoNm2", true, "", "", "");
				fnDisbClass("#inp_saup_juminNo1", true, "", "", "");
				fnDisbClass("#inp_saup_juminNo2", true, "", "", "");
				fnDisbClass("#btn_saup_custOk2", true, "#btn_saup_custOk2", "disabled", "");
				//렌탈일때만 sms 호출
				//data.resetSmsData(true,false);

				/*
				 * //aoz 버튼 disabled 처리
				 * */
				fnDisbClass("#aoz_btn_saup_id_cam", true, "#aoz_btn_saup_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_saup_id_camInfoPop", true, "#aoz_btn_saup_id_camInfoPop", "disabled", "");
				

				/*
				 * 사업-직원 인증되어있으면 초기화처리
				 * */
				$("#inp_inf_certiKey3").val("");
				$("#inp_inf_certiTime3").val("");
				/*
				 * 사업-직원 버튼 활성화처리
				 * */
				fnDisbClass("#inp_saup_jig_ceoNm", false, "", "", "");
				fnDisbClass("#inp_saup_jig_juminNo1", false, "", "", "");
				fnDisbClass("#inp_saup_jig_juminNo2", false, "", "", "");
				fnDisbClass("#btn_saup_jig_custOk", false, "#btn_saup_jig_custOk", "", "disabled");
				fnDisbClass("#aoz_btn_saup_jig_id_cam", false, "#aoz_btn_saup_jig_id_cam", "", "disabled");
				fnDisbClass("#aoz_btn_saup_jig_id_camInfoPop", false, "#aoz_btn_saup_jig_id_camInfoPop", "", "disabled");
				
			}else if(target == "saup_jig"){
				/*
				 * 인증시간 셋팅
				 * */
				$("#inp_inf_certiKey3").val(resultNameCheckRes.certiKey);
				fnSetCertiTime("inp_inf_certiTime3");
				
				/*
				 * 버튼처리
				 * */
				fnDisbClass("#inp_saup_jig_ceoNm", true, "", "", "");
				fnDisbClass("#inp_saup_jig_juminNo1", true, "", "", "");
				fnDisbClass("#inp_saup_jig_juminNo2", true, "", "", "");
				fnDisbClass("#btn_saup_jig_custOk", true, "#btn_saup_jig_custOk", "disabled", "");
				//렌탈일때만 sms 호출
				//data.resetSmsData(true,false);
				/*
				 * //aoz 버튼 disabled 처리
				 * */
				fnDisbClass("#aoz_btn_saup_jig_id_cam", true, "#aoz_btn_saup_jig_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_saup_jig_id_camInfoPop", true, "#aoz_btn_saup_jig_id_camInfoPop", "disabled", "");

				/*
				 * 사업-대표자 인증되어있으면 초기화처리
				 * */
				$("#inp_inf_certiKey2").val("");
				$("#inp_inf_certiTime2").val("");

				/*
				 * 사업-대표자 버튼 활성화처리
				 * */
				fnDisbClass("#inp_saup_ceoNm2", false, "", "", "");
				fnDisbClass("#inp_saup_juminNo1", false, "", "", "");
				fnDisbClass("#inp_saup_juminNo2", false, "", "", "");
				fnDisbClass("#btn_saup_custOk2", false, "#btn_saup_custOk2", "", "disabled");
				fnDisbClass("#aoz_btn_saup_id_cam", false, "#aoz_btn_saup_id_cam", "", "disabled");
				fnDisbClass("#aoz_btn_saup_id_camInfoPop", false, "#aoz_btn_saup_id_camInfoPop", "", "disabled");
			}
			updateSelectOrDie();
			/*
			 * 신청자 탭구분
			 * */
			ui.tabReqTypeGubun();
		}else{
			if(target == "gae"){
				fnDisbClass("#inp_gae_custNm", false, "", "", "");
				fnDisbClass("#inp_gae_juminNo1", false, "", "", "");
				fnDisbClass("#inp_gae_juminNo2", false, "", "", "");
				fnDisbClass("#btn_gae_custOk", false, "#btn_gae_custOk", "", "disabled");
			}
			//실패팝업
			fnPOPMessagePopup("CUST_AUTH_FAIL");
		}
		/*
    	 * 변경구분
    	 * */
    	$("#inp_nextCheck_dataCustFlag").val("Y");
		/*
		 * 데이터 체크
		 * */
		data.nextCheckStep();
	}
	/*
	 * 사업자 확인 Result
	 * */
	, SaupAuthCofirm : function(result){
		var retCode = result.retCode;
		var retMsg = result.retMsg;
		var target = result.contractReq.targetId;
		
		if(retCode == "SUCC"){
			var retCode = result.retCode;
			var retMsg = result.retMsg;
			var target = result.contractReq.targetId;
			if(retCode == "SUCC"){
				//console.log(retCode);
				var rowData = result.retApi;
				var resultNameCheckRes = rowData.resultNameCheckRes;  //사업자인증 inf011
				
				//disabled 처리
				fnPOPMessagePopup("CUST_AUTH_OK");
				fnDisbClass("#inp_saup_custNm", true, "", "", "");
				fnDisbClass("#inp_saup_compNum1", true, "", "", "");
				fnDisbClass("#inp_saup_compNum2", true, "", "", "");
				fnDisbClass("#inp_saup_compNum3", true, "", "", "");
				fnDisbClass("#inp_saup_ceoNm", true, "", "", "");
				fnDisbClass("#inp_saup_corpNm", true, "", "", "");
				fnDisbClass("#btn_saup_custOk", true, "#btn_saup_custOk", "disabled", "");
				
				
				/*
				 * sms 복사부분
				 * */
				$("#div_saup_mobile").show();
				var smsbox = $('#div_gae_smsAuth');
				var smsOKbox = $('#div_sms_authOK');
				$("#div_saup_smsAuthHome").append(smsbox);
				$("#div_saup_smsAuthHome").append(smsOKbox);	
				data.resetSmsData(true,false);
				//------------------------------------------
				
				//사업자번호 인증키
				$("#inp_inf_certiKey").val(resultNameCheckRes.certiKey);
				fnSetCertiTime("inp_inf_certiTime");
				
				/*
				 * 신청자 탭구분
				 * */
				ui.tabReqTypeGubun();
				
			}
		}
		/*
    	 * 변경구분
    	 * */
    	$("#inp_nextCheck_dataCustFlag").val("Y");
		/*
		 * 데이터 체크
		 * */
		data.nextCheck();
	}, updateSecNumCerti : function(result){
		var retCode = result.retCode;
		var retMsg = result.retMsg;
		var target = result.contractReq.targetId;
		if(retCode == "SUCC"){
			fnPOPMessagePopup("CUST_AUTH_OK");
			$("#inp_juminBizNo").val(result.contractReq.juminBizNo);
			if(target == "gae"){
				
			}
			
			/*
			 * 신청자 탭구분
			 * */
			ui.tabReqTypeGubun();
		}else{
			if(target == "gae"){
				fnDisbClass("#inp_gae_custNm", false, "", "", "");
				fnDisbClass("#inp_gae_juminNo1", false, "", "", "");
				fnDisbClass("#inp_gae_juminNo2", false, "", "", "");
				fnDisbClass("#btn_gae_custOk", false, "#btn_gae_custOk", "", "disabled");
			}
			fnPOPMessagePopup("CUST_AUTH_FAIL");
		}
	}
}
var resultApi = {
	//결과 실명인증
	INF_010 : function(result){
		var rowData = result.retApi;
		var target = result.contractReq.targetId;
		if(rowData.rsltCd == "000"){
			//console.log("result certiKey :: " + rowData.certiKey);
			//disabled 처리
			fnPOPMessagePopup("CUST_AUTH_OK");
			if(target == "gae"){
				/*
				 * 다른거 사용 나중에 삭제
				 * */
				fnDisbClass("#inp_gae_custNm", true, "", "", "");
				fnDisbClass("#inp_gae_juminNo1", true, "", "", "");
				fnDisbClass("#inp_gae_juminNo2", true, "", "", "");
				fnDisbClass("#btn_gae_custOk", true, "#btn_gae_custOk", "disabled", "");
				$("#div_gae_mobile").show();
				//렌탈일때만 sms 호출
				//data.resetSmsData(true,false);
				//inp_inf_certiKey2
				//inp_inf_certiTime2
			}else if(target == "gae_fa"){
				/*
				 * 다른거 사용 나주엥 삭제
				 * */
				fnDisbClass("#inp_gae_fa_custNm", true, "", "", "");
				fnDisbClass("#inp_gae_fa_juminNo1", true, "", "", "");
				fnDisbClass("#inp_gae_fa_juminNo2", true, "", "", "");
				fnDisbClass("#btn_gae_fa_custOk", true, "#btn_gae_fa_custOk", "disabled", "");
				//렌탈일때만 sms 호출
				//data.resetSmsData(true,false);
				//인증키 인증 시간저장
				$("#inp_inf_certiKey2").val(rowData.certiKey);
				fnSetCertiTime("inp_inf_certiTime2");
				
				//aoz 버튼 disabled 처리
				fnDisbClass("#aoz_btn_gae_fa_id_cam", true, "#aoz_btn_gae_fa_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_gae_fa_id_camInfoPop", true, "#aoz_btn_gae_fa_id_camInfoPop", "disabled", "");
				
			}else if(target == "gae_dae"){
				/*
				 * 다른거 사용 나주엥 삭제
				 * */
				fnDisbClass("#inp_gae_dae_custNm", true, "", "", "");
				fnDisbClass("#inp_gae_dae_juminNo1", true, "", "", "");
				fnDisbClass("#inp_gae_dae_juminNo2", true, "", "", "");
				fnDisbClass("#btn_gae_dae_custOk", true, "#btn_gae_dae_custOk", "disabled", "");
				//렌탈일때만 sms 호출
				//data.resetSmsData(true,false);
				//인증키 인증 시간저장
				$("#inp_inf_certiKey3").val(rowData.certiKey);
				fnSetCertiTime("inp_inf_certiTime3");
				
				//aoz 버튼 disabled 처리
				fnDisbClass("#aoz_btn_gae_dae_id_cam", true, "#aoz_btn_gae_dae_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_gae_dae_id_camInfoPop", true, "#aoz_btn_gae_dae_id_camInfoPop", "disabled", "");

				
			}else if(target == "saup"){ //사업자 > 대표 실명인증
				/*
				 * 다른거 사용 나주엥 삭제
				 * */
				fnDisbClass("#inp_saup_ceoNm2", true, "", "", "");
				fnDisbClass("#inp_saup_juminNo1", true, "", "", "");
				fnDisbClass("#inp_saup_juminNo2", true, "", "", "");
				fnDisbClass("#btn_saup_custOk2", true, "#btn_saup_custOk2", "disabled", "");
				//렌탈일때만 sms 호출
				//data.resetSmsData(true,false);
				//console.log("saup rowData.certiKey >>>>>>>" + rowData.certiKey);
				//인증키 인증 시간저장
				$("#inp_inf_certiKey2").val(rowData.certiKey);
				fnSetCertiTime("inp_inf_certiTime2");
				
				//aoz 버튼 disabled 처리
				fnDisbClass("#aoz_btn_saup_id_cam", true, "#aoz_btn_saup_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_saup_id_camInfoPop", true, "#aoz_btn_saup_id_camInfoPop", "disabled", "");
				
			}else if(target == "saup_jig"){ //사업자 > 직원 실명인증
				/*
				 * 다른거 사용 나주엥 삭제
				 * */
				fnDisbClass("#inp_saup_jig_ceoNm", true, "", "", "");
				fnDisbClass("#inp_saup_jig_juminNo1", true, "", "", "");
				fnDisbClass("#inp_saup_jig_juminNo2", true, "", "", "");
				fnDisbClass("#btn_saup_jig_custOk", true, "#btn_saup_jig_custOk", "disabled", "");
				//렌탈일때만 sms 호출
				//data.resetSmsData(true,false);

				//인증키 인증 시간저장
				$("#inp_inf_certiKey3").val(rowData.certiKey);
				fnSetCertiTime("inp_inf_certiTime3");
				
				//aoz 버튼 disabled 처리
				fnDisbClass("#aoz_btn_saup_jig_id_cam", true, "#aoz_btn_saup_jig_id_cam", "disabled", "");
				fnDisbClass("#aoz_btn_saup_jig_id_camInfoPop", true, "#aoz_btn_saup_jig_id_camInfoPop", "disabled", "");
				
			}
			
			
			//실명인증키
			//data.setCustCompAuthKey(rowData.certiKey);
			//$("#inp_inf_certiKey").val(rowData.certiKey);
		}else{
			//alert(rowData.rsltMsg);
			fnPOPMessagePopup("CUST_AUTH_FAIL");
		}
		/*
		 * 데이터 체크
		 * */
		data.nextCheck();
		
	},INF_011 : function(result){
		var rowData = result.retApi;
		var target = result.contractReq.targetId;
		if(rowData.rsltCd == "000"){
			//console.log("result certiKey :: " + rowData.certiKey);
			//disabled 처리
			fnPOPMessagePopup("CUST_AUTH_OK");
			fnDisbClass("#inp_saup_custNm", true, "", "", "");
			fnDisbClass("#inp_saup_compNum1", true, "", "", "");
			fnDisbClass("#inp_saup_compNum2", true, "", "", "");
			fnDisbClass("#inp_saup_compNum3", true, "", "", "");
			fnDisbClass("#inp_saup_ceoNm", true, "", "", "");
			fnDisbClass("#inp_saup_corpNm", true, "", "", "");
			fnDisbClass("#btn_saup_custOk", true, "#btn_saup_custOk", "disabled", "");
			$("#div_saup_mobile").show();
			//렌탈일때만 sms 호출
			//sms 박스 복사하기
			//div_saup_smsAuthHome >  , div_gae_smsAuthHome > div_gae_smsAuth
			 //var smsbox = $('#div_gae_smsAuth');
			 
		        // 떼어내면 DOM에서 제거되기 때문에 .box를 찾을수 없게 된다.
		        //if(box.length) { // 박스가 존재할때만. 
		          //  detachNode = box.detach();  // 캐싱 - 떼어내기 CTRL + X 
		        //}
		        //console.log(detachNode);
			 //console.log(">> : " + $("#div_saup_smsAuthHome").html().length);
			 //console.log(">> : " + $("#div_gae_smsAuthHome").html().length);
			 //$("#div_saup_smsAuthHome").append(smsbox);
			//data.resetSmsData(true,false);
			//사업자번호 인증키
			//data.setCustCompAuthKey(rowData.certiKey);
			
			$("#inp_inf_certiKey").val(rowData.certiKey);
			fnSetCertiTime("inp_inf_certiTime");
		}else{
			//alert(rowData.rsltMsg);
			fnPOPMessagePopup("CUST_AUTH_FAIL");
		}
	}
	//설치주소 가능여부 확인
	, INF_014  : function(result){
		var rowData = result.retApi;
		var target = result.contractReq.targetId;
		//console.log(result.retCode + " <> " + target);
		//if(rowData.rsltCd == "000"){
			fnSetCertiTime("inp_instalPossDh_" + target);
			fnDisbClass("#btn_installOk_"+target, true, "#btn_installOk_"+target, "disabled", "");
			
			/*
			 * 설치점조회
			 * 
			 * */
			var paramObj = {
					instalPlceZipCd : $("#inp_addr_" + target).val() 		//설치우편번호*
					, instalPlceAddr : $("#inp_addr2_" + target).val() 		//설치주소*
					, instalPlceSuppAddr : $("#inp_addr3_" + target).val() 	//설치보조주소*
					, refBaseAddr : fn_nvl($("#inp_addr_rdNmAddr_" + target).val(),$("#inp_refMastAddr_" + target).val())				//참조기본주소	
					, refBaseSuppAddr : fn_nvl($("#inp_addr_rdNmSuppAddr_" + target).val(),$("#inp_refSuppAddr_" + target).val())		//참조보조주소
					, addrSeltnTypeCd : "3" 	//	주소선택구분코드*
					, deptCd : g_sessionUserDeptCd 			//	판매자조직코드*
					, eventNo : fn_nvl($("#inp_eventNo_" + target).val(), $("#inp_prdtCd_" + target).val()) 			//이벤트번호 * 이벤트번호로 SLT유통망 판단
					, tempRsltCd : rowData.rsltCd
					, tempRsltMsg : rowData.rsltMsg
					, tempLoadType : ""
			}
			fnApiCall_INF_025(target, paramObj, resultApi.INF_025);
			
			
		//}else{
		//	g_msgObj.msg1 = rowData.rsltMsg;
        	//fnPOPMessagePopup("CUSTOM", g_msgObj);
			//return;
		//}
	}
	//설치희망일 시간 조회
	, INF_015 : function(result){
		var rowData = result.retApi;
		var target = result.contractReq.targetId;
		if(rowData.rsltCd == "000"){
			var rowDataVO = rowData.responseInstalListVO;
			//var inp_installDay = $("#inp_installDay_"+target).val();
			
			fn_clearComboItems("#slt_installTime_"+target);
			fn_setComboAddItem("#slt_installTime_"+target,MSG.DEFAULT_KEY,"설치 시간을 선택해 주세요.",true);
			for(var i = 0;i < rowDataVO.length;i++){
				if(target,rowDataVO[i].svcOpenDhWithStatCd == "Y"){
					fn_setComboAddItem("#slt_installTime_"+target,rowDataVO[i].svcOpenTime,rowDataVO[i].svcOpenTime,false);
				}
			}
			updateSelectOrDie();
		}else{
			fn_clearComboItems("#slt_installTime_"+target);
			fn_setComboAddItem("#slt_installTime_"+target,MSG.DEFAULT_KEY,"설치 시간을 선택해 주세요.",true);
			updateSelectOrDie();
			g_msgObj.msg1 = rowData.rsltMsg;
        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		}
		/*
		 * 데이터 체크
		 * */
		//data.nextCheck();
	}
	//설치유통망조회 결과
	, INF_025 : function(result){
		var rowData = result.retApi;
		var contractReq = result.contractReq;
		var target = contractReq.targetId;
		//console.log(result.retCode + " <> " + target);
		if(rowData.rsltCd == "000"){
			//contractReq.tempRsltCd : rowData.rsltCd
			//, contractReq.tempRsltMsg : rowData.rsltMsg
			if(fn_nvl(contractReq.tempLoadType,"") != "INIT"){
				if(contractReq.tempRsltCd == "000"){
					g_msgObj.title = "설치 가능 확인 완료";
					g_msgObj.msg1 = "설치가 가능합니다.";
				}else{
					g_msgObj.title = "설치 안내";
					g_msgObj.msg1 = contractReq.tempRsltMsg;
				}
				fnPOPMessagePopup("CUSTOM", g_msgObj);
			}
        	
			//slt_installJum_
			fn_setCombo("#slt_installJum_"+target, rowData.responseCrclNetListVO, "crclNetCd", "crclNetAddr", MSG.DEFAULT_KEY, "설치점을 선택해 주세요.", MSG.DEFAULT_KEY);
			updateSelectOrDie();
			
		}else{
			if(fn_nvl(contractReq.tempLoadType,"") != "INIT"){
				g_msgObj.msg1 = rowData.rsltMsg;
	        	fnPOPMessagePopup("CUSTOM", g_msgObj);
			}
        	//버튼 활성
        	fnDisbClass("#btn_installOk_"+target, false, "#btn_installOk_"+target, "", "disabled");
			return;
		}
	}
	//계좌인증 결과
	, INF_016 : function(result){
		var rowData = result.retApi;
		if(rowData.rsltCd == "000"){
			fnPOPMessagePopup("BANK_AUTH_OK");
			fnDisbClass("#btn_auto_accNoAuth", true, "#btn_auto_accNoAuth", "disabled", "");
			/*
			 * 인증결과정보 보관
			 * */
			fnSetCertiTime("inp_inf_payAutoCertiTime");
			$("#inp_inf_payAutoCertiResult").val("Y");
			$("#inp_nextCheck_dataPayFlag").val("Y");
			
		}else{
			fnPOPMessagePopup("BANK_AUTH_FAIL");
		}
		/*
		 * 데이터 체크
		 * */
		data.nextCheck()
	} 
	//카드인증 결과
	, INF_017 : function(result){
		var rowData = result.retApi;
		if(rowData.rsltCd == "000"){
			fnPOPMessagePopup("CARD_AUTH_OK");
			//$("#slt_custom_card_cardComp").addClass('disabled');
			/*fnDisbClass("#inp_card_cardNo1", true, "", "", "");
			fnDisbClass("#inp_card_cardNo2", true, "", "", "");
			fnDisbClass("#inp_card_cardNo3", true, "", "", "");
			fnDisbClass("#inp_card_cardNo4", true, "", "", "");
			fnDisbClass("#inp_card_cardYYYYMM", true, "", "", "");
			fnDisbClass("#inp_card_cardNabbNm", true, "", "", "");
			fnDisbClass("#inp_card_cardJuminBizNo", true, "", "", "");*/
			fnDisbClass("#btn_card_cardAuth", true, "#btn_card_cardAuth", "disabled", "");
			/*
			 * 인증결과정보 보관
			 * */
			fnSetCertiTime("inp_inf_payCardCertiTime");
			$("#inp_inf_payCardCertiResult").val("Y");
			$("#inp_nextCheck_dataPayFlag").val("Y");
			/*
			 * 요금확인방법
			 * */
			
		}else{
			fnPOPMessagePopup("CARD_AUTH_FAIL");
		}
		/*
		 * 데이터 체크
		 * */
		data.nextCheck()
	}
	//sms 인증번호 발송
	, INF_022 : function(result){
		var rowData = result.retApi;
		if(rowData.rsltCd == "000"){
			//
			//rowData.certiKey
			//console.log("certiNum >>" + rowData.certiNum);//
			//console.log("certiChkKey1 >>" + rowData.certiChkKey1);
			//console.log("certiChkKey2 >>" + rowData.certiChkKey2);
			//console.log("certiChkKey3 >>" + rowData.certiChkKey3);
			
			//타이머 체크
			var AuthTimer = new $ComTimer()
			
			if(g_timerID != "undefined" && g_timerID != "" && g_timerID != null){
				AuthTimer.fnStop();
			}
			g_timerSecond = g_time;
			AuthTimer.comSecond = g_time;
			AuthTimer.fnCallback = function(){
				//alert("다시인증을 시도해주세요.")
			}
			AuthTimer.timer =  setInterval(function(){AuthTimer.fnTimer()},1000);
			AuthTimer.domId = document.getElementById("labe_sms_authNoTime");
			g_timerID = AuthTimer.timer;
			
			/*
			 * 인증번호 시간 출력
			 */
			$("#div_sms_authNoTime").show();
			
			/*
			 * 포커스
			 * */
			//setTimeout(function() { $("#inp_sms_authNo").focus();}, 100);
			
			
			data.setSmsAuthNo(rowData.certiNum); //sms인증번호 셋팅
			fnPOPMessagePopup("SMS_NO_SEND");
			
			/*
			 * 인증키 셋팅
			 * */
			$("#inp_inf_moAplnCertiKey").val(rowData.certiNum);
			$("#inp_inf_moAplnCertiKey1").val(rowData.certiChkKey1);
			$("#inp_inf_moAplnCertiKey2").val(rowData.certiChkKey2);
			$("#inp_inf_moAplnCertiKey3").val(rowData.certiChkKey3);
			fnSetCertiTime("inp_inf_moAplnCertiDh");
		}else{
			g_msgObj.msg1 = rowData.rsltMsg;
        	fnPOPMessagePopup("CUSTOM", g_msgObj);
		}
	}
	//sms 인증번호 확인
	, INF_023 : function(result){
		var rowData = result.retApi;
		if(rowData.rsltCd == "000"){
			fnPOPMessagePopup("SMS_AUTH_OK");

			var AuthTimer = new $ComTimer()
			if(g_timerID != "undefined" && g_timerID != "" && g_timerID != null){
				AuthTimer.fnStop();
			}
			data.resetSmsData(false,false);
			//인증완료 - 신청자 정보 탭 변경 불가하게
			$("#div_sms_authOK").show();
			//sms인증 코드
			$("#inp_moAplnCertiTypeCd").val("01");
		}else{
			fnPOPMessagePopup("SMS_AUTH_FAIL");
		}
		
		/*
		 * 데이터 체크
		 * */
		data.nextCheck()
	}
	
}


function $ComTimer(){
    //prototype extend
}

$ComTimer.prototype = {
    comSecond : ""
    , fnCallback : function(){}
    , timer : ""
    , domId : ""
    , fnTimer : function(){
        //var m = "("+Math.floor(this.comSecond / 60) + ":" + (this.comSecond % 60) + ")";	// 남은 시간 계산
    	var m = Math.floor(this.comSecond / 60);
    	var s = (this.comSecond % 60);
    	
        var mText = "0"+m;
        var sText = 10 > s ? "0"+s : s;
        var msText = "("+mText+":"+sText+")";
        
        g_timerSecond = this.comSecond--;					// 1초씩 감소
         
        this.domId.innerText = msText;
        if (this.comSecond < 0) {			// 시간이 종료 되었으면..
            clearInterval(this.timer);		// 타이머 해제
            g_timerSecond = 0;
           // alert("인증번호 유효시간이 지났습니다. 인증번호를 다시 받아주세요");
            fnPOPMessagePopup("SMS_AUTH_TIME");
            
        }
    },fnStop : function(){
        clearInterval(g_timerID);
    }
}




function fnSetCertiTime(targetId){
	$("#" + targetId).val(fn_getNowDateTime());
}

function fnEmail(obj,targetObj){
	if ($("#" + obj.id + " option:selected").text() == "직접입력") {//99
		$(targetObj).attr("disabled",false);
		$(targetObj).val("");
		$(targetObj).focus();
	}
	else {
		$(targetObj).attr("disabled",true);
		//$(targetObj).val($("#" + obj.id + " option:selected").text());
		$(targetObj).val($("#" + obj.id + " option:selected").val());
	}
}
function fnNextFocus(selectId, nextId){
	var sltMaxLen = fn_nvl($("#"+selectId).attr("maxlength"),0);
	if($("#"+selectId).val().length >= sltMaxLen){
		$("#"+nextId).focus();
	}
			
	
}
function updateSelectOrDie(){
	setTimeout(function() { 
		$("select").selectOrDie("update");
	}, 10);
}
