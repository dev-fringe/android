var controller = $.extend(new $.CommonObj(), {
	eventInit : function() {

		$(document).on("keypress keyup blur", "#custNm", function(e) {
			inputChk();
		});

		$(document).on("keypress keyup blur", "#juminBizNoView", function(e) {
			var juminView = $("#juminBizNoView").val();
			var juminNo = $("#juminBizNo").val();
			
			if(juminNo.length > juminView.length){ //입력값 삭제
				$("#juminBizNoView").val(juminNo.substring(0,juminView.length));
				$("#juminBizNo").val($("#juminBizNoView").val());
			} else if(juminNo.length < juminView.length){ //입력값 추가
				$("#juminBizNo").val(juminView);
				
				if(juminView.length == 13){
					var pattern = /.{6}$/;
					var maskValue = juminView.replace(pattern,"******");
					$("#juminBizNoView").val(maskValue);
				}
			} else {
				//return false;
			}
			inputChk();
		});

		$(document).on("change", "#recvRegrDh", function(e) {
			var recvRegrDh = $("#recvRegrDh").val();
			
			if(!fn_isNull(recvRegrDh)){
				$("#btnRecvSearch2").addClass("red").removeClass("disabled");
			} else {
				$("#btnRecvSearch2").removeClass("red").addClass("disabled");				
			}
			$("#custNm").val("");
			$("#juminBizNo").val("");
		});

		$(document).on("click", "#btnRecvSearch1", function(e) {
			
			if ($.trim($("#custNm").val()) == "") {
				alert("고객명을 입력하세요.");
				$("#custNm").focus();
				return;
			}

			if ($.trim($("#juminBizNo").val()) == "") {
				alert("주민등록번호를 입력하세요.");
				$("#juminBizNo").focus();
				return;
			} else {
				var biznum = $.trim($("#juminBizNo").val());
				if (!(biznum.length == 10 || biznum.length == 13)) {
					alert("주민등록번호 자릿수를 확인하세요.");
					$("#juminBizNoView").focus();
					return;
				}
			}
			
			var formData = {
				custNm : $("#custNm").val(),
				juminBizNo : $("#juminBizNo").val(),
				recvNo : $("#recvNo").val()
			};
			getReceiptPaperListHtml(formData);
		});

		$(document).on("click", "#btnRecvSearch2", function(e) {
			var datenum = $.trim($("#recvRegrDh").val());
			if (datenum.length != 10) {
				alert("접수일을 확인하세요.");
				$("#recvRegrDh").focus();
				return;
			}

			var formData = {
				recvRegrDh : $("#recvRegrDh").val()
			};
			getReceiptPaperListHtml(formData);
		});

	}
});

$(document).ready(function(){
	controller.init();
});

function inputChk(){
	var custNm = $("#custNm").val();
	var juminBizNo = $("#juminBizNo").val();
	
	if( !fn_isNull(custNm) && !fn_isNull(juminBizNo) && juminBizNo.length >= 10 ){
		$("#btnRecvSearch1").addClass("red").removeClass("disabled");
	} else {
		$("#btnRecvSearch1").removeClass("red").addClass("disabled");				
	}
	$("#recvRegrDh").val("");
}

function getReceiptPaperListHtml(formData) {
	controller.ajaxSend({
		url:contextPath + '/contract/receiptPaperListHtml.do',
		data: formData,
		dataType:'html',
		type : 'post',
		isBlock:true,
		async:true,
		isOverLap:true,
		successCall:function(jsonObj){
			if(jsonObj.trim() == 'LOGIN'){
				goLogin();
				return false;
			}
			$("#receiptPaperList").html(jsonObj);
		}
	});
}

function cancelMoRecv(recvNo){
	$("#searchConfirmTitle").text("가입신청취소(철회) 안내");
	$("#searchConfirmText").html("가입신청을 취소(철회)하시겠습니까?");
	$("#searchConfirmBtnName").text("가입신청취소(철회)");
	$("#searchConfirmParam").val(recvNo);
	searchConfirm();
}

function cancelMoRecvProc(recvNo){
	var param = {"moRecvNo" : recvNo};
	
    controller.ajaxSend( {
		url : contextPath + '/contract/cancelScisReceiptInfo.json'
		, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var retCode = result.retCode;
			var retMsg = result.retMsg;
			if (retCode == "SUCC") {
				$("#searchPopupTitle").text("가입신청취소(철회) 처리 완료");
				$("#searchPopupText").html("가입신청이 취소(철회)되었습니다.");
				$("#searchPopupMsg").html("");
				$("#searchPopupBtnName").text("확인");
				searchPopup();
			} else {
				$("#searchPopupTitle").text("가입신청취소(철회) 처리 실패");
				$("#searchPopupText").html("가입신청이 취소(철회)가 실패하였습니다.");
				$("#searchPopupMsg").html("실패사유:"+retMsg);
				$("#searchPopupBtnName").text("확인");
				searchPopup();
			}
		}
    });
}

function detVeiewMoRecv(recvNo){

	var formData = {
			"moRecvNo" : recvNo,
			"dispType" : "popup"
	};
	
	controller.ajaxSend({
		url:contextPath + '/contract/receiptContractResultHtml.do',
		data: formData,
		dataType:'html',
		type : 'post',
		isBlock:true,
		async:true,
		isOverLap:true,
		successCall:function(jsonObj){
			if(jsonObj.trim() == 'LOGIN'){
				goLogin();
				return false;
			}
			$("#receiptPaperPopup").html(jsonObj);
		}
	});
	receiptPaperPopup();
}

function receiptPaperPopup(){
	$("#receiptPaperPopup").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}

function reUpdateMoRecv(recvNo){
	$("#searchConfirmTitle").text("가입신청서 재등록 안내");
	$("#searchConfirmText").html("가입신청서를 재등록 하시겠습니까?<br>(기존 등록한 정보 변경 가능)");
	$("#searchConfirmBtnName").text("가입신청서 재등록");
	$("#searchConfirmParam").val(recvNo);
	searchConfirm();
}

function reUpdateMoRecvProc(recvNo){
	var param = {"moRecvNo" : recvNo};
	
    controller.ajaxSend( {
		url : contextPath + '/contract/reUpdateReceiptInfo.json'
		, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var retCode = result.retCode;
			var retMsg = result.retMsg;
			if(retMsg == null || retMsg == ''){
				retMsg = result.RES.returnMsg; 
			}
			if (retCode == "SUCC") {
				var newRecvNo = result.newRecvNo;
				$("#searchPopupTitle").text("가입신청서 재등록 완료");
				$("#searchPopupText").html("가입신청서가 재등록되었습니다.<br>변경된 내용을 다시 입력해 주세요.");
				$("#searchPopupMsg").html("");
				$("#searchPopupParam").val(newRecvNo);
				$("#searchPopupBtnName").text("확인");
				searchPopup();
			} else {
				$("#searchPopupTitle").text("가입신청서 재등록 실패");
				$("#searchPopupText").html("가입신청서 재등록이 실패하였습니다.");
				$("#searchPopupMsg").html("실패사유:"+retMsg);
				$("#searchPopupBtnName").text("확인");
				searchPopup();
			}
		}
    });
}

function deleteMoRecv(recvNo){
	$("#searchConfirmTitle").text("작성중 삭제 안내");
	$("#searchConfirmText").html("작성중인 가입신청 정보를 삭제하시겠습니까?");
	$("#searchConfirmBtnName").text("삭제하기");
	$("#searchConfirmParam").val(recvNo);
	searchConfirm();
}

function deleteMoRecvProc(recvNo){

	var param = {'moRecvNo':recvNo};
	
    controller.ajaxSend( {
		url : contextPath + '/contract/deleteReceiptInfo.json'
		, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var retCode = result.retCode;
			var retMsg = result.retMsg;
			if (retCode == "SUCC") {
				var newRecvNo = result.newRecvNo;
				$("#searchPopupTitle").text("삭제 완료");
				$("#searchPopupText").html("작성중인 가입신청 정보가 모두 삭제되었습니다.");
				$("#searchPopupMsg").html("");
				$("#searchPopupBtnName").text("확인");
				searchPopup();
			} else {
				$("#searchPopupTitle").text("삭제 실패");
				$("#searchPopupText").html("작성중인 가입신청 정보 삭제가 실패하였습니다.");
				$("#searchPopupMsg").html(""); //"실패사유:"+retMsg);
				$("#searchPopupBtnName").text("확인");
				searchPopup();
			}
		}
    });
}

function updateMoRecv(recvNo){
	//alert("가입신청서 작성:"+recvNo);
	var formOption = {
			"action" : contextPath + "/contract/updateMoRecv.do",
		};
	controller.createForm(formOption);
	controller.attachHiddenElement('moRecvNo', recvNo);
	controller.formSubmit();
}

function searchConfirm(){
	$("#searchConfirm").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}

$(document).on("click", "#searchConfirmBtnName", function() {
	$("#searchConfirm").bPopup().close();
	$('body').removeClass('bodyHold');
	var getTitle = $("#searchConfirmTitle").text();
	var recvNo = $("#searchConfirmParam").val();
	if(getTitle == '가입신청취소(철회) 안내'){
		cancelMoRecvProc(recvNo);
	} else if(getTitle == '가입신청서 재등록 안내'){
		reUpdateMoRecvProc(recvNo);
	} else if(getTitle == '작성중 삭제 안내'){
		deleteMoRecvProc(recvNo);
	} else {}
});

function searchPopup(){
	$("#searchPopup").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}

$(document).on("click", "#searchPopupBtnName", function() {
	$("#searchPopup").bPopup().close();
	$('body').removeClass('bodyHold');
	var getTitle = $("#searchPopupTitle").text();
	var newRecvNo = $("#searchPopupParam").val();
	if(getTitle == '가입신청취소(철회) 처리 완료'){
		top.location.reload();
	} else if(getTitle == '가입신청서 재등록 완료'){
		updateMoRecv(newRecvNo);
	} else if(getTitle == '삭제 완료'){
		location.reload();
	} else {}
});
