var controller = $.extend(new $.CommonObj(), {
	eventInit : function() {
		var param = {
				moRecvNo : $("#moRecvNo").val()
		}
		
		controller.ajaxSend({
			url: contextPath + '/contract/receiptContractResultHtml.do',
			data: param,
			dataType:'html',
			type : 'post',
			isBlock:true,
			async:true,
			isOverLap:true,
			successCall:function(jsonObj){
				$("#receiptContractResultHtml").html(jsonObj);
			}
		});
	},
});

$(document).ready(function(){
	controller.init();

	if ($("#popEmailDomain").val() != "") {
		$('#popEmailDomainInput').prop('disabled', true);
	}
	
	$('select').on('change', function() {
		if(this.value == '99'){
		  $('#popEmailDomainInput').val('');
		  $('#popEmailDomainInput').prop('disabled', false);
		}else{
  		  $('#popEmailDomainInput').val('');
		  $('#popEmailDomainInput').val(this.value);
		  $('#popEmailDomainInput').prop('disabled', true);
		}
	});
}); // ready

function goMain(){
	location.href = contextPath + "/main.do";
}
function getEmailPop(){
	$("#getEmailPop").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function sendEmailValid(){
	if($('#popEmailId').val() == ''){
		$("#title").text('이메일로 받기');
		$("#message").text('아이디를 입력해주세요');
		$("#popup").bPopup({
			modalClose: false,
			onOpen: function(){ $('body').addClass('bodyHold'); },
			onClose: function(){ $('body').removeClass('bodyHold');
			$('#popEmailId').focus();
			}
		});
		
		return;
	}
	if($('#popEmailDomainInput').val() == ''){
		$("#title").text('이메일로 받기');
		$("#message").text('도메인을 입력 해주세요.');
		$("#popup").bPopup({
			modalClose: false,
			onOpen: function(){ $('body').addClass('bodyHold'); },
			onClose: function(){ $('body').removeClass('bodyHold');
			$('#popEmailDomainInput').focus();
			}
		});
		
		return;
	}

	$("#emailConfirm").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function sendEmail(){
	var param = {}
	param["id"] = $('#popEmailId').val();
	param["domain"] = $('#popEmailDomainInput').val();
	param["moRecvNo"] = $('#moRecvNo').val();
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : contextPath + '/sendMail.json',
		data : JSON.stringify(param),
		dataType : 'json'
//		timeout : 100000
	}).done(function(data) {
		var stat = data.status;
		var msg = data.message;
		
//		if(StringUtils.hasText(message) && "true".equals(message)){
//			return new SuccessResponse(null, message);
//		}else{
//			return new ErrorResponse(400,message);
//		}
		
		if (stat == '400') {
			$("#title").text('이메일 발송 에러');
			$("#message").text(msg);
			$("#popup").bPopup({
				modalClose: false,
				onOpen: function(){ $('body').addClass('bodyHold'); },
				onClose: function(){ $('body').removeClass('bodyHold'); }
			});
		} else {
			$("#emailComp").bPopup({
				onOpen: function(){ $('body').addClass('bodyHold'); },
				onClose: function(){ $('body').removeClass('bodyHold'); }
			});
		}
	});	
}
