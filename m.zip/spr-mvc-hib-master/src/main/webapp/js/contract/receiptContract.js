var g_flag = true;	 


$(document).ready(function(){
	controller.beforeInit();
	controller.init();
});

$(window).on('load', function(){
	controller.afterLoad();
});


var controller = $.extend(new $.CommonObj(), {
	beforeInit : function() {
		console.log('beforeInit');
		
		data.init();
		event.init();
		ui.init();
	},
	eventInit : function() {
		console.log('eventInit');
		
		
		
		//다음스텝
		$('#btnNextStepAdd, #btnNextStepCfm, #btnNextStepTerms').on({
	        click :function(event){
	        	console.log("btnNextStepAdd : " + $(this).attr("id") + " <> " + g_flag);
        		if($(this).attr("id") == "btnNextStepAdd"){
        			if(g_flag){
            			data.setFlag(false);
            			fnNextStepAdd($(this).attr("id"));
            		}
    	        	data.setFlag(true);
        		}else if($(this).attr("id") == "btnNextStepCfm"){
        			if(g_flag){
            			data.setFlag(false);
            			fnNextStepCfm($(this).attr("id"));
            		}
    	        	data.setFlag(true);
        		}else if($(this).attr("id") == "btnNextStepTerms"){
        			if(g_flag){
            			data.setFlag(false);
            			fnNextStepTerms($(this).attr("id"));
            		}
    	        	data.setFlag(true);
        		}
	        	
	        	
	        }
	    });
		//이전스텝
		$('#btnPrevStepCfm, #btnPrevStepTerms').on({
	        click :function(event){
	        	console.log("btnPrevStepCfm : " + $(this).attr("id"));
	        	ui.prevPage($(this).attr("id"));
	        }
	    });
		
	}//eventInit
	, afterLoad : function() {
		
	}

});
var $form = $('<form></form>');
function fnNextStepTerms(targetId){
	$form = $('<form></form>');
	$form.attr('method', 'post');
    $form.appendTo('body');
    
    /*
     * 다음페이지 열기
     * */
    ui.nextPage(targetId);
}

function fnNextStepCfm(targetId){
	$form = $('<form></form>');
	$form.attr('method', 'post');
    $form.appendTo('body');
    
    /*
     * 다음페이지 열기
     * */
    ui.nextPage(targetId);
}
function fnNextStepAdd(targetId){
	console.log('fnNextStepAdd');
	
	$form = $('<form></form>');
	$form.attr('method', 'post');
    $form.appendTo('body');
    
    
    /*
     * 실행 처리후 성공 후 
     * */
	console.log('divTv : ' + g_tvSize);
	console.log('divInt : ' + g_intSize);
	console.log('divRental2_ : ' + g_rentalSize);
	
	/*
	 * TV 일경우 등록처리
	 * */
	if(Number(g_tvSize) > 0){
		
		/*
		 * 수신기(장비일경우에는 장비컬럼만체크)(장비)
		 * */
		
		data.setCustInfoData("tv","");
		fn_addHidden($form, "exTypeCd", "EQUIP_CL_CD");
		fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호				
		fn_addHidden($form, "exPrdtGrpCd", MSG.DUMMY); //부가상품유형코드
		fn_addHidden($form, "exPrdtCd", MSG.DUMMY); 	//부가상품코드
		fn_addHidden($form, "exPrdtNm", MSG.DUMMY); 	//부가상품명
		fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
		fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
		fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
		fn_addHidden($form, "exPrdtTypeCd", "01");//부가상품구분코드 - 인터넷인 경우	02 : 프로모션	03 : AP	05 : 패밀리	- TV인 경우	01 : 상품
		fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
		fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
		fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
		fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
		fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
		fn_addHidden($form, "equipClCd", "1"); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
		fn_addHidden($form, "equipId", $("#slta_tv_susingi").val());//장비아이디
		fn_addHidden($form, "equipNm", $("#slta_tv_susingi option:checked").text());	//장비명
		fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
		fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
		fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	////장비요율일련번호 BigDecimal
		fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
		
		
		/* 
		 * 안테나(장비)
		 * */
		data.setCustInfoData("tv","");
		fn_addHidden($form, "exTypeCd", "EQUIP_CL_CD");
		fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호				
		fn_addHidden($form, "exPrdtGrpCd", MSG.DUMMY); //부가상품유형코드
		fn_addHidden($form, "exPrdtCd", MSG.DUMMY); 	//부가상품코드
		fn_addHidden($form, "exPrdtNm", MSG.DUMMY); 	//부가상품명
		fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
		fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
		fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
		fn_addHidden($form, "exPrdtTypeCd", "01");//부가상품구분코드 - 인터넷인 경우	02 : 프로모션	03 : AP	05 : 패밀리	- TV인 경우	01 : 상품
		fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
		fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
		fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
		fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
		fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
		fn_addHidden($form, "equipClCd", "3"); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
		fn_addHidden($form, "equipId", $("#slta_tv_annte").val());//장비아이디
		fn_addHidden($form, "equipNm", $("#slta_tv_annte option:checked").text());	//장비명
		fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
		fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
		fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	////장비요율일련번호 BigDecimal
		fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
		
		/*
		 * 구글홈 미니 제휴서비스 및 추가혜택 (보여주기용) 구글홈미니 연관(장비)
		 * */		
		data.setCustInfoData("tv","");
		fn_addHidden($form, "exTypeCd", "EQUIP_CL_CD");
		fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호				
		fn_addHidden($form, "exPrdtGrpCd", MSG.DUMMY); //부가상품유형코드
		fn_addHidden($form, "exPrdtCd", MSG.DUMMY); 	//부가상품코드
		fn_addHidden($form, "exPrdtNm", MSG.DUMMY); 	//부가상품명
		fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
		fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
		fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
		fn_addHidden($form, "exPrdtTypeCd", "01");//부가상품구분코드 - 인터넷인 경우	02 : 프로모션	03 : AP	05 : 패밀리	- TV인 경우	01 : 상품
		fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
		fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
		fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
		fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
		fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
		fn_addHidden($form, "equipClCd", "K"); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
		
		if($("#rdoa_tv_googleSpG").is(":checked")){
			fn_addHidden($form, "equipId", "Google Home Mini-BL");//장비아이디
			fn_addHidden($form, "equipNm", "Google Home Mini-블랙");	//장비명
		}else if($("#rdoa_tv_googleSpB").is(":checked")){
			fn_addHidden($form, "equipId", "Google Home Mini-GR");//장비아이디
			fn_addHidden($form, "equipNm", "Google Home Mini-그레이");	//장비명
		}else{
			fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
			fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
		}
		
		fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
		fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
		fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	////장비요율일련번호 BigDecimal
		fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
		
		/*
		 * 프리미엄 채널 exTypeCd : CHRG_ITEM_CD(상품)
		 * */
		//
		if($("#chka_tv_prmChSlt").is(":checked")){
			$('input[name="chka_tv_prmCh"]').each(function() {
	    	    //$(this).prop('checked', false);
				var value = $(this).val();
				var checked = $(this).prop("checked");
				var text = $(this).next().text();
				if(checked){
					data.setCustInfoData("tv","");
					fn_addHidden($form, "exTypeCd", "EX_PRDT_TYPE_CD");
					fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호				
					fn_addHidden($form, "exPrdtGrpCd", "CHRG_ITEM_CD"); //부가상품유형코드
					fn_addHidden($form, "exPrdtCd", value); 	//부가상품코드
					fn_addHidden($form, "exPrdtNm", text); 	//부가상품명
					fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
					fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
					fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
					fn_addHidden($form, "exPrdtTypeCd", "01");//부가상품구분코드 - 인터넷인 경우	02 : 프로모션	03 : AP	05 : 패밀리	- TV인 경우	01 : 상품
					fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
					fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
					fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
					fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
					fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
					fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
					fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
					fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
					fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
					fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
					fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	////장비요율일련번호 BigDecimal
					fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
				}
	    	});
		}
		
		
		/*
		 * 부가서비스 exTypeCd : PRODUCT_KIND (상품)
		 * */
		if($("#chka_tv_extraS").is(":checked")){
			$('input[name="chka_tv_extraPvrS"]').each(function() {
	    	    //$(this).prop('checked', false);
				var value = $(this).val();
				var checked = $(this).prop("checked");
				var text = $(this).next().text();
				if(checked){
					if($("#slta_tv_extraS").val() == "18"){
						data.setCustInfoData("tv","");
						fn_addHidden($form, "exTypeCd", "EX_PRDT_TYPE_CD");
						fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호				
						fn_addHidden($form, "exPrdtGrpCd", "PVR"); //부가상품유형코드
						fn_addHidden($form, "exPrdtCd", value); 	//부가상품코드
						fn_addHidden($form, "exPrdtNm", text); 	//부가상품명
						fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
						fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
						fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
						fn_addHidden($form, "exPrdtTypeCd", "01");//부가상품구분코드 - 인터넷인 경우	02 : 프로모션	03 : AP	05 : 패밀리	- TV인 경우	01 : 상품
						fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
						fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
						fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
						fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
						fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
						fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
						fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
						fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
						fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
						fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
						fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	////장비요율일련번호 BigDecimal
						fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
					}else{
						
					}
					
				}
	    	});
		}
	} //tv
	
	/*
	 * 인터넷 일경우 등록처리
	 * */
	if(Number(g_intSize) > 0){
		
		
		/*
		 * 프로모션(선택)
		 * */
		
		if($("#chka_int_promo").is(":checked")){
			data.setCustInfoData("int","");
			fn_addHidden($form, "exTypeCd", "EX_PRDT_TYPE_CD");
			fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호		
			fn_addHidden($form, "exPrdtGrpCd", MSG.SPACE); //부가상품유형코드
			fn_addHidden($form, "exPrdtCd", $("#slta_int_promo").val()); 	//부가상품코드
			fn_addHidden($form, "exPrdtNm", $("#slta_int_promo option:checked").text()); 	//부가상품명
			fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
			fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
			fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
			fn_addHidden($form, "exPrdtTypeCd", "02");//부가상품구분코드 - 인터넷인 경우 프로모션(02) AP(03)	 패밀리(05)   	- TV인 경우	01 : 상품
			fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
			fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
			fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
			fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
			fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
			fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
			fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
			fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
			fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
			fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
			fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	//장비요율일련번호 BigDecimal
			fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
		}
		
		/*
		 * 할인(선택)
		 * */
		if($("#chka_int_sale").is(":checked")){
			data.setCustInfoData("int","");
			fn_addHidden($form, "exTypeCd", "EX_PRDT_TYPE_CD");
			fn_addHidden($form, "exScrbrNo", $("#slta_int_sale2").val());		//부가가입계약번호		
			fn_addHidden($form, "exPrdtGrpCd", MSG.SPACE); //부가상품유형코드
			fn_addHidden($form, "exPrdtCd", $("#slta_int_sale").val()); 	//부가상품코드
			fn_addHidden($form, "exPrdtNm", $("#slta_int_sale option:checked").text()); 	//부가상품명
			fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
			fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
			fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
			fn_addHidden($form, "exPrdtTypeCd", "02");//부가상품구분코드 - 인터넷인 경우 프로모션(02) AP(03)	 패밀리(05)   	- TV인 경우	01 : 상품
			fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
			fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
			fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
			fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
			fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
			fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
			fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
			fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
			fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
			fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
			fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	//장비요율일련번호 BigDecimal
			fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
		}
		/*
		 * 부가서비스(선택)
		 * */
		if($("#chka_int_bugaSlt").is(":checked")){
			$('input[name="chka_int_buga"]').each(function() {
	    	    //$(this).prop('checked', false);
				var value = $(this).val();
				var checked = $(this).prop("checked");
				var text = $(this).next().text();
				if(checked){
					data.setCustInfoData("int","");
					fn_addHidden($form, "exTypeCd", "EX_PRDT_TYPE_CD");
					fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호		
					fn_addHidden($form, "exPrdtGrpCd", "EX_PRDT_CD"); //부가상품유형코드
					fn_addHidden($form, "exPrdtCd", value); 	//부가상품코드
					fn_addHidden($form, "exPrdtNm", text); 	//부가상품명
					fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
					fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
					fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
					fn_addHidden($form, "exPrdtTypeCd", "04");//부가상품구분코드 - 인터넷인 경우 프로모션(02) AP(03)	 패밀리(05)   	- TV인 경우	01 : 상품
					fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
					fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
					fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
					fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
					fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
					fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
					fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
					fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
					fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
					fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
					fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	//장비요율일련번호 BigDecimal
					fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
				}
			});
			
		}
		/*
		 * AP(선택)
		 * */
		if($("#chka_int_ap").is(":checked")){
			data.setCustInfoData("int","");
			fn_addHidden($form, "exTypeCd", "EX_PRDT_TYPE_CD");
			fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호		
			fn_addHidden($form, "exPrdtGrpCd", MSG.SPACE); //부가상품유형코드
			fn_addHidden($form, "exPrdtCd", $("#slta_int_ap").val()); 	//부가상품코드
			fn_addHidden($form, "exPrdtNm", $("#slta_int_ap option:checked").text()); 	//부가상품명
			fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
			fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
			fn_addHidden($form, "exDutyUseCd", $("#slta_int_ap3").val()); 	//부가상품약정기간		
			fn_addHidden($form, "exPrdtTypeCd", "03");//부가상품구분코드 - 인터넷인 경우 프로모션(02) AP(03)	 패밀리(05)   	- TV인 경우	01 : 상품
			fn_addHidden($form, "moExInstmCd", "12"); 	//일시불할부구분
			fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
			fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
			fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
			fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
			fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
			fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
			fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
			fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
			fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
			fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	//장비요율일련번호 BigDecimal
			fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
		}
		//부가서비스 없을 경우
		if(!$("#chka_int_promo").is(":checked") && 
			!$("#chka_int_sale").is(":checked") &&
			!$("#chka_int_bugaSlt").is(":checked") && 
			!$("#chka_int_ap").is(":checked") ){
			data.setCustInfoData("int","");
			data.setSpaceCntrExInfo();
		}
		
		
		
		//exTypeCd		//부가정보유형코드 EQUIP_CL_CD	장비,     EX_PRDT_TYPE_CD	상품/프로모션/AP/패밀리
		// TV 프리미엄채널(유료) : "CHRG_ITEM_CD" -> CD_CL = "NB001" 의 값들에 대한 그룹
		//- TV 부가서비스 : "PRODUCT_KIND" -> CD_CL = "MM004" 의 값들에 대한 그룹
		//- TV PRV 패키지 : "PVR"
		//- 인터넷 부가서비스 : "EX_PRDT_CD"
		/*
		 - 상품/이벤트 : 
			 EX_PRDT_TYPE_CD - 인터넷인 경우 02 : 프로모션 03 : AP 05 : 패밀리              - TV인 경우 01 : 상품
			 EX_PRDT_CD
			 EX_PRDT_NM
			 EX_DUTY_USE_CD
			 MO_EX_INSTM_CD
			 MO_EX_MONTH_INVCE_AMT
			 MO_EX_TOT_INVCE_AMT
			 MO_EX_LSE_AMT
			 UPPR_SCRBR_NO
			    - 장비 : 
			 EX_PRDT_TYPE_CD
			 EX_PRDT_CD
			 EX_PRDT_NM
			 EQUIP_CL_CD
			 EQUIP_ID
			 EQUIP_NM
			 EQUIP_MODEL_NO
			 EQUIP_MODEL_NM
			 EQUIP_RATE_SEQ_NO
						
					*/
	}//int
	
	/*
	 * 렌탈일 경우
	 * */
	if(Number(g_rentalSize) > 0){
		for(var i=0;i < Number(g_rentalSize);i++){
			data.setCustInfoData("ren", i);
			fn_addHidden($form, "exTypeCd", MSG.DUMMY);
			fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호		
			fn_addHidden($form, "exPrdtGrpCd", MSG.SPACE); //부가상품유형코드
			fn_addHidden($form, "exPrdtCd", MSG.DUMMY); 	//부가상품코드
			fn_addHidden($form, "exPrdtNm", MSG.DUMMY); 	//부가상품명
			fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
			fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
			fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
			fn_addHidden($form, "exPrdtTypeCd", "99");//부가상품구분코드 - 인터넷인 경우02 : 프로모션	03 : AP	05 : 패밀리   	- TV인 경우	01 : 상품
			fn_addHidden($form, "moExInstmCd", MSG.DUMMY); 	//일시불할부구분
			fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
			fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
			fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
			fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
			fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
			fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
			fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
			fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
			fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
			fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	////장비요율일련번호 BigDecimal
			fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
			/*
			if("".equals(StringHelper.nvl(smartContractAddReq.getExPrdtTypeCd()[i]))){
			if("".equals(StringHelper.nvl(smartContractAddReq.getExPrdtCd()[i]))){
			if("".equals(StringHelper.nvl(smartContractAddReq.getExPrdtNm()[i]))){
			if("".equals(StringHelper.nvl(smartContractAddReq.getExDutyUseCd()[i]))){
			if("".equals(StringHelper.nvl(smartContractAddReq.getMoExInstmCd()[i]))){
			if("".equals(StringHelper.nvl(smartContractAddReq.getMoExMonthInvceAmt()[i]))){
			if("".equals(StringHelper.nvl(smartContractAddReq.getMoExTotInvceAmt()[i]))){
			if("".equals(StringHelper.nvl(smartContractAddReq.getMoExLseAmt()[i]))){
			}*/
			
		}
		
	}//rental
	
	
	var formData = $form.serialize();
    var ajaxController = {
        init: function() {
            this.type = "post";
            this.url = "";
            this.data =  formData;
            this.dataType = "json";
        },
        start: function() {
        	var result = null;
            $.ajax({
                async: false,
                url: this.url,
                type: this.type,
                data: this.data,
                dataType: this.dataType,
                success: function (json) {
                    result = json;
                },
            });
            return result;
        }
    };
    
    
    ajaxController.init();
    ajaxController.url = contextPath + "/contract/saveReceiptContractAddTv.json"; //TV 체크
    var resultTV = ajaxController.start();
    if(resultTV.retCode == "SUCC"){
    	console.log("resultTV:" + resultTV.retCode);
    	
    	/*
    	 * 다음 페이지 열기
    	 * */
    	
    	ui.nextPage(targetId);
    }else{
    	g_msgObj.msg1 = resultTV.retMsg
    	fnPOPMessagePopup("CUSTOM", g_msgObj);
    }
	
	
	
}


var data = {
	init : function (){
		console.log('contract init');
	}, setFlag : function (flag){
		g_flag = flag;
	}, setSpaceCntrExInfo : function (){
		fn_addHidden($form, "exTypeCd", MSG.DUMMY);
		fn_addHidden($form, "exScrbrNo", MSG.SPACE);		//부가가입계약번호		
		fn_addHidden($form, "exPrdtGrpCd", MSG.SPACE); //부가상품유형코드
		fn_addHidden($form, "exPrdtCd", MSG.DUMMY); 	//부가상품코드
		fn_addHidden($form, "exPrdtNm", MSG.DUMMY); 	//부가상품명
		fn_addHidden($form, "exEventNo", MSG.DUMMY); 	//
		fn_addHidden($form, "exEventNm", MSG.DUMMY); 	//
		fn_addHidden($form, "exDutyUseCd", MSG.DUMMY); 	//부가상품약정기간		
		fn_addHidden($form, "exPrdtTypeCd", "02");//부가상품구분코드 - 인터넷인 경우02 : 프로모션	03 : AP	05 : 패밀리   	- TV인 경우	01 : 상품
		fn_addHidden($form, "moExInstmCd", MSG.DUMMY); 	//일시불할부구분
		fn_addHidden($form, "moExMonthInvceAmt", MSG.DUMMY); 	//할부금액
		fn_addHidden($form, "moExTotInvceAmt", MSG.DUMMY); 	//일시불납부액
		fn_addHidden($form, "moExLseAmt", MSG.DUMMY); 	//임대료
		fn_addHidden($form, "upprScrbrNo", MSG.DUMMY); //모가입계약번호
		fn_addHidden($form, "equipClCd", MSG.SPACE); //장비유형코드 "1" : 수신기  - "3" : 안테나  - "F" : 모뎀  - "G" : AP  - "H" : 모뎀(LTE)  - "K" : 구글홈미니
		fn_addHidden($form, "equipId", MSG.SPACE);//장비아이디
		fn_addHidden($form, "equipNm", MSG.SPACE);	//장비명
		fn_addHidden($form, "equipModelNo", MSG.SPACE);	//장비모델번호
		fn_addHidden($form, "equipModelNm", MSG.SPACE);	//장비모델명
		fn_addHidden($form, "equipRateSeqNo", MSG.DUMMY);	////장비요율일련번호 BigDecimal
		fn_addHidden($form, "moEquipAmt", MSG.DUMMY);	//
	}, setCustInfoData : function (gubun, index){
		if(gubun == "tv"){
			//고객정보(단일)
			fn_addHidden($form, "prdtTypeCd", MSG.TV_KEY);
			fn_addHidden($form, "moRecvNo", fn_nvl($("#smartRecvNo").val(),"")); 	//스마트청약접수번호 key	
			fn_addHidden($form, "moScrbrNo", fn_nvl($("#inpa_tv_moScrbrNo").val(),MSG.SPACE)); //스마트청약가입계약번호 key
			fn_addHidden($form, "moExScrbrNo", MSG.SPACE);//스마트청약부가가입계약번호 key
			
			fn_addHidden($form, "recvNo", MSG.SPACE);	//접수번호
			fn_addHidden($form, "scrbrNo", MSG.SPACE);	//가입계약번호
							
			fn_addHidden($form, "prdtCd", fn_nvl($("#inpa_tv_eventNo").val(),MSG.SPACE));			
			fn_addHidden($form, "prdtNm", fn_nvl($("#inpa_tv_eventNm").val(),MSG.SPACE));		
			fn_addHidden($form, "eventNo", fn_nvl($("#inpa_tv_eventNo").val(),MSG.SPACE));			
			fn_addHidden($form, "eventNm", fn_nvl($("#inpa_tv_eventNm").val(),MSG.SPACE));		
			
			fn_addHidden($form, "recvMthCd", $("#slta_tv_susinType").val()); //수신방식
			fn_addHidden($form, "instalClCd", $("#slta_tv_installType").val());	//설치유형
			fn_addHidden($form, "instalPlceBldClCd", $("#slta_tv_buildingType").val()); //건물유형
			fn_addHidden($form, "recvRegionTypeCd", $("#slta_tv_susinCity").val()); //수신지역구분
			//이동체구분(선택)
			fn_addHidden($form, "imapTypeCd", MSG.SPACE); //이동체구분코드
			fn_addHidden($form, "imapMgmtNo", MSG.SPACE);	//이동체관리번호
			fn_addHidden($form, "etcEntrTypeCd", $("#slta_tv_ispType").val());	//인터넷서비스제공자
			fn_addHidden($form, "ipSvcAgreeYn", "1");	//인터넷/dcs연결동의여부
			
			fn_addHidden($form, "entrClCd", $("#slta_tv_joinType").val()); //가입유형코드
			fn_addHidden($form, "entrPathCd", $("#slta_tv_joinPath").val()); //가입경로코드	
			fn_addHidden($form, "remark", "메모");	//메모
			fn_addHidden($form, "moMultiCnt", "1");	//복수가입수량
				
			fn_addHidden($form, "collAgncyCd", $("#slta_tv_mojip").val());	//모집점코드
			fn_addHidden($form, "collAgncyNm", "모집점명");//모집점명
			fn_addHidden($form, "relScrbrNo", "01"); //관련가입계약번호 1. 상품정보 - 홈 렌탈	o 기존 가입계약번호
		}else if(gubun == "int"){
			fn_addHidden($form, "prdtTypeCd", MSG.INT_KEY);
			fn_addHidden($form, "moRecvNo", fn_nvl($("#smartRecvNo").val(),"")); 	//스마트청약접수번호 key	
			fn_addHidden($form, "moScrbrNo", fn_nvl($("#inpa_int_moScrbrNo").val(),MSG.SPACE)); //스마트청약가입계약번호 key
			fn_addHidden($form, "moExScrbrNo", MSG.SPACE);//스마트청약부가가입계약번호 key
			
			fn_addHidden($form, "recvNo", MSG.SPACE);	//접수번호
			fn_addHidden($form, "scrbrNo", MSG.SPACE);	//가입계약번호
					
							
			fn_addHidden($form, "prdtCd", fn_nvl($("#inpa_int_eventNo").val(),MSG.SPACE));			
			fn_addHidden($form, "prdtNm", fn_nvl($("#inpa_int_eventNm").val(),MSG.SPACE));		
			fn_addHidden($form, "eventNo", fn_nvl($("#inpa_int_eventNo").val(),MSG.SPACE));			
			fn_addHidden($form, "eventNm", fn_nvl($("#inpa_int_eventNm").val(),MSG.SPACE));		
			
			fn_addHidden($form, "recvMthCd", MSG.SPACE); //수신방식
			fn_addHidden($form, "instalClCd", $("#slta_int_installType").val());	//설치유형
			fn_addHidden($form, "instalPlceBldClCd", $("#slta_int_buildingType").val()); //건물유형
			fn_addHidden($form, "recvRegionTypeCd", MSG.SPACE); //수신지역구분
			//이동체구분(선택)
			fn_addHidden($form, "imapTypeCd", MSG.SPACE); //이동체구분코드
			fn_addHidden($form, "imapMgmtNo", MSG.SPACE);	//이동체관리번호
			fn_addHidden($form, "etcEntrTypeCd", MSG.SPACE);	//인터넷서비스제공자
			fn_addHidden($form, "ipSvcAgreeYn", MSG.SPACE);	//인터넷/dcs연결동의여부
			
			fn_addHidden($form, "entrClCd", $("#slta_int_joinType").val()); //가입유형코드
			fn_addHidden($form, "entrPathCd", $("#slta_int_joinPath").val()); //가입경로코드	
			fn_addHidden($form, "remark", "메모");	//메모
			fn_addHidden($form, "moMultiCnt", "1");	//복수가입수량
				
			fn_addHidden($form, "collAgncyCd", fn_nvl($("#slta_int_mojip").val(),MSG.DUMMY));	//모집점코드
			fn_addHidden($form, "collAgncyNm", "모집점명");//모집점명
			fn_addHidden($form, "relScrbrNo", "01"); //관련가입계약번호 1. 상품정보 - 홈 렌탈	o 기존 가입계약번호
		}else if(gubun == "ren"){
			fn_addHidden($form, "prdtTypeCd", MSG.REN_KEY);
			fn_addHidden($form, "moRecvNo", fn_nvl($("#smartRecvNo").val(),"")); 	//스마트청약접수번호 key	
			fn_addHidden($form, "moScrbrNo", fn_nvl($("#inpa_ren_"+index+"_moScrbrNo").val(),MSG.SPACE)); //스마트청약가입계약번호 key
			fn_addHidden($form, "moExScrbrNo", MSG.SPACE);//스마트청약부가가입계약번호 key
			
			fn_addHidden($form, "recvNo", MSG.SPACE);	//접수번호
			fn_addHidden($form, "scrbrNo", MSG.SPACE);	//가입계약번호
					
							
			fn_addHidden($form, "prdtCd", fn_nvl($("#inpa_ren_"+index+"_prdtCd").val(),MSG.SPACE));			
			fn_addHidden($form, "prdtNm", fn_nvl($("#inpa_ren_"+index+"_prdtNm").val(),MSG.SPACE));		
			fn_addHidden($form, "eventNo", fn_nvl($("#inpa_ren_"+index+"_prdtCd").val(),MSG.SPACE));			
			fn_addHidden($form, "eventNm", fn_nvl($("#inpa_ren_"+index+"_prdtNm").val(),MSG.SPACE));		
			
			fn_addHidden($form, "recvMthCd", MSG.SPACE); //수신방식
			fn_addHidden($form, "instalClCd", MSG.SPACE);	//설치유형
			fn_addHidden($form, "instalPlceBldClCd", MSG.SPACE); //건물유형
			fn_addHidden($form, "recvRegionTypeCd", MSG.SPACE); //수신지역구분
			//이동체구분(선택)
			fn_addHidden($form, "imapTypeCd", MSG.SPACE); //이동체구분코드
			fn_addHidden($form, "imapMgmtNo", MSG.SPACE);	//이동체관리번호
			fn_addHidden($form, "etcEntrTypeCd", MSG.SPACE);	//인터넷서비스제공자
			fn_addHidden($form, "ipSvcAgreeYn", MSG.SPACE);	//인터넷/dcs연결동의여부
			
			fn_addHidden($form, "entrClCd", MSG.SPACE); //가입유형코드
			fn_addHidden($form, "entrPathCd", MSG.SPACE); //가입경로코드	
			fn_addHidden($form, "remark", "메모");	//메모
			fn_addHidden($form, "moMultiCnt", "1");	//복수가입수량
				
			fn_addHidden($form, "collAgncyCd", MSG.SPACE);	//모집점코드
			fn_addHidden($form, "collAgncyNm", MSG.SPACE);//모집점명
			fn_addHidden($form, "relScrbrNo", fn_nvl($("#slta_ren_"+index+"_joinNo").val(),MSG.SPACE)); //관련가입계약번호 1. 상품정보 - 홈 렌탈	o 기존 가입계약번호
		}
	}
}

var event = {
	init : function (){
		
	}
}
var ui = {
	init : function (){
		
	}
	//다음
	, nextPage : function (targetId){
		if(targetId == "btnNextStepAdd"){
			$("#section_contract_add").hide();
			$("#section_contract_cfm").show();
			$("#section_contract_terms").hide();
		}else if(targetId == "btnNextStepCfm"){
			$("#section_contract_add").hide();
			$("#section_contract_cfm").hide();
			$("#section_contract_terms").show();
		}else if(targetId == "btnNextStepTerms"){
			window.location.replace(contextPath + '/contract/receiptContractResult.do?moRecvNo=' + $("#smartRecvNo").val());
			return;
		}	
		
		fnScrollTopMove("wrap");
	} 
	//이전
	, prevPage : function (targetId){
		if(targetId == "btnPrevStepCfm"){
			$("#section_contract_add").show();
			$("#section_contract_cfm").hide();
			$("#section_contract_terms").hide();
		}else if(targetId == "btnPrevStepTerms"){
			$("#section_contract_add").hide();
			$("#section_contract_cfm").show();
			$("#section_contract_terms").hide();
		}
		fnScrollTopMove("wrap");
	} 
}