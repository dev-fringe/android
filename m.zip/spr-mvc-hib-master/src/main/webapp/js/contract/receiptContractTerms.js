

$(document).ready(function(){
	
	dataT.init();
	eventT.init();
	uiT.init();
});

$(window).on('load', function(){
});





var dataT = {
	init : function (){
		console.log('contract dataT');
	}
}

var eventT = {
	init : function (){
		
	}
}
var uiT = {
	init : function (){
		
	} 
}