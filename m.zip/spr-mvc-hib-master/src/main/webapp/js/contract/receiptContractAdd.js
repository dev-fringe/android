

$(document).ready(function(){
	
	dataA.init();
	eventA.init();
	uiA.init();
});

$(window).on('load', function(){
});





var dataA = {
	init : function (){
		console.log('contract dataA');
	}
}

var eventA = {
	init : function (){
		
	}
}
var uiA = {
	init : function (){
		
	} 
}