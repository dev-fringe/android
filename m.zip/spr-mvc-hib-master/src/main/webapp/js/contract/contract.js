var MSG = new Object();
//셀렉트 박스 기본
MSG.SPACE = " ";
MSG.TEMP = "";
MSG.DUMMY = "0";
MSG.DEFAULT = "선택해주세요";
MSG.DEFAULT_KEY = "TTII";
MSG.MONTH = 12;


MSG.TV_KEY = "01";
MSG.INT_KEY = "02";
MSG.REN_KEY = "03";

MSG.ALERT_PROD_SELECT = "상품을 선택해주세요.";
MSG.ALERT_PROD_EVENT_SELECT = "상품명(이벤트명)을 선택해주세요.";
MSG.ALERT_PROD_DEL_LIMIT = "상품은 1개 이상 선택되야 하므로, 삭제가 불가능 합니다.";
MSG.ALERT_RENTAL_EA_LIMIT = "홈 렌탈 상품 동시가입 가능 개수 초과.";
MSG.ALERT_RENTAL_OUTPUT = "출력제한.";


MSG.CMM_KEY = "cd";
MSG.CMM_KEY_NAME = "cdNm";

//api 코드
MSG.API_RSLTCD = "000"; //인터페이스 리턴코드 : 정상

MSG.API_CODE_MM089 = "상품그룹코드";
MSG.API_CODE_MM089_KEY = "MM089";

MSG.API_CODE_MM107 = "이벤트상품그룹코드";
MSG.API_CODE_MM107_KEY = "MM107";

MSG.API_CODE_MM170 = "의무가입기간코드";
MSG.API_CODE_MM170_KEY = "MM170";

MSG.API_CODE_MM179 = "이벤트상품그룹코드-인터넷 상품종류";
MSG.API_CODE_MM179_KEY = "MM179";

MSG.API_CODE_CM417 = "렌탈접수유형코드";
MSG.API_CODE_CM417_KEY = "CM417";

MSG.API_CODE_CM440 = "가전결합판매처코드";
MSG.API_CODE_CM440_KEY = "CM440";

MSG.API_CODE_CM471 = "에러코드조회";
MSG.API_CODE_CM471_KEY = "CM471";

//db 메모리 코드
MSG.MEM_CODE_CONTENT_MAIN_TV = "CONTENT_MAIN_TV";
MSG.MEM_CODE_CONTENT_MAIN_INTERNET = "CONTENT_MAIN_INTERNET";
MSG.MEM_CODE_INTERNET_2001 = "93";
MSG.MEM_CODE_INTERNET_2002 = "94";
MSG.MEM_CODE_INTERNET_2003 = "92";
MSG.MEM_CODE_INTERNET_2004 = "91";
MSG.MEM_CODE_INTERNET_2005 = "95";
MSG.MEM_CODE_CONTENT_MAIN_RENTAL = "CONTENT_MAIN_RENTAL";
MSG.MEM_CODE_RENTAL_SELLER_CD = "RENTAL_SELLER_CD";
MSG.MEM_CODE_DUTY_USE_PERD = "DUTY_USE_PERD";
MSG.MEM_CODE_CELLPHONE_PREFIX = "CELLPHONE_PREFIX";
MSG.MEM_CODE_CELLPHONE_PREFIX = "TELEPLHOE_PREFIX";


//체크코드
MSG.CHK_JUMIN_OK = "JUMIN_OK";
MSG.CHK_JUMIN_ERROR = "JUMIN_ERROR";
MSG.CHK_NATION_KO = "KO";
MSG.CHK_NATION_FO = "FO";
MSG.CHK_ADULT_OK = "ADULTOK";
MSG.CHK_ADULT_NO = "ADULTNO";
MSG.CHK_SEX_M = "SEXM";
MSG.CHK_SEX_W = "SEXW";

//수용국 스크롤 전역
MSG.LAND_NUM = true;
MSG.LAND_ADDR = true;
var g_msgObj = {title : "", msg1 : "", msg2 : ""};
/*
var g_appl_1_reqdDoc1 = {}; //신청자구비서류1 
var g_appl_1_reqdDoc2 = {}; //신청자구비서류2 
var g_appl_1_reqdDoc3 = {}; //신청자구비서류3 
var g_appl_1_reqdDoc4 = {}; //신청자구비서류4 
var g_appl_1_reqdDoc5 = {}; //신청자구비서류5 
var g_appl_1_reqdDoc6 = {}; //신청자구비서류6
var g_appl_1_reqdDoc7 = {}; //신청자구비서류7
var g_appl_1_reqdDoc8 = {}; //신청자구비서류8

var g_appl_2_reqdDoc1 = {}; //신청자구비서류1 
var g_appl_2_reqdDoc2 = {}; //신청자구비서류2 
var g_appl_2_reqdDoc3 = {}; //신청자구비서류3 
var g_appl_2_reqdDoc4 = {}; //신청자구비서류4 
var g_appl_2_reqdDoc5 = {}; //신청자구비서류5 
var g_appl_2_reqdDoc6 = {}; //신청자구비서류6
var g_appl_2_reqdDoc7 = {}; //신청자구비서류7
var g_appl_2_reqdDoc8 = {}; //신청자구비서류8
*/
//moRecvNo
//moAcctNo
/*
 * 가입계약정보
 * */
var g_smartScrptCntrtInfo = ['moRecvNo','moScrbrNo'
                             ,'recvNo'
                             , 'scrbrNo'
                             , 'prdtTypeCd'
                             , 'prdtGrpCd'
                             , 'moPrdtGrpCd'
                             , 'prdtCd'
                             , 'prdtNm'
                             , 'eventPrdtGrpCd'
                             , 'eventPrdtGrpNm'
                             , 'eventNo'
                             , 'eventNm'
                             , 'rentalSellerCd'
                             , 'rentalSellerNm'
                             , 'dutyUsePerd'
                             , 'instalPlceZipCd'
                             , 'instalPlceAddr'
                             , 'instalPlceSuppAddr'
                             , 'aptCd'
                             , 'aptDong'
                             , 'aptHo'
                             , 'bldMgmtNo'
                             , 'addrSeltnTypeCd'
                             , 'rdNmVrfCd'
                             , 'refMastAddr'
                             , 'refSuppAddr'
                             , 'ktDongCd'
                             , 'addrBunjiCl'
                             , 'addrBunji'
                             , 'addrHo'
                             , 'refAddr'
                             , 'ktOfceCd'
                             , 'ktOfceNm'
                             , 'ktBldId'
                             , 'ktRdNmId'
                             , 'instalPossDh'
                             , 'instalCrclNetCd'
                             , 'instalCrclNetNm'
                             , 'preferSvcOpenDh'
                             , 'instalClCd'
                             , 'instalPlceBldClCd'
                             , 'entrClCd'
                             , 'entrPathCd'
                             , 'recvMthCd'
                             , 'recvRegionTypeCd'
                             , 'imapTypeCd'
                             , 'imapMgmtNo'
                             , 'etcEntrTypeCd'
                             , 'ipSvcAgreeYn'
                             , 'moMultiCnt'
                             , 'termInstalClCd'
                             , 'buyMthCd'
                             , 'collAgncyCd'
                             , 'collAgncyNm'
                             , 'mdmClCd'
                             , 'recvClType'
                             , 'relScrbrNo'
                             , 'moInstmCd'
                             , 'moMonthInvceAmt'
                             , 'moChrg'
                             , 'moLseAmt'
                             , 'moTotInvceAmt'
                             , 'moPrdtAmt'];
/*
 * 고객가입정보  
 * 
var g_smartScrptRecvInfo = ['moRecvNo'
                            ,'recvNo'
                            ,'recvRegrDh'
                            ,'cnclDh'
                            ,'moEntrType'
                            ,'custNo'
                            ,'custNm'
                            ,'custTypeCd'
                            ,'juminBizNo'
                            ,'telNo'
                            ,'mblTelNo'
                            ,'emailId'
                            ,'smsRecvYn'
                            ,'emailRecvYn'
                            ,'telRecvYn'
                            ,'reduTypeCd'
                            ,'coNo'
                            ,'rpsntNm'
                            ,'indsTypeCd'
                            ,'bizCndDesc'
                            ,'indsDesc'
                            ,'moCustNmCertiTypeCd'
                            ,'moCustNmCertiKey'
                            ,'moCustNmCertiDh'
                            ,'moCustNmPossDh'
                            ,'aplnTypeCd'
                            ,'aplnJuminNo'
                            ,'aplnNm'
                            ,'aplnCnctTelNo'
                            ,'moAplnNmCertiTypeCd'
                            ,'moAplnNmCertiKey'
                            ,'moAplnNmCertiDh'
                            ,'moAplnCertiTypeCd'
                            ,'moAplnCertiMblCoCd'
                            ,'moAplnCertiMblTelNo'
                            ,'moAplnCertiKey'
                            ,'moAplnCertiDh'
                            ,'moAplnAddPrdtYn'
                            ,'moMonthInvceAmt'
                            ,'moTotInvceAmt'
                            ,'moInstalChrgAmt'
                            ,'agrTgtTypeCd'
                            ,'prmtAgrYn'
                            ,'prsnlSupyAgrYn'
                            ,'rentalAgrTgtTypeCd'
                            ,'rentalCreditSupyAgrYn'
                            ,'rentalPrsnlSupyAgrYn'
                            ,'agentAgrTgtTypeCd'
                            ,'agentPrmtAgrYn'
                            ,'agentPrsnlSupyAgrYn'
                            ,'agentRentalAgrTgtTypeCd'
                            ,'agentRentalCredtSupyAgrYn'
                            ,'agentRentalPrsnlSupyAgrYn'
                            ,'aplnAgrTgtTypeCd'
                            ,'aplnPrmtAgrYn'
                            ,'aplnPrsnlSupyAgrYn'
                            ,'aplnRentalAgrTgtTypeCd'
                            ,'aplnRentalCredtSupyAgrYn'
                            ,'aplnRentalPrsnlSupyAgrYn'
                            ,'recvUserId'
                            ,'recvOrgCd'
                            ,'moAplnSignMthCd'
                            ,'moUserSignMthCd'
                            ,'moProgStatCd'
                            ];*/
/*
 * 가입계약 부가상품정보
 * 
var g_smartScrptCntrtExInfo = ['moRecvNo'
                            ,'moScrbrNo'
                            ,'moExScrbrNo'
                            ,'recvNo'
                            ,'scrbrNo'
                            ,'exScrbrNo'
                            ,'exTypeCd'
                            ,'prdtCd'
                            ,'prdtNm'
                            ,'eventNo'
                            ,'eventNm'
                            ,'exPrdtTypeCd'
                            ,'exPrdtGrpCd'
                            ,'exPrdtCd'
                            ,'exPrdtNm'
                            ,'exDutyUseCd'
                            ,'moExInstmCd'
                            ,'moExMonthInvceAmt'
                            ,'moExTotInvceAmt'
                            ,'moExLseAmt'
                            ,'upprScrbrNo'
                            ,'equipClCd'
                            ,'equipId'
                            ,'equipNm'
                            ,'equipModelNo'
                            ,'equipModelNm'
                            ,'equipRateSeqNo'
                            ,'moMltRecvNo'
                            ];
*/







//fnApiGetMessage(106);
/*function fnApiGetMessage (v_msgCode) {
	var param = {
		 apiType : "apiInfScs005"
		, cdClList : MSG.API_CODE_CM471_KEY
		, msgCode : v_msgCode
	};
	fn_callAjax("/contract/selectCallApi.json", param, fnDisplayMessageInfo)
}
function fnDisplayMessageInfo (result) {
	var retCode = result.retCode;
	var retMsg = result.retMsg;
	//retApiList
	if (retCode == "SUCC") {
		var rowData = result.retApiList;
		var reqMsgCode = result.contractReq.msgCode;
		if(rowData != null && rowData.length > 0){
			for(var i=0;i<rowData.length;i++){
				var code = rowData[i].cd;
				var codeMsg = rowData[i].cdDesc;
				if(reqMsgCode == code){
					//alert(codeMsg);
					g_msgObj.msg1 = codeMsg;
					fnPOPMessagePopup("CUSTOM", g_msgObj);
					break;
				}
			}
		}
		
	}
	
}*/
/*
 * 인터페이스 fnApiCall_INF_010 실명인증 인터페이스
 * */
function fnApiCall_INF_010(v_tartgetId, v_custNm, v_juminBizNo, resultFunc){
	var param = {
			apiType : "apiInfScs010"
			, custNm : v_custNm
			, juminBizNo : v_juminBizNo
			, targetId : v_tartgetId
	}
	fn_callAjax("/contract/nameVerifyCheck.json", param, resultFunc)
}

/*
 * 인터페이스 fnApiCall_INF_011 사업자정보인증 인터페이스
 * */
function fnApiCall_INF_011(v_tartgetId, v_custNm, v_juminBizNo, resultFunc){
	var param = {
			apiType : "apiInfScs011"
			, custNm : v_custNm
			, juminBizNo : v_juminBizNo
			, targetId : v_tartgetId
	}
	fn_callAjax("/contract/bizInfoVerifyCheck.json", param, resultFunc)
}
/*
 * INF_SCS_012 고객정보 조회 이력등록처리
 * */

/*
* 인터페이스 fnApiCall_INF_013 고객 가입가능 확인-고객상품가입 가능한지 체크
* */
function fnApiCall_INF_013(v_tartgetId, resultFunc){
	var param = {
			apiType : "apiInfScs013"
			, custNm : "이월이"
			, juminBizNo : "8706302268218"
			, targetId : v_tartgetId
	}
	fn_callAjax("/contract/custScrptValidCheck.json", param, resultFunc)
}

/*
* 인터페이스 fnApiCall_INF_014 설치주소 설치 가능여부 확인
* */
function fnApiCall_INF_014(v_tartgetId, paramObj, resultFunc){
	var param = {
			apiType : "apiInfScs014"
			, prdtCd : paramObj.prdtCd  	//30170102 상품코드 *
			, ktOfceCd : paramObj.ktOfceCd  //R02471 KT수용국코드 *
			, ktDongCd : paramObj.ktDongCd  //380201 KT동코드 *
			, ktBldId : paramObj.ktBldId 	//90000211096 KT건물아이디 *
			, bunji : paramObj.bunji 		//번지
			, ho : paramObj.ho				//호
			, targetId : v_tartgetId
	}
	fn_callAjaxAsync("/contract/checkInstallYn.json", param, resultFunc)
}
/*
* 인터페이스 fnApiCall_INF_015  설치 희망일 및 희망시간 조회
* */
function fnApiCall_INF_015(v_tartgetId, paramObj, resultFunc){
	var param = {
			apiType : "apiInfScs015"
			, instalPlceZipCd : paramObj.instalPlceZipCd	//설치우편번호	
			, instalPlceAddr : paramObj.instalPlceAddr	//설치주소	
			, instalPlceSuppAddr : paramObj.instalPlceSuppAddr	//설치보조주소	
			, refBaseAddr : paramObj.refBaseAddr	//참조기본주소	
			, refBaseSuppAddr : paramObj.refBaseSuppAddr	//참조보조주소	
			, addrSeltnTypeCd : paramObj.addrSeltnTypeCd	//주소선택구분코드	
			, instalCrclNetCd : paramObj.instalCrclNetCd	//설치점	TV/인터넷인 경우
			, preferSvcOpenDh : paramObj.preferSvcOpenDh	//개통희망일	
			, targetId : v_tartgetId
	}
	fn_callAjax("/contract/instalPreferSvcOpenDhSearch.json", param, resultFunc)
}
/*
 * 인터페이스 fnApiCall_INF_016 계좌인증 
 * */
function fnApiCall_INF_016(v_tartgetId, paramObj, resultFunc){
	var param = {
			apiType : "apiInfScs016"
			, bankCd : paramObj.bankCd
			, acctNo : paramObj.acctNo
			, depOwnNm : paramObj.depOwnNm
			, acctJuminBizNo : paramObj.acctJuminBizNo
			, targetId : v_tartgetId
	}
	fn_callAjaxAsync("/contract/accountValidCheck.json", param, resultFunc)
}


/*
 * 인터페이스 fnApiCall_INF_017 신용카드인증
 * */
function fnApiCall_INF_017(v_tartgetId, paramObj, resultFunc){
	var param = {
			apiType : "apiInfScs017"
			, creditCardKindCd : paramObj.creditCardKindCd
			, creditCardNo : paramObj.creditCardNo
			, creditCardValidPerdDm : paramObj.creditCardValidPerdDm
			, creditCardOwnerNm : paramObj.creditCardOwnerNm
			, acctJuminBizNo : paramObj.acctJuminBizNo
			, juminNoCheck : paramObj.juminNoCheck //'P : 개인	C : 법인
			, targetId : v_tartgetId
	}
	fn_callAjaxAsync("/contract/creditCardValidCheck.json", param, resultFunc)
}

/*
* 인터페이스 fnApiCall_INF_020  기존 등록된 고객의 정보조회(고객정보, 청구정보, 설치정보) 호출시 -> INF_012번 호출( 고객정보 조회 이력등록 처리) 고객정보 조회하면 이력을 남겨야됨
* */
function fnApiCall_INF_020(v_tartgetId, juminBizNo, resultFunc){
	var param = {
			apiType : "apiInfScs022"
			, juminBizNo : "8706302268218"
			, targetId : v_tartgetId
	}
	fn_callAjax("/contract/custScrptInstalInfoSearch.json", param, resultFunc)
}



/*
* 인터페이스 fnApiCall_INF_022 kmc 인증 번호발송
* */
function fnApiCall_INF_022(v_tartgetId, paramObj, resultFunc){
	var param = {
			apiType : "apiInfScs022"
			, custNm : paramObj.custNm
			, birthDt : paramObj.birthDt
			, gender : paramObj.gender
			, nation : paramObj.nation
			, phoneCorp : paramObj.phoneCorp
			, mblTelNo : paramObj.mblTelNo
			, exSvcGuideAgreeYn : paramObj.exSvcGuideAgreeYn
			, targetId : v_tartgetId
	}
	fn_callAjaxAsync("/contract/kmcSmsSend.json", param, resultFunc)
}

/*
 * 인증번호 확인
 */
function fnSmsValidCheck(paramObj, resultFunc){
	var param = {
			apiType : "apiInfScs023"
			, smsNum : paramObj.smsNum
			, certiNum : paramObj.certiNum
			, certiChkKey1 : paramObj.certiChkKey1
			, certiChkKey2 : paramObj.certiChkKey2
			, certiChkKey3 : paramObj.certiChkKey3
			, moRecvNo : paramObj.moRecvNo
			, moAplnCertiMblCoCd : paramObj.moAplnCertiMblCoCd
			, moAplnCertiMblTelNo : paramObj.moAplnCertiMblTelNo
			, moAplnCertiKey : paramObj.moAplnCertiKey
	}
	fn_callAjaxAsync("/contract/selectSmsValidCheck.json", param, resultFunc)
}

/*
 * 인터페이스 024 모집점정보조회
 * */
function fnApiCall_INF_024(v_tartgetId, v_crclNetCd, resultFunc){
	var param = {
			apiType : "apiInfScs024"
			, crclNetCd : v_crclNetCd
			, targetId : v_tartgetId
	}
	fn_callAjax("/contract/collAgncyInfoSearch.json", param, resultFunc)
}


/*
* 인터페이스 fnApiCall_INF_025  설치유통망 조회 
**/
function fnApiCall_INF_025(v_tartgetId, paramObj, resultFunc){

	var param = {
			apiType : "apiInfScs025"
			, instalPlceZipCd : paramObj.instalPlceZipCd 	//설치우편번호*
			, instalPlceAddr : paramObj.instalPlceAddr 	//	설치주소*
			, instalPlceSuppAddr : paramObj.instalPlceSuppAddr //	설치보조주소*
			, refBaseAddr : paramObj.refBaseAddr 		//	참조기본주소*
			, refBaseSuppAddr : paramObj.refBaseSuppAddr 	//	참조보조주소*
			, addrSeltnTypeCd : paramObj.addrSeltnTypeCd 	//	주소선택구분코드*
			, deptCd : paramObj.deptCd 			//	판매자조직코드*
			, eventNo : paramObj.eventNo 			//이벤트번호 * 이벤트번호로 SLT유통망 판단
			, targetId : v_tartgetId
			, tempRsltCd : paramObj.tempRsltCd
			, tempRsltMsg : paramObj.tempRsltMsg
			, tempLoadType : paramObj.tempLoadType
	}
	if(paramObj.tempLoadType == "INIT"){
		fn_callAjax("/contract/instalCrclNetInfoSearch.json", param, resultFunc)
	}else{
		fn_callAjaxAsync("/contract/instalCrclNetInfoSearch.json", param, resultFunc)
	}
	
}

/*
* 인터페이스 fnApiCall_INF_028  인터넷 수용국 조회
* */
function fnApiCall_INF_028(v_tartgetId, paramObj, resultFunc){
	var param = {
			apiType : "apiInfScs028"
			, ofceNm : paramObj.ofceNm		//수용국명*
			, eupmyundongNm : paramObj.eupmyundongNm	//읍면동*
			, searchGubun : paramObj.searchGubun 	//'0 : 수용국명 1 : 주소*
			, pageNo : paramObj.pageNo			//페이지번호*
			, targetId : v_tartgetId
	}
	fn_callAjaxAsync("/contract/getOfceInfo.json", param, resultFunc)
}

function fnPOPMessagePopup(gubun, msgObj){
	if(gubun == ""){
		return;
	}
	var v_title = $("#POP_popup1 .pop-tit");
	var v_content1 = $("#POP_popup1 .popmsg1");
	var v_content2 = $("#POP_popup1 .popmsg2");
	if(gubun == "SMS_NO_SEND"){
		v_title.html("인증번호 발송 안내");v_content1.html("인증번호가 발송되었습니다.");	v_content2.html("인증번호를 입력해주세요.");
	}else if(gubun == "SMS_AUTH_OK"){
		v_title.html("인증 완료 안내");	v_content1.html("인증이 완료 되었습니다.");v_content2.html("");
	}else if(gubun == "SMS_AUTH_FAIL"){
		v_title.html("인증 실패 안내");	v_content1.html("인증이 실패 되었습니다.");v_content2.html("불가 사유 : 인증번호가 잘못 입력되었습니다.");
	}else if(gubun == "BANK_AUTH_OK"){
		v_title.html("계좌 확인 완료");	v_content1.html("계좌가 인증되었습니다.");v_content2.html("");
	}else if(gubun == "BANK_AUTH_FAIL"){
		v_title.html("계좌 이용 불가 안내");	v_content1.html("계좌 이용이 불가능합니다.");v_content2.html("불가 사유 : XX");
	}else if(gubun == "CARD_AUTH_OK"){
		v_title.html("신용카드 확인 완료");	v_content1.html("신용카드가 인증되었습니다.");v_content2.html("");
	}else if(gubun == "CARD_AUTH_FAIL"){
		v_title.html("신용카드 이용 불가 안내");	v_content1.html("신용카드 이용이 불가능합니다.");v_content2.html("불가 사유 : XX");
	}else if(gubun == "SMS_AUTH_TIME"){
		v_title.html("인증 실패 안내");	v_content1.html("인증번호 유효시간이 지났습니다.");v_content2.html("인증번호를 다시 받아주세요.");
	}else if(gubun == "CUST_AUTH_OK"){
		v_title.html("고객정보 확인 완료");v_content1.html("고객정보 확인이 완료 되었습니다.");v_content2.html("신청서를 계속 작성해주세요.");
	}else if(gubun == "CUST_AUTH_FAILE"){
		v_title.html("가입 불가 안내");	v_content1.html("고객님은 신청이 불가능합니다.");v_content2.html("불가 사유 : XX");//v_content2.html("불가 사유 : 불가사유 메시지 입니다.");
	}else if(gubun == "SMS_NO_INPUT"){
		v_title.html("");v_content1.html("인증번호를 입력해주세요.");	v_content2.html("");
	}else if(gubun == "SMS_NO_TIME_OUT"){
		v_title.html("");v_content1.html("인증시간이 지났습니다.");v_content2.html("");
	}else if(gubun == "NO_DATA"){
		v_title.html("");v_content1.html("조회결과없음.");	v_content2.html("");
	}else if(gubun == "CUSTOM"){
		v_title.html(msgObj.title);
		v_content1.html(msgObj.msg1);
		v_content2.html(msgObj.msg2);
	}
	
	$("#POP_popup1").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}

/*
 * 인터넷 수용국 조회 팝업
 * */
function fnPOPA_60_P11(target, target2){
	//name:code
	fnPOPA_60_P11Reset();
	MSG.TEMP = target + ":" + target2;
	$("#POP_A_60_P11").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
	
}
function fnPOPA_60_P11Reset(){
	//수용국명-초기화
	$("#pop_inp_nm_intHost").val("");
	$("#pop_inp_nm_intHostCode").val("");
	$("#pop_div_nm_tblList").empty();
	$("#pop_div_nm_nodata_intHost").show();
	$('#interLandNum').attr('page',"0");
	MSG.LAND_NUM = true;
	//수용국 주소-초기화
	$("#pop_inp_addr_dong").val("");
	$("#pop_div_addr_tblList").empty();
	$("#pop_div_addr_nodata_dong").show();
	$('#interLandAddr').attr('page',"0");
	MSG.LAND_ADDR = true;
}
function fnPOPA_60_P11Search(type, typeStatus){
	var paramObj = {
			ofceNm : ""
			, eupmyundongNm : ""
			, searchGubun : ""
			, pageNo : ""
	};
	g_msgObj.title = "";
	g_msgObj.msg2 = "";
	
	
	if(type == "type_nm_intHost" || type == "type_nm_intHostCode"){
		if(type == "type_nm_intHost" && typeStatus == "search"){
			MSG.LAND_NUM = true;	
			$('#interLandNum').attr('page',"0");
			$("#pop_div_nm_tblList").empty();
		}
		if(type == "type_nm_intHost" && MSG.LAND_NUM){
			if($.trim($("#pop_inp_nm_intHost").val()) == ""){
				g_msgObj.msg1 = "수용국명을 입력해주세요.";
				fnPOPMessagePopup("CUSTOM", g_msgObj);
				return;
			}
			paramObj["ofceNm"] = $("#pop_inp_nm_intHost").val();
			paramObj["eupmyundongNm"] = "";
			paramObj["searchGubun"] = "0";
			var pageNo = Number($('#interLandNum').attr('page')) + 1;
			$('#interLandNum').attr('page',pageNo);
			paramObj["pageNo"] = pageNo
			
			fnApiCall_INF_028(type, paramObj, resultPOPA_60_P11Search);
		}else if(type == "type_nm_intHostCode"){
			if($.trim($("#pop_inp_nm_intHostCode").val()) == ""){
				g_msgObj.msg1 = "수용국코드를 입력해주세요.";
				fnPOPMessagePopup("CUSTOM", g_msgObj);
				return;
			}
			var arrTempId = MSG.TEMP.split(":");
			console.log(" >> " + arrTempId[0]);
			console.log(" >> " + arrTempId[1]);
			
			$("#"+arrTempId[0]).val($("#pop_inp_nm_intHostCode").val());
			$("#"+arrTempId[1]).val($("#pop_inp_nm_intHostCode").val());
			//inp_intHost_
			//inp_intHostCode_
			
			//초기화 팝업닫기
			fnbPopupClose("POP_A_60_P11");
			fnPOPA_60_P11Reset();
			
			/*
			 * 데이터 체크
			 * */
			data.nextCheck();
			
		}
	}else{
		if(type == "type_addr_dong" && typeStatus == "search"){
			MSG.LAND_ADDR = true;	
			$('#interLandAddr').attr('page',"0");
			$("#pop_div_addr_tblList").empty();
		}
		if(type == "type_addr_dong" && MSG.LAND_ADDR){
			if($.trim($("#pop_inp_addr_dong").val()) == ""){
				g_msgObj.msg1 = "읍/면/동을 입력해주세요.";
				return;
			}
			paramObj["ofceNm"] = "";
			paramObj["eupmyundongNm"] = $("#pop_inp_addr_dong").val();
			paramObj["searchGubun"] = "1";
			var pageNo = Number($('#interLandAddr').attr('page')) + 1;
			$('#interLandAddr').attr('page',pageNo);
			paramObj["pageNo"] = pageNo;
			
			fnApiCall_INF_028(type, paramObj, resultPOPA_60_P11Search);
		}
	}
	
}
resultPOPA_60_P11Search = function(result){
	//console.log('resultPOPA_60_P11Search');
	var rowData = result.retApi;
	var rowDataList = rowData.resultOfceVo;
	var rowList = "";
	var targetId = result.contractReq.targetId;
	//totalCnt
	if(rowDataList != null && rowDataList.length > 0){
		for(var i=0;i<rowDataList.length;i++){
			rowList = rowList + "<li onclick=\"fnPOPA_60_P11Selected(this);\" ofceCd=\""+rowDataList[i].ofceCd+"\" ofceNm=\""+rowDataList[i].ofceNm+"\">";
			rowList = rowList + "<span>"+rowDataList[i].zipCd+"</span>";
			rowList = rowList + "<span>("+rowDataList[i].dongCd+")</span>";
			rowList = rowList + "<strong>"+rowDataList[i].addr+" "+rowDataList[i].bunjiGubun+" "+controller.nvl(rowDataList[i].bunjiHo,"")+"</strong>";
			rowList = rowList + "<em>("+rowDataList[i].ofceCd+" : "+rowDataList[i].ofceNm+")</em>";
			rowList = rowList + "</li>";
		}
		if(targetId == "type_nm_intHost" || targetId == "type_nm_intHostCode"){
			$("#pop_div_nm_nodata_intHost").hide();
			$("#pop_div_nm_tblList").append(rowList);
			var liSize = $("#pop_div_nm_tblList > li").length;
			if(rowData.totalCnt == liSize){
				MSG.LAND_NUM = false;
			}
		}else{
			if(targetId == "type_addr_dong"){
				$("#pop_div_addr_nodata_dong").hide();
		    	$("#pop_div_addr_tblList").append(rowList);
		    	var liSize = $("#pop_div_addr_tblList > li").length;
				if(rowData.totalCnt == liSize){
					MSG.LAND_ADDR = false;
				}
			}
		}
		$('body').addClass('bodyHold');
	}else{
		if(targetId == "type_nm_intHost" || targetId == "type_nm_intHostCode"){
			if(rowData.totalCnt == "0"){
				$("#pop_div_nm_nodata_intHost").show();
				$("#pop_div_nm_tblList").empty();
				$('#interLandNum').attr('page',"0");
			}
			
		}else {
			if(targetId == "type_addr_dong"){
				if(rowData.totalCnt == "0"){
					$("#pop_div_addr_nodata_dong").show();
					$("#pop_div_addr_tblList").empty();
					$('#interLandAddr').attr('page',"0");
				}
			}
		}
		$('body').addClass('bodyHold');
	}
	
}
/*
 * 주소 선택
 * */
function fnPOPA_60_P11Selected(obj){
	//데이터 셋팅
	var ofceNm = $(obj).attr("ofceNm");
	var ofceCd = $(obj).attr("ofceCd");
	var arrTempId = MSG.TEMP.split(":");
	$("#" + arrTempId[0]).val(ofceNm);
	$("#" + arrTempId[1]).val(ofceCd);
	//초기화 팝업닫기
	fnbPopupClose("POP_A_60_P11");
	fnPOPA_60_P11Reset();
	
	/*
	 * 데이터 체크
	 * */
	data.nextCheck();
}
/*
 * 상품정보 페이지 링크(등록후)
 * */
function fnLinkProduct(moRecvNo, moProgStatCd){
	var $form = $('<form></form>');
	$form.attr('method', 'post');
	$form.attr('action', contextPath + "/contract/receiptProduct.do");
    $form.appendTo('body');
    fn_addHidden($form, "moRecvNo",  moRecvNo);
    fn_addHidden($form, "moProgStatCd",  fn_nvl(moProgStatCd,"P"));
    $form.submit();
}
/*
 * 고객정보 페이지 링크(등록후)
 * */
function fnLinkCustInfo(moRecvNo,moProgStatCd){
	var $form = $('<form></form>');
	$form.attr('method', 'post');
	$form.attr('action', contextPath + "/contract/receiptCustInfo.do");
    $form.appendTo('body');
    fn_addHidden($form, "moRecvNo",  moRecvNo);
    fn_addHidden($form, "moProgStatCd",  fn_nvl(moProgStatCd,"P"));
    $form.submit();
}
/*
 * 계약확인 페이지 링크(등록후) X
 * 
function fnLinkContract(moRecvNo){
	var $form = $('<form></form>');
	$form.attr('method', 'post');
	$form.attr('action', contextPath + "/contract/receiptContract.do");
    $form.appendTo('body');
    fn_addHidden($form, "moRecvNo",  moRecvNo);
    fn_addHidden($form, "moProgStatCd",  fn_nvl(moProgStatCd,"P"));
    $form.submit();
}*/
/*
* 약관 팝업 (html)
* */

function A_60_P15(){
	$("#A_60_P15").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function A_60_P16(){
	$("#A_60_P16").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function A_60_P17(){
	$("#A_60_P17").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function A_60_P18(){
	$("#A_60_P18").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function A_60_P19(){
	$("#A_60_P19").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function POP_Confirm6(){
	$("#POP_Confirm6").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
/*
 * 안드로이드 촬영안내 팝업
 * */
function fnPOPA_60_P21(v_type, v_moRecvNo){
	$("#POP_A_60_P21").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
	
	if(v_type == "GAE_ID"){
		if($("#aoz_btn_gae_id_cam").attr("disabled") == "disabled"){
			fnDisbClass("#pop_btn_cam_A_60_P21", true, "#pop_btn_cam_A_60_P21", "disabled", "");
		}else{
			fnDisbClass("#pop_btn_cam_A_60_P21", false, "#pop_btn_cam_A_60_P21", "", "disabled");
		}
	}else if(v_type == "GAE_FA_ID"){
		if($("#aoz_btn_gae_fa_id_cam").attr("disabled") == "disabled"){
			fnDisbClass("#pop_btn_cam_A_60_P21", true, "#pop_btn_cam_A_60_P21", "disabled", "");
		}else{
			fnDisbClass("#pop_btn_cam_A_60_P21", false, "#pop_btn_cam_A_60_P21", "", "disabled");
		}
	}else if(v_type == "GAE_DAE_ID"){
		if($("#aoz_btn_gae_dae_id_cam").attr("disabled") == "disabled"){
			fnDisbClass("#pop_btn_cam_A_60_P21", true, "#pop_btn_cam_A_60_P21", "disabled", "");
		}else{
			fnDisbClass("#pop_btn_cam_A_60_P21", false, "#pop_btn_cam_A_60_P21", "", "disabled");
		}
	}else if(v_type == "SAUP_CEO_ID"){
		if($("#aoz_btn_saup_id_cam").attr("disabled") == "disabled"){
			fnDisbClass("#pop_btn_cam_A_60_P21", true, "#pop_btn_cam_A_60_P21", "disabled", "");
		}else{
			fnDisbClass("#pop_btn_cam_A_60_P21", false, "#pop_btn_cam_A_60_P21", "", "disabled");
		}
	}else if(v_type == "SAUP_JIG_ID"){
		if($("#aoz_btn_saup_jig_id_cam").attr("disabled") == "disabled"){
			fnDisbClass("#pop_btn_cam_A_60_P21", true, "#pop_btn_cam_A_60_P21", "disabled", "");
		}else{
			fnDisbClass("#pop_btn_cam_A_60_P21", false, "#pop_btn_cam_A_60_P21", "", "disabled");
		}
	}else{
		fnDisbClass("#pop_btn_cam_A_60_P21", true, "#pop_btn_cam_A_60_P21", "disabled", "");
	}
	
	$("#pop_btn_cam_A_60_P21").removeAttr("onclick");
	$("#pop_btn_cam_A_60_P21").attr("onclick","fnCmmAozCamera('"+v_type+"', '"+v_moRecvNo+"')");
	
}


function fnbPopupClose(target){
	$('body').removeClass('bodyHold');
	$("#" + target).bPopup().close();
}

function fnScrollTopMove(targetClass){
	$('html, body').stop().animate({scrollTop: $('.'+targetClass).offset().top - $('.header').outerHeight()},300);
}
function fnScrollTopMoveObj(target){
	$('html, body').stop().animate({scrollTop: $(target).offset().top - $('.header').outerHeight()},300);
}
function fnDisbClass(disObj, flag,tarObjCls,addCls, rmvCls){
	//fnDisbClass($("#btn_gae_custOk"), true,$("#btn_gae_custOk"),"disabled", "");
	$(disObj).prop("disabled", flag);
	if(tarObjCls != ""){
		if(addCls !=""){
			$(tarObjCls).addClass(addCls);
		}
		if(rmvCls !=""){
			$(tarObjCls).removeClass(rmvCls);
		}
	}
}

function fnCmmAozCamera(v_type, v_moRecvNo){
	/*
	 * 인풋 구분 코드
	 * */
	//개인 > 본인 신분증 GAE_ID GAE_DOC1
	//개인 > 가족 신분증 GAE_FA_ID
	//개인 > 가족 구비서류 GAE_FA_DOC1(가족관계),GAE_FA_DOC2(위임장) 
	//개인 > 법정대리 신분증 GAE_DAE_ID
	//개인 > 법정대리 서류 GAE_DAE_DOC1(가족관계),GAE_DAE_DOC2(위임장)
	//사업자 > 본인 SAUP_CEO_ID
	//사업자 > 대표자서류 SAUP_CEO_DOC1(사업자등록증), SAUP_CEO_DOC2(법인인감), SAUP_CEO_DOC3(신분증(외국인등록증))
	//사업자 > 직원 SAUP_JIG_ID
	//사업자 > 직원구비서류  SAUP_JIG_DOC1(사업자등록증), SAUP_JIG_DOC2(법인인감), SAUP_JIG_DOC3(재직증명/사원증), SAUP_JIG_DOC3(위임장(사원증/재직증명), SAUP_JIG_DOC4(외국인 등록증) 
	//console.log("fnCmmAozCamera : " + v_type);
	var paramObjReq = {
		type : v_type //페이지내 id 구분
		, moRecvNo : v_moRecvNo   //스마트청약접수번호
		, moFileType : "" //내부 db 공통코드(MO_FILE_TYPE) 값
	}
	
	if(v_type == "GAE_ID"){
		paramObjReq.moFileType = "PRSNL_10_ID_CARD";
		/*
		 * 인증구분
		 * */
		$("#inp_moCustNmCertiTypeCd").val("03");
	}else if(v_type == "GAE_FA_ID"){
		paramObjReq.moFileType = "APLN_02_ID_CARD";
		/*
		 * 신청자 인증구분
		 * */
		$("#inp_moAplnNmCertiTypeCd").val("03");
	}else if(v_type == "GAE_DAE_ID"){
		paramObjReq.moFileType = "APLN_05_ID_CARD";
		/*
		 * 신청자 인증구분
		 * */
		$("#inp_moAplnNmCertiTypeCd2").val("03");
	}else if(v_type == "SAUP_CEO_ID"){
		paramObjReq.moFileType = "APLN_03_ID_CARD";
		/*
		 * 신청자 인증구분
		 * */
		$("#inp_moAplnNmCertiTypeCd").val("03");
	}else if(v_type == "SAUP_JIG_ID"){
		paramObjReq.moFileType = "APLN_04_ID_CARD_10";
		/*
		 * 신청자 인증구분
		 * */
		$("#inp_moAplnNmCertiTypeCd2").val("03");
	}else if(v_type == "GAE_DOC1"){
		if(fn_nvl($("#inp_custTypeCd").val(),"") == "2"){
			paramObjReq.moFileType = "PRSNL_20_ID_CARD";
		}else{
			paramObjReq.moFileType = "PRSNL_10_ID_CARD";
		}/**/
		/*
		 * 인증구분
		 * */
		$("#inp_moCustNmCertiTypeCd").val("04");
	}else if(v_type == "GAE_GAM_DOC1"){
		paramObjReq.moFileType = "REDU_FILE";
	}else if(v_type == "GAE_FA_DOC1"){
		paramObjReq.moFileType = "APLN_02_ID_CARD";
		/*
		 * 인증구분
		 * */
		$("#inp_moAplnNmCertiTypeCd").val("03");
	}else if(v_type == "GAE_FA_DOC2"){
		paramObjReq.moFileType = "APLN_02_FAMY_REL";
	}else if(v_type == "GAE_FA_DOC3"){
		paramObjReq.moFileType = "APLN_02_ATTORNEY";
	}else if(v_type == "GAE_DAE_DOC1"){
		paramObjReq.moFileType = "APLN_05_ID_CARD";
	}else if(v_type == "GAE_DAE_DOC2"){
		paramObjReq.moFileType = "APLN_05_FAMY_REL";
	}else if(v_type == "GAE_DAE_DOC3"){
		paramObjReq.moFileType = "APLN_05_ATTORNEY";
	}else if(v_type == "SAUP_GAM_DOC1"){
		paramObjReq.moFileType = "REDU_FILE";
	}else if(v_type == "SAUP_CEO_DOC1"){
		paramObjReq.moFileType = "APLN_03_ID_CARD";
	}else if(v_type == "SAUP_CEO_DOC2"){
		paramObjReq.moFileType = "APLN_03_BIZ_REGR";
	}else if(v_type == "SAUP_CEO_DOC3"){
		paramObjReq.moFileType = "APLN_03_CO_CERT";
	}else if(v_type == "SAUP_CEO_DOC4"){
		paramObjReq.moFileType = "APLN_03_ID_CARD_20";
	}else if(v_type == "SAUP_JIG_DOC1"){
		paramObjReq.moFileType = "APLN_04_ID_CARD_10";
	}else if(v_type == "SAUP_JIG_DOC2"){
		paramObjReq.moFileType = "APLN_04_BIZ_REGR";
	}else if(v_type == "SAUP_JIG_DOC3"){
		paramObjReq.moFileType = "APLN_04_CO_CERT";
	}else if(v_type == "SAUP_JIG_DOC4"){
		paramObjReq.moFileType = "APLN_04_EMP";
	}else if(v_type == "SAUP_JIG_DOC5"){
		paramObjReq.moFileType = "APLN_04_ATTORNEY";
	}else if(v_type == "SAUP_JIG_DOC6"){
		paramObjReq.moFileType = "APLN_04_ID_CARD_20";
	}	
	
	
	
	/*
	 * DB 코드
	 * */
	//MO_RECV_NO	스마트청약접수번호
	//MO_FILE_TYPE	첨부파일유형
	//MO_FILE_NUM	첨부파일유형페이지번호
	//MO_FILE_NM	첨부파일명
	//MO_FILE_SCAN_TYPE 파일 생성을 위한 스캔 유형	- 01 : OCR 신분증 자동인식 스캔	- 02 : OCR 문서촬영	- 03 : 파일 업로드
	//MO_FILE_SIZE	첨부파일크기
	//MO_FILE	첨부파일
	//MO_FILE_RSLT_CD	파일전송결과
	/*
	가입신청서	IDENTITY_DOC_CD	고객유형별 신분증		PRSNL_10	개인
			IDENTITY_DOC_CD						PRSNL_20	외국개인
	 */
	/*
	가족 - MO_FILE_TYPE	APLN_02_ATTORNEY	위임장 
	가족 - MO_FILE_TYPE	APLN_02_FAMY_REL	가족관계 증명서
	가족 - MO_FILE_TYPE	APLN_02_ID_CARD	신청자 신분증(주민등록증, 운전면허증, 여권)
	사업-MO_FILE_TYPE	APLN_03_BIZ_REGR	사업자등록증
	사업-MO_FILE_TYPE	APLN_03_CO_CERT	법인인감증명서
	사업-MO_FILE_TYPE	APLN_03_ID_CARD	대표자 신분증(주민등록증, 운전면허증, 여권)
	사업-MO_FILE_TYPE	APLN_04_ATTORNEY	위임장(사원증 혹은 재직증명서)
	사업-MO_FILE_TYPE	APLN_04_BIZ_REGR	사업자등록증
	사업-MO_FILE_TYPE	APLN_04_CO_CERT	법인인감증명서
	사업-MO_FILE_TYPE	APLN_04_EMP	재직증명서(혹은 사원증)
	사업-MO_FILE_TYPE	APLN_04_ID_CARD_10	직원 신분증(주민등록증, 운전면허증, 여권)
	사업-MO_FILE_TYPE	APLN_04_ID_CARD_20	직원 신분증(외국인 등록증)
	법정대리-MO_FILE_TYPE	APLN_05_ATTORNEY	위임장
	법정대리-MO_FILE_TYPE	APLN_05_FAMY_REL	법정대리인 증명서(혹은 가족관계증명서)
	법정대리-MO_FILE_TYPE	APLN_05_ID_CARD		신청자 신분증(주민등록증, 운전면허증, 여권)
	개인-MO_FILE_TYPE	PRSNL_10_ID_CARD	신분증(주민등록증, 운전면허증, 여권)
	외국인-MO_FILE_TYPE	PRSNL_20_ID_CARD	신분증(외국인 등록증, 국내 거소신고증)
	MO_FILE_TYPE	REDU_FILE	감면증빙서류
	MO_FILE_TYPE	SCRBR_APLN_1	가입신청서이미지 1페이지
	MO_FILE_TYPE	SCRBR_APLN_2	가입신청서이미지 2페이지
	MO_FILE_TYPE	SCRBR_APLN_3	가입신청서이미지 3페이지
	MO_FILE_TYPE	SCRBR_APLN_RENTAL_1	가입신청서이미지(홈 렌탈) 1페이지
	MO_FILE_TYPE	SCRBR_APLN_RENTAL_2	가입신청서이미지(홈 렌탈) 2페이지
	MO_FILE_TYPE	SCRBR_APLN_RENTAL_3	가입신청서이미지(홈 렌탈) 3페이지*/
	
	
	
	/*
	 * 인터페이스 호출
	 **/ 
	//-----------------------
	
	if(v_type == "GAE_ID" || v_type == "GAE_FA_ID" || v_type == "GAE_DAE_ID" || v_type == "SAUP_CEO_ID" || v_type == "SAUP_JIG_ID"){
		if($("#POP_A_60_P21").css("display") != "none"){
			fnbPopupClose("POP_A_60_P21");
		}
		capture(paramObjReq);
		
		
	}else{
		caputreDocument(paramObjReq); //문서
	}
	
}

function fnCmmAozCameraResult(paramObjRes){
	/*
	var paramObjRes = {
		type : "" 			//페이지내 id 구분
		, name : ""   		//이름
		, jumin : ""   		//주민
		, moRecvNo : ""   	//스마트청약접수번호
		, moFileType : "" 	//내부 db 공통코드(MO_FILE_TYPE) 값
		, moFileNum : "" 	//첨부파일유형페이지번호
		, moFileNm : ""  	//첨부파일명
		, moFileScanType : ""  	//파일스캔유형		
		, moFileSize : ""	//첨부파일크기
		, moFile : ""		//첨부파일경로
		, moFileRsltCd : "" //파일전송결과
		, moFileDocCnt : 0
		, moFileDoc : [
			{moFileNum : "" 	//첨부파일유형페이지번호
			, moFileNm : ""  	//첨부파일명
			, moFileSize : ""	//첨부파일크기
			, moFile : ""		//첨부파일경로
			, moFileRsltCd : "" //파일전송결과
			, moFileScanType : "" 	//파일스캔유형
		}
		]
		
	}
	*/
	var msg = "";
	if(paramObjRes.type.indexOf("DOC") > -1){
		msg = "type : " + paramObjRes.type + "<br/>";
		msg = msg + "name : " + paramObjRes.name + "<br/>";
		msg = msg + "jumin : " + paramObjRes.jumin + "<br/>";
		msg = msg + "moRecvNo : " + paramObjRes.moRecvNo + "<br/>";
		msg = msg + "moFileDocCnt : " + paramObjRes.moFileDocCnt + "<br/>";
		msg = msg + "moFileType : " + paramObjRes.moFileType + "<br/>";
		for(var i=0;i < paramObjRes["moFileDoc"].length;i++){
			msg = msg + "moFileNum : " + paramObjRes["moFileDoc"][i].moFileNum + "<br/>";
		}
		for(var i=0;i < paramObjRes["moFileDoc"].length;i++){
			msg = msg + "moFileNm : " + paramObjRes["moFileDoc"][i].moFileNm + "<br/>";
		}
		for(var i=0;i < paramObjRes["moFileDoc"].length;i++){
			msg = msg + "moFileSize : " + paramObjRes["moFileDoc"][i].moFileSize + "<br/>";
		}
		for(var i=0;i < paramObjRes["moFileDoc"].length;i++){
			msg = msg + "moFile : " + paramObjRes["moFileDoc"][i].moFile + "<br/>";
		}
		/*for(var i=0;i < paramObjRes["moFileDoc"].length;i++){
			msg = msg + "moFileScanType : " + paramObjRes["moFileDoc"][i].moFileScanType + "<br/>";
		}*/
	}else{
		msg = "type : " + paramObjRes.type + "<br/>";
		msg = msg + "moRecvNo : " + paramObjRes.moRecvNo + "<br/>";
		msg = msg + "moFileType : " + paramObjRes.moFileType + "<br/>";
		msg = msg + "moFileNum : " + paramObjRes.moFileNum + "<br/>";
		msg = msg + "moFileScanType : " + paramObjRes.moFileScanType + "<br/>";
		msg = msg + "moFileSize : " + paramObjRes.moFileSize + "<br/>";
		msg = msg + "moFile : " + paramObjRes.moFile + "<br/>";
		msg = msg + "name : " + paramObjRes.name + "<br/>";
		msg = msg + "jumin : " + paramObjRes.jumin + "<br/>";
	}
	
	//g_msgObj.msg1 = msg;
	//fnPOPMessagePopup("CUSTOM", g_msgObj);
	
	cmmCamera.autoOcr(paramObjRes);
	
}
var cmmCamera = {
	autoOcr : function(paramObjRes){
		if(paramObjRes.type.indexOf("DOC") > -1){
			//문서들
			if(paramObjRes.type == "GAE_DOC1"){
				//ui처리
				$("#aoz_ul_gae_id_camDoc1").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc1 = paramObjRes;
				$("#FILE_GAE_ID_DOC1_PRSNL_ID_CARD").val("Y");
			}else if(paramObjRes.type == "GAE_GAM_DOC1" || paramObjRes.type == "SAUP_GAM_DOC1"){
				//ui처리
				if(paramObjRes.type == "GAE_GAM_DOC1"){
					$("#aoz_ul_gae_gam_camDoc1").addClass("photo-finish");
				}else{
					$("#aoz_ul_saup_gam_camDoc1").addClass("photo-finish");
				}
				//파일정보 추가
				//g_appl_1_reqdDoc2 = paramObjRes;
				$("#FILE_DOC_REDU_FILE").val("Y");
			}else if(paramObjRes.type == "GAE_FA_DOC1"){
				//ui처리
				$("#aoz_ul_gae_fa_id_camDoc1").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc3 = paramObjRes;
				$("#FILE_GAE_FA_ID_DOC1_APLN_ID_CARD").val("Y");
			}else if(paramObjRes.type == "GAE_FA_DOC2"){
				//ui처리
				$("#aoz_ul_gae_fa_id_camDoc2").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc4 = paramObjRes;
				$("#FILE_GAE_FA_DOC2_APLN_02_FAMY_REL").val("Y");
			}else if(paramObjRes.type == "GAE_FA_DOC3"){
				//ui처리
				$("#aoz_ul_gae_fa_id_camDoc3").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc5 = paramObjRes;
				$("#FILE_GAE_FA_DOC3_APLN_02_ATTORNEY").val("Y");
			}else if(paramObjRes.type == "GAE_DAE_DOC1"){
				//ui처리
				$("#aoz_ul_gae_dae_id_camDoc1").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc1 = paramObjRes;
				$("#FILE_GAE_DAE_ID_DOC1_APLN_05_ID_CARD").val("Y");
			}else if(paramObjRes.type == "GAE_DAE_DOC2"){
				//ui처리
				$("#aoz_ul_gae_dae_id_camDoc2").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc2 = paramObjRes;
				$("#FILE_GAE_DAE_DOC2_APLN_05_FAMY_REL").val("Y");
			}else if(paramObjRes.type == "GAE_DAE_DOC3"){
				//ui처리
				$("#aoz_ul_gae_dae_id_camDoc3").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc3 = paramObjRes;
				$("#FILE_GAE_DAE_DOC3_APLN_05_ATTORNEY").val("Y");
			}else if(paramObjRes.type == "SAUP_CEO_DOC1"){
				//ui처리
				$("#aoz_ul_saup_ceo_id_camDoc1").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc1 = paramObjRes;
				$("#FILE_SAUP_CEO_ID_DOC1_APLN_03_ID_CARD").val("Y");
			}else if(paramObjRes.type == "SAUP_CEO_DOC2"){
				//ui처리
				$("#aoz_ul_saup_ceo_id_camDoc2").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc2 = paramObjRes;
				$("#FILE_SAUP_CEO_DOC2_APLN_03_BIZ_REGR").val("Y");
			}else if(paramObjRes.type == "SAUP_CEO_DOC3"){
				//ui처리
				$("#aoz_ul_saup_ceo_id_camDoc3").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc3 = paramObjRes;
				$("#FILE_SAUP_CEO_DOC3_APLN_03_CO_CERT").val("Y");
			}else if(paramObjRes.type == "SAUP_CEO_DOC4"){
				//ui처리
				$("#aoz_ul_saup_ceo_id_camDoc4").addClass("photo-finish");
				//파일정보 추가
				//g_appl_1_reqdDoc4 = paramObjRes;
				$("#FILE_SAUP_CEO_DOC4_APLN_03_ID_CARD_20").val("Y");
			}else if(paramObjRes.type == "SAUP_JIG_DOC1"){
				//ui처리
				$("#aoz_ul_saup_jig_id_camDoc1").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc1 = paramObjRes;
				$("#FILE_SAUP_JIG_ID_DOC1_APLN_04_ID_CARD_10").val("Y");
			}else if(paramObjRes.type == "SAUP_JIG_DOC2"){
				//ui처리
				$("#aoz_ul_saup_jig_id_camDoc2").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc2 = paramObjRes;
				$("#FILE_SAUP_JIG_DOC2_APLN_04_BIZ_REGR").val("Y");
			}else if(paramObjRes.type == "SAUP_JIG_DOC3"){
				//ui처리
				$("#aoz_ul_saup_jig_id_camDoc3").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc3 = paramObjRes;
				$("#FILE_SAUP_CEO_DOC3_APLN_04_CO_CERT").val("Y");
			}else if(paramObjRes.type == "SAUP_JIG_DOC4"){
				//ui처리
				$("#aoz_ul_saup_jig_id_camDoc4").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc4 = paramObjRes;
				$("#FILE_SAUP_CEO_DOC4_APLN_04_EMP").val("Y");
			}else if(paramObjRes.type == "SAUP_JIG_DOC5"){
				//ui처리
				$("#aoz_ul_saup_jig_id_camDoc5").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc5 = paramObjRes;
				$("#FILE_SAUP_CEO_DOC5_APLN_04_ATTORNEY").val("Y");
			}else if(paramObjRes.type == "SAUP_JIG_DOC6"){
				//ui처리
				$("#aoz_ul_saup_jig_id_camDoc6").addClass("photo-finish");
				//파일정보 추가
				//g_appl_2_reqdDoc6 = paramObjRes;
				$("#FILE_SAUP_CEO_DOC6_APLN_04_ID_CARD_20").val("Y");
			}
			
			
		}else{

			var name = fn_nvl(paramObjRes.name,"");
			var jumin = fn_nvl(paramObjRes.jumin,"");
			//주민번호 구분
			var jumin1 = "";
			var jumin2 = "";
			if(jumin.length > 6){
				jumin1 = jumin.substr(0,6);
				jumin2 = jumin.substr(6);
			}
			
			if(paramObjRes.type == "GAE_ID"){
				//이름, 주민번호 셋팅
				$("#inp_gae_custNm").val(name);
				$("#inp_gae_juminNo1").val(jumin1);
				$("#inp_gae_juminNo2").val(jumin2);
				//버튼활성
				if(jumin.length >= 13){
					fnDisbClass("#btn_gae_custOk", false, "#btn_gae_custOk", "", "disabled");
				}
				//ui처리
				$("#aoz_ul_gae_id_camDoc1").addClass("photo-finish");
				
				//외국 내국 ui처리(신분증 출력명)
				//$("#aoz_input_gae_id_cam").attr("placeholder","신분증(주민등록증, 운전면허증, 여권)");
				//파일정보 값 셋팅
				$("#FILE_GAE_ID_DOC1_PRSNL_ID_CARD").val("Y");
			}else if(paramObjRes.type == "GAE_FA_ID"){
				//이름, 주민번호 셋팅
				$("#inp_gae_fa_custNm").val(name);
				$("#inp_gae_fa_juminNo1").val(jumin1);
				$("#inp_gae_fa_juminNo2").val(jumin2);
				//버튼활성
				if(jumin.length >= 13){
					fnDisbClass("#btn_gae_fa_custOk", false, "#btn_gae_fa_custOk", "", "disabled");
				}
				//ui처리
				$("#aoz_ul_gae_fa_id_camDoc1").addClass("photo-finish");
				//파일정보 값 셋팅
				$("#FILE_GAE_FA_ID_DOC1_APLN_ID_CARD").val("Y");
			}else if(paramObjRes.type == "GAE_DAE_ID"){
				//이름, 주민번호 셋팅
				$("#inp_gae_dae_custNm").val(name);
				$("#inp_gae_dae_juminNo1").val(jumin1);
				$("#inp_gae_dae_juminNo2").val(jumin2);
				//버튼활성
				if(jumin.length >= 13){
					fnDisbClass("#btn_gae_dae_custOk", false, "#btn_gae_dae_custOk", "", "disabled");
				}
				//ui처리
				$("#aoz_ul_gae_dae_id_camDoc1").addClass("photo-finish");
				//파일정보 값 셋팅
				$("#FILE_GAE_DAE_ID_DOC1_APLN_05_ID_CARD").val("Y");
			}else if(paramObjRes.type == "SAUP_CEO_ID"){
				//이름, 주민번호 셋팅
				$("#inp_saup_ceoNm2").val(name);
				$("#inp_saup_juminNo1").val(jumin1);
				$("#inp_saup_juminNo2").val(jumin2);
				//버튼활성
				if(jumin.length >= 13){
					fnDisbClass("#btn_saup_custOk2", false, "#btn_saup_custOk2", "", "disabled");
				}
				//ui처리 
				$("#aoz_ul_saup_ceo_id_camDoc1").addClass("photo-finish");
				//파일정보 값 셋팅 
				$("#FILE_SAUP_CEO_ID_DOC1_APLN_03_ID_CARD").val("Y");
			}else if(paramObjRes.type == "SAUP_JIG_ID"){
				//이름, 주민번호 셋팅
				$("#inp_saup_jig_ceoNm").val(name);
				$("#inp_saup_jig_juminNo1").val(jumin1);
				$("#inp_saup_jig_juminNo2").val(jumin2);
				//버튼활성
				if(jumin.length >= 13){
					fnDisbClass("#btn_saup_jig_custOk", false, "#btn_saup_jig_custOk", "", "disabled");
				}
				//ui처리 
				$("#aoz_ul_saup_jig_id_camDoc1").addClass("photo-finish");
				//파일정보 값 셋팅
				$("#FILE_SAUP_JIG_ID_DOC1_APLN_04_ID_CARD_10").val("Y");
			}
		}
	}
}
function fnCmmJuminNation(jumin1, jumin2){
	//fn_isJuminByVal($("#inp_gae_juminNo1").val(), $("#inp_gae_juminNo2").val())
	if(true){
		if(jumin2.charAt(0) == "5" || jumin2.charAt(0) == "6" || jumin2.charAt(0) == "7" || jumin2.charAt(0) == "8" || jumin2.charAt(0) == "9"){
			return "2"; //외국인
		}else{
			return "1";
		}
	}
}
function fnCmmAozSign(v_type, v_moRecvNo){
	/*
	 * 인풋 구분 코드
	 * */
	//서명 > 신청(대리인) 서명 GAE_SIGN
	//서명 > 납부 서명 NABB_SIGN
	//서명 > 접수 서명 JUBSU_SIGN
	var paramObjReq = {
			type : "" //페이지내 id 구분
			, moRecvNo : ""   //스마트청약접수번호
			, moFileType : "" //내부 db 공통코드(MO_FILE_TYPE) 값
			
		}
		
	if(v_type == "GAE_SIGN"){
		paramObjReq.type = v_type;
		paramObjReq.moRecvNo = v_moRecvNo;
		paramObjReq.moFileType = "APLN_SIGN_MTH_CD";
	}else if(v_type == "NABB_SIGN"){
		paramObjReq.type = v_type;
		paramObjReq.moRecvNo = v_moRecvNo;
		paramObjReq.moFileType = "ACCT_SIGN_MTH_CD";
	}else if(v_type == "JUBSU_SIGN"){
		paramObjReq.type = v_type;
		paramObjReq.moRecvNo = v_moRecvNo;
		paramObjReq.moFileType = "USER_SIGN_MTH_CD";
	}
	/*
	 * 인터페이스 호출
	 * */
	//-----------------------
//	sign(paramObjReq); //오즈 호출
	signPop(paramObjReq); //오즈 호출
	
	/*
	 * scis 코드
	 * */
	/*CM205	7462056	서명방식코드		APLN_SIGN_MTH_CD	신청자서명방식코드
	CM205	7462056	서명방식코드		USER_SIGN_MTH_CD	판매접수자서명방식코드
	CM205	7462056	서명방식코드		ACCT_SIGN_MTH_CD	타인납부서명방식코드*/

}
function fnCmmAozSignResult(paramObjRes){
	/*
	var paramObjRes = {
		type : "" //페이지내 id 구분
		, moFileType : "" 	//내부 인터페이스 서명방식코드 값
		, moRecvNo : ""   	//스마트청약접수번호
		, moFileNm : ""  	//첨부파일명-서명파일명
		, moFile : ""		//첨부파일경로-서명파일경로
	}
	*/
	var msg = "type : " + paramObjRes.type + "<br/>";
	msg = msg + "moFileType : " + paramObjRes.moFileType + "<br/>";
	msg = msg + "moRecvNo : " + paramObjRes.moRecvNo + "<br/>";
	msg = msg + "moFileNm : " + paramObjRes.moFileNm + "<br/>";
	msg = msg + "moFile : " + paramObjRes.moFile + "<br/>";
	//alert(msg);
	//var msgObj = {title : "", msg1 : msg, msg2 : ""};
	//fnPOPMessagePopup("CUSTOM", msgObj);
	
	if(paramObjRes.type == "GAE_SIGN" ){
		var imgContainer1 = $('#imgt_gae_sign');
		imgContainer1.html('');
	    imgContainer1.html('<li><div class="canvas" id="imgt_gae_sign"><img width="100%" src="'+paramObjRes.moFile+'"/></div></li>');
		var imgContainer2 = $('#imgt_gae_name');
		imgContainer2.html('');
	    imgContainer2.html('<li><div class="canvas" id="imgt_gae_name"><img width="100%" src="'+paramObjRes.moFile2+'"/></div></li>');
	    
		return;
	}else if(paramObjRes.type == "NABB_SIGN" ){
		var imgContainer1 = $('#imgt_nabb_sign');
		imgContainer1.html('');
	    imgContainer1.html('<li><div class="canvas" id="imgt_nabb_sign"><img width="100%" src="'+paramObjRes.moFile+'"/></div></li>');
		var imgContainer2 = $('#imgt_nabb_name');
		imgContainer2.html('');
	    imgContainer2.html('<li><div class="canvas" id="imgt_nabb_name"><img width="100%" src="'+paramObjRes.moFile2+'"/></div></li>');		
		return;
	}else if(paramObjRes.type == "JUBSU_SIGN" ){
		var imgContainer1 = $('#imgt_jubsu_sign');
		imgContainer1.html('');
	    imgContainer1.html('<li><div class="canvas" id="imgt_jubsu_sign"><img width="100%" src="'+paramObjRes.moFile+'"/></div></li>');
		var imgContainer2 = $('#imgt_jubsu_name');
		imgContainer2.html('');
	    imgContainer2.html('<li><div class="canvas" id="imgt_jubsu_name"><img width="100%" src="'+paramObjRes.moFile2+'"/></div></li>');			
		return;
	}
//	if(paramObjRes.type == "GAE_SIGN" ){
//		$("#ult_gae_sign").hide();
//		$("#imgt_gae_sign").attr("src",paramObjRes.moFile);
//		return;
//	}else if(paramObjRes.type == "NABB_SIGN" ){
//		$("#ult_nabb_sign").hide();
//		$("#imgt_nabb_sign").attr("src",paramObjRes.moFile);
//		return;
//	}else if(paramObjRes.type == "JUBSU_SIGN" ){
//		$("#ult_jubsu_sign").hide();
//		$("#imgt_jubsu_sign").attr("src",paramObjRes.moFile);
//		return;
//	}
	
}

function fnReqValCheckMsgOutput(msg){
	var msgArr = msg.split(":");
	g_msgObj.msg1 = msgArr[msgArr.length-1];
	fnPOPMessagePopup("CUSTOM", g_msgObj);
}

