

$(document).ready(function(){
	
	dataC.init();
	eventC.init();
	uiC.init();
});

$(window).on('load', function(){
});





var dataC = {
	init : function (){
		console.log('contract dataC');
	}
}

var eventC = {
	init : function (){
		
	}
}
var uiC = {
	init : function (){
		
	} 
}