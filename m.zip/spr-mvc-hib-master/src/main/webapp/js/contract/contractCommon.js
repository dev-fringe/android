var cm; if(cm===undefined || typeof cm !== "object") cm = {};

(function(){
	/**
	 * ajax 실행
	 * @param {object}   controller
	 * @param {string}   url
	 * @param {object}   data
	 * @param {boolean}  useProgress
	 * @param {function} callbackSuccess
	 * @param {boolean}  toMap   @RequestBody Map<String, Object> 으로 전달할 경우 true
	 */
	cm.ajax = function(controller, url, data, useProgress, callbackSuccess, toMap){
		controller.ajaxSend({
			url     : contextPath + url,
			data    : toMap ? JSON.stringify(data) : data,
			isBlock : !!useProgress,
			dataType: 'json',
			type    : 'post',
			contentType: toMap ? 'application/json;charset=UTF-8' : undefined,
			successCall:function(result) {
				
				//NEED_LOGIN
				if(result.retCode==='07'){
					cm.message.alert({
						title: '안내',
						text : '로그인 정보가 존재 하지 않습니다.<br>로그인 후 이용해주세요.'
					}, function(){
						goLogin();
					});
					return;
				}
				
				if(typeof callbackSuccess==='function'){
					callbackSuccess(result);
				}
			}
		});
	};
	/**
	 * 클라이언트의 스크롤 top 위치를 반환한다.
	 */
	cm.getScrollTop=function(){
		if(document.body.scrollTop == 0) {
			return document.documentElement.scrollTop;
		} else {
			return document.body.scrollTop;
		}
	};
	
	/**
	 * 빈값 여부를 반환한다.
	 * @param {anytype} v
	 * @return {boolean} true = ""(빈문자열), " "(공백), undefined, null, "__NONE__" 
	 */
	cm.isEmptyValue=function(v){
		return $.trim(v).length===0 || v==="__NONE__";
	};
	
	cm.unique = {
		idx: 0,
		get: function(prefix){
			var result = (new Date()).getTime() + '' + (++this.idx);
			if(prefix){
				result = prefix + result;
			}
			return result;
		}
	};
})();

/**
 * cm.message : 알림창 제어
 */
(function(){
	var message = cm.message = {
		/**
		 * 알림 메세지를 띄운다
		 * @param {string|jsonObject}   msg {
		 *                                   {string}  title : 제목
		 *                                   {string}  text  : 본문
		 *                                   {string}  subText : 추가내용
		 *                               }
		 * @param {function}            [callback]   확인 버튼 클릭시 호출 될 콜백함수
		 * @param {string}              [btnName]    확인 버튼 이름
		 */
		alert: function(msg, callback, btnName){
			var $item = temp.alert.get(msg, callback, btnName);
			factory.open($item);
		},
		/**
		 * 확인 메세지를 띄운다
		 * @param {string|jsonObject}   msg {
		 *                                   {string}  title : 제목
		 *                                   {string}  text  : 본문
		 *                                   {string}  subText : 추가내용
		 *                               }
		 * @param {function}            [callbackConfirm]  확인 버튼 클릭시 호출 될 콜백함수
		 * @param {function}            [callbackCancel]   취소 버튼 클릭시 호출 될 콜백함수
		 * @param {string}              [btnConfirmName]   확인 버튼 이름
		 * @param {string}              [btnCancelName]    취소 버튼 이름
		 */
		confirm: function(msg, callbackConfirm, callbackCancel, btnConfirmName, btnCancelName){
			var $item = temp.confirm.get(msg, callbackConfirm, callbackCancel, btnConfirmName, btnCancelName);
			factory.open($item);
		},
		/**
		 * 상품(이벤트)상세보기 레이어를 띄운다 
		 * @param {string}            title   제목
		 * @param {string}            content 본문
		 */
		productInfo: function(title, content){
			var $item = temp.productInfo.get(title, content);
			factory.open($item);
		}
	};
	
	var factory = {
		open: function($item){

			$('body').addClass('bodyHold');
			
			var $docFrag = $(document.createDocumentFragment()).append($item);
			$('body').append($docFrag);
			
			$item.bPopup({
				modalClose: false,
				onClose: function(){
					$item.remove();
					if($('body [data-message-item]').length===0){
						$('body').removeClass('bodyHold');
					}
				}
			});
		}
	};
	
	var temp = {
		convertMessage: function(s){
			if(s===undefined || s===null) return s;
			switch(typeof s){
				case "object":
					s = JSON.stringify(s);
					break;
				case "number":
					s = s.toString();
					break;
			}
			try{
				s = decodeURIComponent(s);
			}
			catch(e){
				msg = msg;
			}
			return s.replace(/\\n|\n/g, '<br>');
		}
	};
	/**
	 * alert 템플릿
	 */
	temp.alert = {
		get: function(msg, callback, btnName){
			if(!this.$){
				var html = [];
				html.push('<div class="pop-wp" data-message-item>');
				html.push(	'<div class="pop-ct">');
				html.push(		'<strong class="pop-tit" data-message-layout="title"></strong>');//제목
				html.push(		'<p class="txt" data-message-layout="text"></p>');//본문
				html.push(		'<p class="stxt" data-message-layout="subText"></p>');//추가내용
				html.push(		'<div class="btn-wp">');
				html.push(			'<ul class="colum">');
				html.push(				'<li><button type="button" class="btn1 red b-close" data-id="btn-confirm"><span>확인</span></button></li>');
				html.push(			'</ul>');
				html.push(		'</div>');
				html.push(	'</div>');
				html.push('</div>');
				this.$ = $(html.join(""));
			}
			var $item = this.$.clone();
			
			var $title = $item.find('[data-message-layout="title"]');//제목
			var $text = $item.find('[data-message-layout="text"]');//본문
			var $subText = $item.find('[data-message-layout="subText"]');//추가내용
			
			if(typeof msg==="object"){
				//제목
				if(!!msg.title){
					$title.html(temp.convertMessage(msg.title));
				}
				else{
					$title.remove();
				}
				//본문
				if(!!msg.text){
					$text.html(temp.convertMessage(msg.text));
				}
				else{
					$text.remove();
				}
				//추가내용
				if(!!msg.subText){
					$subText.html(temp.convertMessage(msg.subText));
				}
				else{
					$subText.remove();
				}
			}
			else{
				$title.remove();
				$text.html(temp.convertMessage(msg));
				$subText.remove();
			}
			
			//확인 버튼 명
			if(!!btnName){
				$item.find('[data-id="btn-confirm"]').children().text(btnName);
			}
			//확인버튼 클릭시 콜백 처리
			$item.find('[data-id="btn-confirm"]').click(function(e){
				e.preventDefault();
				if(typeof(callback)==="function"){
					callback();
				}
			});
			return $item;
		}
	};
	/**
	 * confirm 템플릿
	 */
	temp.confirm = {
		get: function(msg, callbackConfirm, callbackCancel, btnConfirmName, btnCancelName){
			if(!this.$){
				var html = [];
				html.push('<div class="pop-wp" data-message-item>');
				html.push(	'<div class="pop-ct">');
				html.push(		'<p class="pop-tit" data-message-layout="title"></p>');//제목
				html.push(		'<p class="txt" data-message-layout="text"></p>');//본문
				html.push(		'<p class="stxt" data-message-layout="subText"></p>');//추가내용
				html.push(		'<div class="btn-wp">');
				html.push(			'<ul class="colum">');
				html.push(				'<li><button type="button" class="btn1 b-close" data-id="btn-cancel"><span>취소</span></button></li>');
				html.push(				'<li><button type="button" class="btn1 red b-close" data-id="btn-confirm"><span>확인</span></button></li>');
				html.push(			'</ul>');
				html.push(		'</div>');
				html.push(	'</div>');
				html.push('</div>');
				
				this.$ = $(html.join(""));
			}
			var $item = this.$.clone();
			
			var $title = $item.find('[data-message-layout="title"]');//제목
			var $text = $item.find('[data-message-layout="text"]');//본문
			var $subText = $item.find('[data-message-layout="subText"]');//추가내용
			
			if(typeof msg==="object"){
				//제목
				if(!!msg.title){
					$title.html(temp.convertMessage(msg.title));
				}
				else{
					$title.remove();
				}
				//본문
				if(!!msg.text){
					$text.html(temp.convertMessage(msg.text));
				}
				else{
					$text.remove();
				}
				//추가내용
				if(!!msg.subText){
					$subText.html(temp.convertMessage(msg.subText));
				}
				else{
					$subText.remove();
				}
			}
			else{
				$title.remove();
				$text.html(temp.convertMessage(msg));
				$subText.remove();
			}
			
			//확인 버튼 명
			if(!!btnConfirmName){
				$item.find('[data-id="btn-confirm"]').children().text(btnConfirmName);
			}
			//확인버튼 클릭시 콜백 처리
			$item.find('[data-id="btn-confirm"]').click(function(e){
				e.preventDefault();
				if(typeof(callbackConfirm)==="function"){
					callbackConfirm();
				}
			});
			
			//취소 버튼 명
			if(!!btnCancelName){
				$item.find('[data-id="btn-cancel"]').children().text(btnCancelName);
			}
			//취소버튼 클릭시 콜백 처리
			$item.find('[data-id="btn-cancel"]').click(function(e){
				e.preventDefault();
				if(typeof(callbackCancel)==="function"){
					callbackCancel();
				}
			});
			
			return $item;
		}
	};
	/**
	 * confirm 템플릿
	 */
	temp.productInfo = {
		get: function(title, content){
			if(!this.$){
				var html = [];
				html.push('<div class="pop-wp" data-message-item>');
				html.push(	'<div class="pop-ct info">');
				html.push(		'<header class="pop-header">');
				html.push(			'<h3 class="pop-tit">상품(이벤트) 안내</h3>');
				html.push(			'<button type="button" class="b-close"><span class="hide">닫기</span></button>');
				html.push(		'</header>');
				html.push(		'<section class="pop-noti">');
				html.push(			'<h4 class="tit" data-message-layout="title"></h4>');
				html.push(			'<div class="txt">');
				html.push(				'<div data-message-layout="content"></div>');
				html.push(			'</div>');
				html.push(			'<div class="btn-wp">');
				html.push(				'<ul class="colum">');
				html.push(					'<li><button type="button" class="btn1 red b-close"><span>확인</span></button></li>');
				html.push(				'</ul>');
				html.push(			'</div>');
				html.push(		'</section>');
				html.push(	'</div>');
				html.push('</div>');
				
				this.$ = $(html.join(""));
			}
			var $item = this.$.clone();
			
			var $title   = $item.find('[data-message-layout="title"]');//제목
			var $content = $item.find('[data-message-layout="content"]');//본문
			
			$title.html(temp.convertMessage(title));
			$content.html(temp.convertMessage(content));
			
			return $item;
		}
	};
})();//end of cm.message


/**
 * cm.code : 코드정보조회
 */
(function(){
	var code = cm.code = {
		memCache: {
			/**
			 * 코드그룹에 해당하는 memCache 코드 리스트를 콜백함수로 전달한다.
			 * @param {string}   cdCl 코드그룹
			 * @param {function} fn({
			 *                       {Array} list: 코드목록
			 *                   }) 
			 */
			getList: function(controller, cdCl, fn){
				var data = {cdCl: cdCl};
				cm.ajax(controller, '/contract/selectCode.json', data, true, function(r){
					fn(r.retList);
				});
			}
		}
	};
})();


/**
 * cm.format
 */
(function(){
	var code = cm.format = {
		/**
		 * 입력값을 문자열로 반환한다
		 * @param {string|number|jsonObject} v
		 * @return {string}
		 */
		toString: function(v){
			if(v===null || v===undefined){
				return "";
			}
			switch(typeof(v)){
				case "number":
					return v.toString();
				case "object":
					return JSON.stringify(v);
			}
			return v;
		},
		/**
		 * 입력값을 숫자로 반환한다.
		 * @param {string|number} v
		 * @return {number}
		 */
		toNumber: function(v){
			if(v===undefined || v===null){
				return 0;
			}
			if(typeof(v)==="string"){
				if(v.length===0){
					return 0;
				}
				var flag = v.startsWith("-") ? "-" : "";
				v = flag + v.replace(/[^\d\.]/g, "");
				v = Number(v);
				if(isNaN(v)){
					return 0;
				}
			}
			return v;
		},
		/**
		 * 숫자
		 * @param {string|number} v              숫자
		 * @param {number}        [decimalPoint] 소수점 자릿수
		 * @return {string}
		 */
		number: function(v, decimalPoint){
			if(typeof(v)==="string"){
				if(v.length===0){
					return "";
				}
				v = v.replace(/[^-\d\.]/g, "");
				if(decimalPoint!==0 && !decimalPoint && v.indexOf(".")>-1){
					decimalPoint = v.substring(v.indexOf(".")+1).length;
				}
				v = Number(v);
				if(isNaN(v)){
					return "";
				}
			}
			if(!!decimalPoint){
				v = v.toFixed(decimalPoint+1);
				v = v.substring(0, v.length-1);
			}
			else{
				if(decimalPoint===0){
					v = v.toFixed(0);
				}
				v = v.toString();
			}
			var p = /(\d)(?=(?:\d{3})+(?!\d))/g, decimal_index = v.indexOf(".");
			if(decimal_index<0) decimal_index = v.length;
			return v.replace(p, function(match, $1, offset){
				if(decimal_index > offset){
					return $1 + ",";
				}
				else{
					return $1;
				}
			});
		}
	};
})();

$(function(){
	//selectOrDie fix
	$('body').on('change', 'select', function(){
		var $sod = $(this).prev();
		if($sod.length > 0 && $sod.hasClass('sod_list_wrapper')){
			$sod.find('.sod_option').removeClass('active selected');
			$sod.find('.sod_option[data-value="' + this.value + '"]').addClass('active selected');
		}
	});
})