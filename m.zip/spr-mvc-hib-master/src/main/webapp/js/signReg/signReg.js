var controller = $.extend(new $.CommonObj(), {
	eventInit : function() {
		// 로그인
		$(document).on("click", "#btnApplicatNum", function() {
			if ($.trim($("#applicatNum").val()) == "") {
				$("#signPopup").bPopup({
					onOpen: function(){ $('body').addClass('bodyHold'); },
					onClose: function(){ $('body').removeClass('bodyHold'); }
				});
				$("#applicatNum").focus();
				return;
			}
			
			var param = { recvNo : $("#applicatNum").val() };
			
			
//            controller.ajaxSend( {
//				url : contextPath + '/sign/signRegSearch.json'
//				, data : param
//				, dataType : 'json'
//				, type : 'post'
//				, isBlock : true
//				, isOverLap : true
//				, successCall:function(result) {
//					var rsltCd = result.rspCd;
//					var rsltMsg = result.rspMsg;
//					var tt = result.responseSignTgtInfoVO.juminBizNo;
//					
//					if (rsltCd == 000 || rsltCd == 001) { // 000 정상, 001 정상 (패스워드 종료일 7일이내)
//						if (rsltCd == 001) {
//							var notiTxt = '<p class="txt">'+ apiMsg +'</p>';
//							$('#loginNotiMsg').html(notiTxt);
//							loginNoti(); // 로그인 공지
//						} else {
//							var easyId = $("#userId").val();
//							if($("#easyYn").is(":checked")) { // 간편로그인 체크
//								saveId(easyId);
//							} else {
//								saveId(""); // 간편로그인 해제
//							}
//							goMain();
//						}
//					} else { //100 실패
//						var txt = '<p class="txt">'+ apiMsg +'</p>';
//						$('#popMsg').html(txt);
//						loginFail(); // 로그인 실패
//					}
//				}
//            });
		});

		// 테스트 DB 로그인
		$('#btnEasy').on({click :function(event){
			var param = {
						userId :'ants01' 
						, password : 'iants123!'
						, easyYn : 'on'
				};
			
		    controller.ajaxSend( {
		    	url : contextPath + "/login/dbLogin.json"
		    	, data : param
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var retCode = result.retCode;
					var retMsg = result.retMsg;
					var noti = result.loginNoti;
					if (retCode == "SUCC") {
						var easyId = $("#userId").val();
						if($("#easyYn").is(":checked")) { // 간편로그인 체크
							saveId(easyId);
						} else {
							saveId(""); // 간편로그인 해제
						}
						
						if(noti != "") {
							var notiTxt = '<p class="txt">'+ noti +'</p>';
							$('#loginNotiMsg').html(notiTxt);
							loginNoti(); // 로그인 공지
						} else {
							goMain();
						}
					} else {
						var txt = '<p class="txt">'+ retMsg +'</p>';
						$('#popMsg').html(txt);
						loginFail(); // 로그인 실패
					}
				}
		    });
	    }
		});
		// 테스트 DB 로그인
		$('#btnNor').on({click :function(event){
			var param = {
					userId :'ants01' 
					, password : 'iants123!'
			};
			
			controller.ajaxSend( {
				url : contextPath + "/login/dbLogin.json"
				, data : param
				, dataType : 'json'
					, type : 'post'
						, isBlock : true
						, isOverLap : true
						, successCall:function(result) {
							var retCode = result.retCode;
							var retMsg = result.retMsg;
							var noti = result.loginNoti;
							if (retCode == "SUCC") {
								var easyId = $("#userId").val();
								if($("#easyYn").is(":checked")) { // 간편로그인 체크
									saveId(easyId);
								} else {
									saveId(""); // 간편로그인 해제
								}
								
								if(noti != "") {
									var notiTxt = '<p class="txt">'+ noti +'</p>';
									$('#loginNotiMsg').html(notiTxt);
									loginNoti(); // 로그인 공지
								} else {
									goMain();
								}
							} else {
								var txt = '<p class="txt">'+ retMsg +'</p>';
								$('#popMsg').html(txt);
								loginFail(); // 로그인 실패
							}
						}
			});
		}
		});
		
		// 비밀번호 변경 버튼
		$(document).on("click", "#chgConfirm", function() {
			if ($("#chgConfirm").attr("class") == "btn1 red disabled") {
	    		$("#pwTitle").text('비밀번호 변경 안내');
	    		$("#pwMsg").text('변경 항목을 모두 입력해주세요.');
	     		$("#pwValidPop").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
				return;
			}
			
			if ($.trim($("#loginNewPw").val()) != $.trim($("#loginNewPwConfirm").val())) {
				$("#pwTitle").text('비밀번호 변경 안내');
				$("#pwMsg").text('새 비밀번호가 일치하지 않습니다.');
				$("#pwValidPop").bPopup({
					onOpen: function(){ $('body').addClass('bodyHold'); },
					onClose: function(){ $('body').removeClass('bodyHold'); }
				});
				return;			
			}
			
     		$("#pwConfirm").bPopup({
     			onOpen: function(){ $('body').addClass('bodyHold'); },
     			onClose: function(){ $('body').removeClass('bodyHold'); }
     		});
		});

		// 임시 비밀번호 신청 버튼
		$(document).on("click", "#chgIdTemporary", function() {
			if ($.trim($("#loginIdTemporary").val()) == "") {
	    		$("#pwTitle").text('임시 비밀번호 신청 안내');
	    		$("#pwMsg").text('아이디를 입력해주세요.');
	     		$("#pwValidPop").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
				$("#loginIdTemporary").focus();
				return;
			}
			$("#pwTempConfirm").bPopup({
				onOpen: function(){ $('body').addClass('bodyHold'); },
				onClose: function(){ $('body').removeClass('bodyHold'); }
			});
		});
	},
});

$(document).ready(function(){
	controller.init();
	
    // 조회 버튼 키업 이벤트 
	$('#applicatNum').keyup(function(event) {
		if ($.trim($("#applicatNum").val()) == "") {
			$("#applicatNum").val("");
			$('#btnApplicatNum').addClass("disabled");
		} else {
			$('#btnApplicatNum').removeClass("disabled");
		}
	});
	// 신청완료 버튼 키업 이벤트
//	$('#userId').keyup(function(event) {
//		if ($.trim($("#userId").val()) == "") {
//			$("#userId").val("");
//			$('#btnLogin').addClass("disabled");
//		} else if ($.trim($("#password").val()) == ""){
//			$('#btnLogin').addClass("disabled");
//		} else {
//			$('#btnLogin').removeClass("disabled");
//		}
//	});
});

function loginNoti(){
	$("#loginNoti").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function loginFail(){
	$("#loginFail").bPopup({
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}

function goMain(){
	location.href = contextPath + '/main.do';
}
function goLogout(){
	location.href = contextPath + '/logout.do';
}
function pwChgApi(){ // 비밀번호 변경
	$("#pwConfirm").bPopup().close();
	
	var param = {
			userId : $("#chgLoginId").val()
			, password : $("#loginNewPwConfirm").val()
			, OldPassword : $("#loginCurrentPw").val()
			, mblId : "357174095821635"
	};
	
	controller.ajaxSend( {
		url : contextPath + '/login/pwdChangeApi.json'
		, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var rsltCd = result.result.rsltCd;
			var rsltMsg = result.result.rsltMsg;
			
			if (rsltCd == 000) { // 비밀번호 변경 000 정상
				$("#pwChgSuccTitle").text('비밀번호 변경 완료 안내');
	    		var pwSuccMsg = '<p class="txt">'+'비밀번호 변경이 완료되었습니다.<br>다시 로그인 해주세요.'+'</p>';
				$('#pwChgSuccMsg').html(pwSuccMsg);
				$("#pwChgSucc").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
			} else { // 100 실패, 102 아이디 혹은 패스워드 다름, 106 패스워드 형식 오류
	    		$("#pwTitle").text('비밀번호 변경 실패 안내');
	    		var pwMsg = '<p class="txt">'+'비밀번호 변경이 실패하였습니다.<br>다시 변경해주세요.'  +'</p>';
				$('#pwMsg').html(pwMsg);
	     		$("#pwValidPop").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
			}
		}
	});
}
function pwTempChgApi(){ // 임시 비밀번호 신청
	$("#pwTempConfirm").bPopup().close();

	var param = {
			userId : $("#loginIdTemporary").val()
			, mblId : "357174095821635"
	};
	
	controller.ajaxSend( {
		url : contextPath + '/login/pwTempChgApi.json'
		, data : param
		, dataType : 'json'
		, type : 'post'
		, isBlock : true
		, isOverLap : true
		, successCall:function(result) {
			var rsltCd = result.result.rsltCd;
			var rsltMsg = result.result.rsltMsg;
			
			if (rsltCd == 000) { // 임시 비밀번호 신청 000 정상
//				$("#pwChgSuccTitle").text('임시 비밀번호 신청 완료 안내');
				var pwSuccTitle = "<strong class='pop-tit'>임시 비밀번호 신청<br> 완료 안내</strong>";
				$('#pwChgSuccTitle').html(pwSuccTitle);
				
	    		var pwSuccMsg = '<p class="txt">임시 비밀번호 신청이 완료되었습니다.<br>다시 로그인 해주세요.</p>';
				$('#pwChgSuccMsg').html(pwSuccMsg);
				$("#pwChgSucc").bPopup({
	     			onOpen: function(){ $('body').addClass('bodyHold'); },
	     			onClose: function(){ $('body').removeClass('bodyHold'); }
	     		});
			} else { // 100 실패, 102 아이디 혹은 패스워드 다름, 106 패스워드 형식 오류
//				$("#pwTitle").text('임시 비밀번호 신청 실패 안내');
				var pwTitle = "<strong class='pop-tit'>임시 비밀번호 신청<br> 실패 안내</strong>";
				$('#pwTitle').html(pwTitle);
				
				var pwMsg = '<p class="txt">임시 비밀번호 신청이 실패하였습니다.<br>다시 변경해주세요.</p>';
				$('#pwMsg').html(pwMsg);
				$("#pwValidPop").bPopup({
					onOpen: function(){ $('body').addClass('bodyHold'); },
					onClose: function(){ $('body').removeClass('bodyHold'); }
				});
			}
		}
	});
}
function pwCancle(){
	$("#pwCancle").bPopup({ 
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}
function pwTempCancle(){
	$("#pwTempCancle").bPopup({ 
		onOpen: function(){ $('body').addClass('bodyHold'); },
		onClose: function(){ $('body').removeClass('bodyHold'); }
	});
}


function fnCmmAozSign(v_type, v_moRecvNo){
	/*
	 * 인풋 구분 코드
	 * */
	//서명 > 신청(대리인) 서명 GAE_SIGN
	//서명 > 납부 서명 NABB_SIGN
	//서명 > 접수 서명 JUBSU_SIGN
	var paramObjReq = {
			type : "" //페이지내 id 구분
			, moRecvNo : ""   //스마트청약접수번호
			, moFileType : "" //내부 db 공통코드(MO_FILE_TYPE) 값
			
		}
		
	if(v_type == "GAE_SIGN"){
		paramObjReq.type = v_type;
		paramObjReq.moRecvNo = v_moRecvNo;
		paramObjReq.moFileType = "APLN_SIGN_MTH_CD";
	}else if(v_type == "NABB_SIGN"){
		paramObjReq.type = v_type;
		paramObjReq.moRecvNo = v_moRecvNo;
		paramObjReq.moFileType = "ACCT_SIGN_MTH_CD";
	}else if(v_type == "JUBSU_SIGN"){
		paramObjReq.type = v_type;
		paramObjReq.moRecvNo = v_moRecvNo;
		paramObjReq.moFileType = "USER_SIGN_MTH_CD";
	}
	/*
	 * 인터페이스 호출
	 * */
	//-----------------------
//	sign(paramObjReq); //오즈 호출
	signPop(paramObjReq); //오즈 호출
	
	/*
	 * scis 코드
	 * */
	/*CM205	7462056	서명방식코드		APLN_SIGN_MTH_CD	신청자서명방식코드
	CM205	7462056	서명방식코드		USER_SIGN_MTH_CD	판매접수자서명방식코드
	CM205	7462056	서명방식코드		ACCT_SIGN_MTH_CD	타인납부서명방식코드*/

}


function fnCmmAozSignResult(paramObjRes){
	/*
	var paramObjRes = {
		type : "" //페이지내 id 구분
		, moFileType : "" 	//내부 인터페이스 서명방식코드 값
		, moRecvNo : ""   	//스마트청약접수번호
		, moFileNm : ""  	//첨부파일명-서명파일명
		, moFile : ""		//첨부파일경로-서명파일경로
	}
	*/
	var msg = "type : " + paramObjRes.type + "<br/>";
	msg = msg + "moFileType : " + paramObjRes.moFileType + "<br/>";
	msg = msg + "moRecvNo : " + paramObjRes.moRecvNo + "<br/>";
	msg = msg + "moFileNm : " + paramObjRes.moFileNm + "<br/>";
	msg = msg + "moFile : " + paramObjRes.moFile + "<br/>";
	//alert(msg);
	//var msgObj = {title : "", msg1 : msg, msg2 : ""};
	//fnPOPMessagePopup("CUSTOM", msgObj);
	
	
	if(paramObjRes.type == "GAE_SIGN" ){
		var imgContainer1 = $('#imgt_gae_sign');
		imgContainer1.html('');
	    imgContainer1.html('<li><div class="canvas" id="imgt_gae_sign"><img width="100%" src="'+paramObjRes.moFile+'"/></div></li>');
		var imgContainer2 = $('#imgt_gae_name');
		imgContainer2.html('');
	    imgContainer2.html('<li><div class="canvas" id="imgt_gae_name"><img width="100%" src="'+paramObjRes.moFile2+'"/></div></li>');
	    
//		$("#ult_gae_sign").hide();
//	    $("#imgt_gae_sign").attr("src",paramObjRes.moFile);
		return;
	}else if(paramObjRes.type == "NABB_SIGN" ){
		var imgContainer1 = $('#imgt_nabb_sign');
		imgContainer1.html('');
	    imgContainer1.html('<li><div class="canvas" id="imgt_nabb_sign"><img width="100%" src="'+paramObjRes.moFile+'"/></div></li>');
		var imgContainer2 = $('#imgt_nabb_name');
		imgContainer2.html('');
	    imgContainer2.html('<li><div class="canvas" id="imgt_nabb_name"><img width="100%" src="'+paramObjRes.moFile2+'"/></div></li>');		
//		$("#ult_nabb_sign").hide();
//		$("#imgt_nabb_sign").attr("src",paramObjRes.moFile);
		return;
	}else if(paramObjRes.type == "JUBSU_SIGN" ){
		var imgContainer1 = $('#imgt_jubsu_sign');
		imgContainer1.html('');
	    imgContainer1.html('<li><div class="canvas" id="imgt_jubsu_sign"><img width="100%" src="'+paramObjRes.moFile+'"/></div></li>');
		var imgContainer2 = $('#imgt_jubsu_name');
		imgContainer2.html('');
	    imgContainer2.html('<li><div class="canvas" id="imgt_jubsu_name"><img width="100%" src="'+paramObjRes.moFile2+'"/></div></li>');			
//		$("#ult_jubsu_sign").hide();
//		$("#imgt_jubsu_sign").attr("src",paramObjRes.moFile);
		return;
	}
	
}