var controller = $.extend(new $.CommonObj(), {
	eventInit : function() {

		// 로그인
		$(document).on("click", "#btnLoginId", function() {

			if ($.trim($("#id").val()) == "") {
				alert("아이디를 입력하여 주십시오.");
				$("#id").focus();
				return;
			}

			if ($.trim($("#pwd").val()) == "") {
				alert("비밀번호를 입력하여 주십시오.");
				$("#pwd").focus();
				return;
			}
			
            controller.ajaxSend( {
				url : contextPath + '/sample/login.json'
				, data : $("#form1").serialize()
				, dataType : 'json'
				, type : 'post'
				, isBlock : true
				, isOverLap : true
				, successCall:function(result) {
					var retCode = result.retCode;
					var retMsg = result.retMsg;
					if (retCode == "SUCC") {
						location.href="/sample/UserList.do";
					} else {
						alert(retMsg);
					}
				}
            });

		});
		
		$(document).on("click", "#btnJoinBranch", function() {
			var formOption = {
					"action" : "/join/JoinBranch.do"
			};
			controller.createForm(formOption);
			controller.formSubmit();
		});
		
	},
	getLoginApp : function(result) {
		doEmmBikeNativeIf({
			ifName : 'setLoginInfo'
			, ifData : '{"autoLoginYn":"'+result.autoLoginYn+'", "authToken":"'+ result.authToken+'"}'
		});
	},
	onCreate : function() {

	}
});

$(document).ready(function(){
	controller.init();
});

function setLoginInfoCallback(jsonString) {
	try {
    	var jsonObject = JSON.parse(jsonString);
    	var result = jsonObject.rt;
    	var msg = jsonObject.rtMsg;
    	
    	if(result == "0000") {
    		location.href = contextPath + "/main.do";
    	} else {
    		alert(msg);
    	}
	} catch(exception) {
		console.log(exception);
	}
}


function authCheck(){
	if($('#authChkType').val() == 'id'){
		var formOption = {
			"action" : "/login/ResultUserId.do"
		}
		controller.createForm(formOption);
		controller.attachHiddenElement('userDupInfo', $('#userDupInfo').val());
		controller.formSubmit();
	}else if($('#authChkType').val() == 'pwd'){
		var formOption = {
			"action" : "/login/NewPwd.do"
		}
		controller.createForm(formOption);
		controller.attachHiddenElement('userDupInfo', $('#userDupInfo').val());
		controller.formSubmit();
	}
}