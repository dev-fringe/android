package com.sprhib.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import dev.fringe.intergration.ws.auth.login.LoginReq;
import dev.fringe.intergration.ws.auth.login.LoginRes;

@Controller
public class LoginController {
	
	
	@RequestMapping(value="/auth/login")
	public ModelAndView indexPage() {
		LoginReq req = new LoginReq();
		req.setUsername("john1111@csticonsulting.com");
		req.setPassword("password");
		return new ModelAndView("/auth/login", "login", req);
	}
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ModelAndView addingTeam(@ModelAttribute LoginReq req) {
		RestTemplate template = new RestTemplate();
		System.out.println(template.postForObject("http://localhost:8080/api/v1/auth/login", req, LoginRes.class));
		return new ModelAndView("index", "message", "Team was successfully added.") ;
	}
	
}
