package com.sprhib.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sprhib.model.Team;
import com.sprhib.service.TeamService;

@Controller
@RequestMapping(value="/team")
public class TeamController {
	
	@Autowired
	private TeamService teamService;
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView addTeamPage() {
		return new ModelAndView("/team/add","team", new Team()) ;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ModelAndView addingTeam(@ModelAttribute Team team) {
		teamService.addTeam(team);
		return new ModelAndView("index", "message", "Team was successfully added.") ;
	}
	
	@RequestMapping(value="/list")
	public ModelAndView listOfTeams() {
		return new ModelAndView("/team/list", "teams", teamService.getTeams());
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
	public ModelAndView editTeamPage(@PathVariable Integer id) {
		return new ModelAndView("/team/edit", "team",teamService.getTeam(id)) ;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.POST)
	public ModelAndView edditingTeam(@ModelAttribute Team team, @PathVariable Integer id) {
		teamService.updateTeam(team);
		return new ModelAndView("index", "message", "Team was successfully edited.");
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.GET)
	public ModelAndView deleteTeam(@PathVariable Integer id) {
		teamService.deleteTeam(id);
		return  new ModelAndView("index", "message", "Team was successfully deleted.") ;
	}

}
