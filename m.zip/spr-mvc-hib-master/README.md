spr-mvc-hib
===========

Spring MVC + Hibernate + Maven tutorial with all CRUD operations
