package m;

import org.springframework.web.client.RestTemplate;

import dev.fringe.intergration.ws.auth.register.Billing;
import dev.fringe.intergration.ws.auth.register.RegisterReq;
import dev.fringe.intergration.ws.auth.register.RegisterRes;

public class RegisterTest {

//	{
//		"emailAddress":"john@csticonsulting.com",
//		"gender":"M",
//		"language":"en",
//		"userName":"john1@csticonsulting.com",
//		"clearPassword":"password",
//		"billing":{
//		  "address":"123 E Street",
//		  "city":"Toonto",
//		  "postalCode":"J4B 8J9",
//		  "country":"KR",
//		  "zone":"ON",
//		  "firstName":"��",
//		  "lastName":"�е�"
//		  }
//		}
	public static void main(String[] args) {
		RestTemplate template = new RestTemplate();
		RegisterReq req = new RegisterReq();
		req.setEmailAddress("john@csticonsulting.com");
		req.setGender("M");
		req.setLanguage("ko");
		req.setUserName("john1111@csticonsulting.com");
		req.setClearPassword("password");
		Billing bill = new Billing();
		bill.setAddress("123 E Street");
		bill.setCity("Toonto");
		bill.setCountry("KR");
		bill.setZone("ON");
		bill.setFirstName("��");
		bill.setLastName("�е�");
		req.setBilling(bill);
		System.out.println(template.postForObject("http://localhost:8080/api/v1/auth/register", req, RegisterRes.class));
	}
}
