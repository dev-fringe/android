package m;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

import dev.fringe.intergration.ws.auth.products.Description;
import dev.fringe.intergration.ws.auth.products.Owner;
import dev.fringe.intergration.ws.auth.products.ProductsReq;
import dev.fringe.intergration.ws.auth.register.RegisterRes;

public class ProductsTest {

//	{
//		  "price" : 49.99,
//		  "quantity" : 1,
//		  "sku" : "001uniqu1e",
//		  "quantityOrderMaximum" : 1,
//		  "quantityOrderMinimum" : 1,
//		  "productIsFree" : false,
//		  "available" : true,
//		  "visible" : true,
//		  "productLength" : 0,
//		  "productWidth" : 0,
//		  "productHeight" : 0,
//		  "productWeight" : 0,
//		  "rating" : 0.0,
//		  "ratingCount" : 0,
//		  "sortOrder" : 0,
//		  "dateAvailable" : "2017-11-01",
//		  "condition" : "NEW",
//		  "rentalDuration" : 10,
//		  "rentalPeriod" : 3,
//		  "rentalStatus" : "AVAILABLE",
//		  "descriptions" : [ {
//		    "language" : "en",
//		    "name" : "Jeep Cherokeel",
//		    "description" : "Jeep Cherokee 2013, perfect condition, non smoker",
//		    "keyWords" : null,
//		    "highlights" : "Jeep Cherokee 2013"
//		  }],
//		  "categories" : null,
//		  "relatedProducts" : null,
//		  "manufacturer" : null,
//		  "owner" : {
//		    "id":2
//		  }
//		}
	public static void main(String[] args) {
		RestTemplate template = new RestTemplate();
		ProductsReq req = new ProductsReq();
		req.setPrice(49.99);
		req.setQuantity(1);
		req.setSku("unique01");
		req.setQuantityOrderMaximum(1);
		req.setQuantityOrderMinimum(1);
		req.setProductPrices(false);
		req.setAvailable(true);
		req.setVisible(true);
		req.setProductLength(100);
		req.setProductWidth(100);
		req.setProductHeight(100);
		req.setProductWeight(100);
		req.setRating(0.0);
		req.setRatingCount(0);
		req.setDateAvailable("2017-11-01");
		req.setCondition("NEW");
		req.setRentalDuration(10);
		req.setRentalPeriod(3);
		req.setRentalStatus("AVAILABLE");
		Description des = new Description();
		des.setLanguage("en");
		des.setName("Jeep");
		des.setDescription("Jeep Cherokee 2013, perfect condition, non smoker");
		des.setKeyWords(null);
		des.setHighlights("Jeep Cherokee 2013");
		List<Description> descriptions = new ArrayList<>();
		descriptions.add(des);
		req.setDescriptions(descriptions);
		req.setCategories(null);
		req.setRelatedProducts(null);
		req.setManufacturer(null);
		Owner owner = new Owner();
		owner.setId(50);
		req.setOwner(owner);
		System.out.println(req);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "bearer " + "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqb2huMTMyM0Bjc3RpY29uc3VsdGluZy5jb20iLCJhdWQiOiJ1bmtub3duIiwiZXhwIjoxNTcwODQwMzg4LCJpYXQiOjE1NzAyMzU1ODh9.tSCiEcEDGTBqfAl-XPKBJjcjnQYZZaY8L0-AmoDmgPvHYl7ZA7_0YZzbDzn3626HHHdubAirlw7LdNGqbIX89w");
		headers.add("Content-Type", "application/json");
		headers.add("Accept", "application/json");
		HttpEntity requestEntity = new HttpEntity(req, headers);
		System.out.println(template.exchange("http://localhost:8080/api/v1/auth/products",HttpMethod.POST, requestEntity, RegisterRes.class));
	}

}
